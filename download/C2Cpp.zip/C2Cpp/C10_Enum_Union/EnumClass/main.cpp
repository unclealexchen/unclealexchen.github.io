//Project - EnumClass
#include <iostream>
using namespace std;

enum class GenderType:unsigned char{
    male,female
};  //注意末尾分号不能少

int main() {
    GenderType gender = GenderType::male; //::为域解析符
    //gender = male;    //错误: male不在全局名字空间内
    //gender = 1;       //错误：不允许进行整数与enum class之间的隐式类型转换
    gender = GenderType(0);  //显式类型转换 整数 -> 枚举项
    int i = int(GenderType::female); //显式类型转换 枚举项 -> 整数

    cout << "sizeof(gender) = " << sizeof(gender) << endl;
    cout << i << endl;

    return 0;
}
