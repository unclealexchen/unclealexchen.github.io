//Project - GenderType
#include <stdio.h>

typedef enum {
    male, female   //依次取值0,1
} GenderType;

int main(){
    //enum ColorType color = red;
    GenderType gender = female;

    printf("sizeof(GenderType) = %lld", sizeof(GenderType));
    return 0;
}
