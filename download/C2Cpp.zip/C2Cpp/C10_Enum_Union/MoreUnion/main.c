//Project - MoreUnion
#include <stdio.h>

union UMore {
    double dValue;    //全部8个字节
    char   cValue;    //8个字节中的前1个字节
    int    iValue;    //8个字节中的前4个字节
};

int main() {
    printf("sizeof(union UMore) = %d\n", sizeof(union UMore));

    union UMore v = {33.22};  //未指定初始化成员时默认赋值给第0个成员dValue
    printf("v.dValue = %f\n",v.dValue);

    printf("&v.dValue = %p, &v.cValue = %p, &v.iValue = %p\n",
           &v.dValue, &v.cValue, &v.iValue);

    union UMore* p = &v;
    printf("p->iValue = %d", p->iValue);

    return 0;
}
