//Project - UnionExample
#include <stdio.h>

union UINT {
    unsigned int intValue;   //占4个字节
    unsigned char bytes[4];  //占4个字节
};  //注意末尾分号不能少

int main() {
    union UINT v = {.intValue=0x11223344};

    printf("&v = %p, &v.intValue = %p, v.bytes = %p\n",
           &v, &v.intValue, v.bytes);

    printf("v.bytes[0..3] = 0x%x 0x%x 0x%x 0x%x\n",
           v.bytes[0], v.bytes[1], v.bytes[2], v.bytes[3]);

    v.bytes[0] = 0x55; v.bytes[1] = 0x66;  v.bytes[2] = 0x77;  v.bytes[3] = 0x88;
    printf("v.intValue = 0x%x\n",v.intValue);

    printf("sizeof(v) = %lld",sizeof(v));
    return 0;
}
