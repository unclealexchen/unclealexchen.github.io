//Project - CircleStruct
#include <stdio.h>

struct Point { //平面上的一个点，(x,y)为坐标
    int x;
    int y;
};

typedef struct {
    struct Point ptCenter;  //圆心
    float fRadius;          //半径
} Circle;

void horizontalMove(Circle* c, int offset){
    c->ptCenter.x += offset; //圆在水平方向上移动offset
}

int main() {
    Circle c = {{0,100},4.1F};

    c.ptCenter = (struct Point){0,0};
    c.ptCenter.y = 0;

    horizontalMove(&c, -12);

    printf("center = (%d, %d), radius = %f",
           c.ptCenter.x, c.ptCenter.y, c.fRadius);

    return 0;
}
