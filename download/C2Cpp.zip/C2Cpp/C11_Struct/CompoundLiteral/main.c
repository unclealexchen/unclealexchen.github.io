//Project - CompoundLiteral
#include <stdio.h>
#include <stdbool.h>

typedef struct {
    float width;
    float height;
} Rect;   //表示一个矩形的结构体

float computeArea1(Rect r){  //矩形面积计算函数1
    return r.width * r.height;
}

float computeArea2(const Rect* r){ //矩形面积计算函数2
    return r->width * r->height;
}

int main() {
    Rect r;
    r = (Rect){15,10};  //复合字面量

    float fArea1 = computeArea1((Rect){3,2});   //生成临时对象并传值
    float fArea2 = computeArea2(&(Rect){3,2});  //对临时对象取地址

    printf("fArea1 = %f, fArea2 = %f\n", fArea1, fArea2);
    return 0;
}
