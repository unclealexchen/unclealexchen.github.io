//Project - EmployeeInfo
#include <stdio.h>
#include <stdbool.h>

typedef enum {
    male = 0, female = 1
} GenderType;

typedef struct {
    char sName[10];     //姓名
    bool bRetired;      //是否已退休
    int  iSalary;       //月薪
    GenderType gender;  //性别
} Employee;

void printEmployee(const Employee* p){
    printf("------Employee Information--------\n");
    printf("Name:   \t%s\n",p->sName);
    printf("Retired:\t%s\n",p->bRetired?"Yes":"No");
    printf("Salary: \t%d\n",p->iSalary);
    printf("Gender: \t%s\n",p->gender==male?"MALE":"FEMALE");
}

int main() {
    Employee e = {"Jack Ma", false, 9000, male};
    e.iSalary += 1000;

    Employee* p = &e;
    p->bRetired = true;
    (*p).bRetired = false;

    printEmployee(p);
    return 0;
}
