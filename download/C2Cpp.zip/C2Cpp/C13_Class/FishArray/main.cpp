//Project - FishArray
#include <iostream>
using namespace std;

class Fish {
public:
    int iNumber;
    Fish(){
        static int iCounter = 0; //静态对象可以在函数的多次调用间保存其值
        iNumber = iCounter++;
        cout << "Fish Constructor called: " << iNumber << endl;
    }

    ~Fish(){
        cout << "Fish Destructor called:  "  << iNumber << endl;
    }
};

int main() {
    Fish stackFishes[3];
    for (auto& f:stackFishes)
        cout << f.iNumber << ", ";

    cout << "\n---------------------------------------" << endl;

    Fish* heapFishes = new Fish[4];  //也可写作new Fish[4]()
    cout << heapFishes[0].iNumber << ", " << heapFishes[1].iNumber << ", "
         << heapFishes[2].iNumber << ", " << heapFishes[3].iNumber << endl;
    delete []heapFishes;

    cout << "--------------------------------------" << endl;
    return 0;
}
