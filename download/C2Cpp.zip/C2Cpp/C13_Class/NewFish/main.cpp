//Project - NewFish
#include <iostream>
using namespace std;

class Fish {
public:
    string sName;
    Fish(const string& name){
        sName = name;
        cout << "Fish Constructor called: " << sName << endl;
    }

    Fish(){
        sName = "N/A";
        cout << "Fish Constructor called: " << sName << endl;
    }

    ~Fish(){
        cout << "Fish Destructor called:  "  << sName << endl;
    }
};

int main() {
    Fish tom = Fish("tom");    //等价于Fish tom("tom")

    Fish* dora = new Fish("dora");
    Fish* nameless = new Fish; //new Fish等价于new Fish()

    cout << "---------------------------------" << endl;
    cout << "&tom = " << &tom << ", dora = " << dora
         << ", nameless = " << nameless << endl;
    cout << "3 Fish objects: " << tom.sName << ",  "
         << dora->sName << ",  " << nameless->sName << endl;
    cout << "---------------------------------" << endl;

    delete dora;
    delete nameless;

    return 0;
}
