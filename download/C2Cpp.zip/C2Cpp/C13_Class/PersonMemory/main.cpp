//Project - PersonMemory
#include <iostream>
#include <stdio.h>
using namespace std;

enum class GenderType{
    male = 0, female = 1
};

class Person{
public:
    string sName;       //姓名
    string sID;         //身份证号
    GenderType gender;  //性别
    int iWeight;        //体重，以克为单位

    Person(const string& id = "N/A", const string& name = "N/A" ){
        sID = id;
        sName = name;
        gender = GenderType::male;
        iWeight = 50000;
        cout << "Person::Person(), sName = " << sName << endl;
    }

    void speak(){
        cout << "Person::speak()" << endl;
        cout << "I am " << sName <<", Nice to meet you here." << endl;
    }

    void eat(int weight){
        iWeight += weight;
        cout << "I just ate " << weight << " gram's food." << endl;
    }

    string description(){
        char buffer[1024];  //注意缓冲区尺寸，当心溢出
        sprintf(buffer,"ID:     %s\nName:   %s\nGender: %s\nWeight: %d",
                sID.c_str(),sName.c_str(),
                gender==GenderType::male?"Male":"Female",iWeight);
        return buffer;
    }
};  //注意末尾的分号不能少

int main(){
    printf("sizeof(Person) = sizeof(string) x 2 + sizeof(GenderType) "
           "+ sizeof(int)\n= %lld x 2 + %lld + %lld \n= %lld\n",
           sizeof(string),sizeof(GenderType),sizeof(int),sizeof(Person));

    Person a("3604020001", "Peter Lee");

    printf("&a         = %p, sizeof(a)        = %lld\n",
           &a, sizeof(a));
    printf("&a.sName   = %p, sizeof(a.sName)  = %lld\n",
           &a.sName, sizeof(a.sName));
    printf("&a.sID     = %p, sizeof(a.sID)    = %lld\n",
           &a.sID, sizeof(a.sID));
    printf("&a.gender  = %p, sizeof(a.gender) = %lld\n",
           &a.gender, sizeof(a.gender));
    printf("&a.iWeight = %p, sizeof(iWeight)  = %lld\n",
           &a.iWeight, sizeof(a.iWeight));

    return 0;
}

