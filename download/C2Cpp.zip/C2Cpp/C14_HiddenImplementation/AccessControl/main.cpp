//Project - AccessControl
#include <iostream>
using namespace std;

class Person{
private:                         //可略去不写，默认为private
    float fIncome {0.0f};        //月收入
    float computeIncomeTax(){    //计算收入税
        return fIncome*0.2F;     //收入税=月收入 x 20%
    }
public:
    string sID;
    string sName;

    void setIncome(float fIncome){  //设置月收入
        this->fIncome = fIncome;    //在类里访问本类私有属性
    }

    string description(){
        auto fIncomeTax = computeIncomeTax(); //在类里访问本类私有函数

        char buffer[1024];  //注意缓冲区尺寸，当心溢出
        sprintf(buffer,"ID:         %s\nName:       %s\nIncome:"
                "     %.2f\nIncome Tax: %.2f",
                sID.c_str(), sName.c_str(), fIncome, fIncomeTax);
        return buffer;
    }
};

int main() {
    Person dora;
    dora.sID = "3604020001"; //访问公有数据成员
    dora.sName = "Dora Henry";

    //dora.fIncome = 3000;   //错误：不可以访问私有成员
    //auto fIncomeTax = dora.computeIncomeTax();

    dora.setIncome(5000);    //访问公有成员函数
    cout << dora.description();

    return 0;
}
