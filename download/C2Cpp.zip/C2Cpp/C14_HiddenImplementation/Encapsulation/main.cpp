//Project - Encapsulation
#include <iostream>
using namespace std;

#include <Engine>
#include <Wheel>
#include <Window>
#include <Seat>

class Car{
public:
    Engine e(2000);
    Wheel wheels[4];
    Window frontWindows[2];
    Window backWindows[2];
    Seat seats[5];
    int iWeight = 2300;

    void pushSpeedPedal(int offset){
        if (offset > 0)
            cout << "Speed Up." << endl;
        else
            cout << "Speed Down." << endl;
    }

    void pushBrake(){
        cout << "Car is slowing down." << endl;
    }
};

int main() {
    cout << "Hello World!" << endl;
    return 0;
}
