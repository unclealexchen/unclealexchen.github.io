//Project - FriendFunction
#include <iostream>
using namespace std;

class Complex{          //复数类
private:
    float fReal;        //私有的实部和虚部
    float fImage;
public:
    Complex(float real, float img){
        fReal = real;
        fImage = img;
    }
    friend Complex add(const Complex&, const Complex&);
    friend int main();  //声明友元函数
};

Complex add(const Complex& a, const Complex& b){
    float fReal = a.fReal + b.fReal;    //友元函数访问对象的私有成员
    float fImage = a.fImage + b.fImage;
    return Complex(fReal,fImage);
}

int main() {
    Complex a(3,2);
    Complex c = add(a,Complex(2,3));

    cout << "(3+2i)+(2+3i)= " << c.fReal << "+" << c.fImage << "i";
    return 0;
}
