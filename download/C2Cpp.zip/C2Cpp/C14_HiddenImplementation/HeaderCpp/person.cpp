#include "person.h"

void Person::setIncome(float fIncome){
    this->fIncome = fIncome;    //在类里访问本类私有属性
}

string Person::description(){
    auto fIncomeTax = computeIncomeTax(); //在类里访问本类私有函数

    char buffer[1024];  //注意缓冲区尺寸，当心溢出
    sprintf(buffer,"ID:         %s\nName:       %s\nIncome:"
            "     %.2f\nIncome Tax: %.2f",
            sID.c_str(), sName.c_str(), fIncome, fIncomeTax);
    return buffer;
}
