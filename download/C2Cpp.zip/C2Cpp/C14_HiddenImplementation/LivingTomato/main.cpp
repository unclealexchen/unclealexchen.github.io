//Project - LivingTomato
#include <iostream>
using namespace std;

class Tomato {
private:
    static int iConstructed;   //构造数量
    static int iDestructed;    //析构数量
    float fSize {10};          //番茄的尺寸
public:
    Tomato(){
        iConstructed++;        //构造数量+1
    }

    ~Tomato(){
        iDestructed++;         //析构数量+1
    }

    static int livingCount(){
        //fSize *= 2;         //错误：不可以访问非静态成员
        //this->fSize -= 2;   //错误：静态成员函数没有this指针
        //存活数量  = 构造数量 - 析构数量
        return iConstructed - iDestructed;
    }
};

int Tomato::iConstructed {0};  //给静态数据成员赋初始值
int Tomato::iDestructed  {0};

int main() {
    Tomato t1;
    Tomato t2[10];
    Tomato *t3 = new Tomato[3];

    cout << "Number of living tomatoes = " << Tomato::livingCount() << endl;
    cout << "Number of living tomatoes = " << t2[3].livingCount() << endl;
    cout << "Number of living tomatoes = " << t3->livingCount() << endl;

    delete[] t3;
    cout << "Number of living tomatoes = " << t1.livingCount() << endl;

    return 0;
}
