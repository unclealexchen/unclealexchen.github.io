//Project - Singleton
#include <iostream>
using namespace std;

class Daemon {
private:
    static Daemon* instance;
    Daemon(){} //将构造函数私有
    Daemon(const Daemon&){} //将拷贝构造函数私有
public:
    static Daemon* Instance(){
        if (instance==nullptr)
            instance = new Daemon();
        return instance;
    }
};

Daemon* Daemon::instance {nullptr};

int main() {
    //Daemon d;  //错误：私有的构造函数不能执行
    //Daemon* d = new Daemon();

    Daemon* d1 = Daemon::Instance();
    //借助于d1指针使用唯一的Daemon对象...
    Daemon* d2 = Daemon::Instance();
    //借助于d2指针使用唯一的Daemon对象...

    cout << "d1 = " << d1 << ", d2 = " << d2 << endl;

    delete Daemon::Instance(); //释放唯一的Daemon对象
    return 0;
}
