//Project - TomatoCount
#include <iostream>
#include <stdio.h>
using namespace std;

class Tomato {
private:
    static int objectCount;   //静态数据成员
    float fSize {10};         //番茄的尺寸
public:
    Tomato(){
        objectCount++;        //每构造一个对象，数量加1
    }

    ~Tomato(){
        objectCount--;        //每析构一个对象，数量减1
    }
    friend int main();
};

int Tomato::objectCount = 0;  //给静态数据成员赋初始值

int main() {
    cout << "sizeof(Tomato) = " << sizeof(Tomato) << endl;

    Tomato t1;
    printf("&t1: %p, &Tomato::objectCount: %p\n", &t1, &Tomato::objectCount);

    Tomato t2[10];
    Tomato* t3 = new Tomato;

    printf("t1.objectCount=%d, t3->objectCount=%d, Tomato::objectCount=%d\n",
           t1.objectCount,t3->objectCount,Tomato::objectCount);
    printf("&t1.objectCount = %p, &t3->objectCount = %p\n",
           &t1.objectCount,&t3->objectCount);

    delete t3;
    printf("t1.objectCount=%d, Tomato::objectCount=%d\n",
           t1.objectCount,Tomato::objectCount);

    return 0;
}
