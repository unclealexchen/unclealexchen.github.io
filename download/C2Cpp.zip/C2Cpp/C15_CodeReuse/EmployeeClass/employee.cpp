#include "employee.h"
#include <iostream>
using namespace std;

Employee::Employee(const string& emplNo, const string& id,
                   const string& name):Person(id,name) {
    sEmployeeNo = emplNo;
    cout << "Employee::Employee()" << endl;
    //iWeight = 60000; //错误：不可以访问父类的私有成员
}

Employee::~Employee(){
    cout << "Employee::~Employee()" << endl;
}

void Employee::work(){
    cout << "I am a " << sJobTitle << ", working in department:"
         << sDepartment << endl;
}

void Employee::speak(){
    cout << "Employee::speak()" << endl;
    Person::speak();   //可以访问父类的保护成员函数
    cout << "I am happy to work for you." << endl;
}

string Employee::description(){
    char buffer[1024];  //注意缓冲区尺寸，当心溢出
    sprintf(buffer,"ID:     %s\nName:   %s\nGender: %s\nEmployee No: %s\n"
                   "Job Title: %s\nDepartment: %s",
            sID.c_str(),sName.c_str(),
            gender==GenderType::male?"Male":"Female",sEmployeeNo.c_str(),
            sJobTitle.c_str(),sDepartment.c_str());
    //可以访问gender, sID, sName等父类的保护数据成员
    return buffer;
}
