#include "person.h"
#include <iostream>

Person::Person(const string& id, const string& name ){
    sID = id;
    sName = name;
    cout << "Person::Person()" << endl;
}

Person::~Person(){
    cout << "Person::~Person()" << endl;
}

void Person::speak(){
    cout << "Person::speak()" << endl;
    cout << "I am " << sName <<", Nice to meet you here." << endl;
}

void Person::eat(int weight){
    iWeight += weight;
    cout << "I just ate " << weight << " gram's food." << endl;
}

string Person::description(){
    char buffer[1024];  //注意缓冲区尺寸，当心溢出
    sprintf(buffer,"ID:     %s\nName:   %s\nGender: %s\nWeight: %d",
            sID.c_str(),sName.c_str(),
            gender==GenderType::male?"Male":"Female",iWeight);
    return buffer;
}
