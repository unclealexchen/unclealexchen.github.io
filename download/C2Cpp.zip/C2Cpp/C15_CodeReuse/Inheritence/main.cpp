//Project - Inheritence
#include <iostream>
using namespace std;

class Base{
private:
    int iPrivate = 0;
protected:
    void protectedMethod(){}
public:
    float fPublic = 2.2;
};

class DerivedA:public Base {
};

class DerivedB:protected Base{
};

class DerivedC:private Base{
};


int main() {

    DerivedA a;
    Base* b0 = &a;          //公有继承允许隐式向上类型转换
    DerivedB b;
    Base* b1 = (Base*)&b;   //保护继承只允许在派生类中进行隐式向上类型转换
    DerivedC c;
    Base* b2 = (Base*)&c;   //私有继承不允许隐式向上类型转换

    return 0;
}
