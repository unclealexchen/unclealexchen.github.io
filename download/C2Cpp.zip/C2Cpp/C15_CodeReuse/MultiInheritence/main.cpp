//Project - MultiInheritence
#include <iostream>
using namespace std;

class Person{
public:
    string sName;
    string sID;
    void eat(int weight){
        cout << "Person::eat(): " << weight << " grams of food.\n";
    }

    Person(const string& id, const string& name){
        sID = id;
        sName = name;
        cout << "Person::Person()" << endl;
    }
};

class TaxPayer{
public:
    string sTaxNo;
    bool payTax(float fAmount){
        cout << "TaxPayer::payTax(): " << fAmount << endl;
        return true;
    }
    TaxPayer(){
        cout << "TaxPayer::TaxPayer()" << endl;
    }
};

class Employee: public Person, public TaxPayer {
public:
    string sEmployeeNo;
    int iWeekSalary = 0;
    void work(){
        cout << "Employee::work()" << endl;
    }
    Employee(const string& id, const string& name, const string& emplNo)
        :Person(id,name), sEmployeeNo(emplNo){ //构造函数初始化列表
        cout << "Employee::Employee()" << endl;
    }
};

int main(){
    cout << "------------------construct----------------------\n";
    Employee dora("3604020001","Dora Henry", "10000");

    cout << "------------------memory map---------------------\n";
    printf("sizeof(Employee) = sizeof(Person) + sizeof(TaxPayer)\n"
           "+ sizeof(string) + sizeof(int)\n"
           "= %lld + %lld + %lld + %lld\n= %lld\n",
           sizeof(Person),sizeof(TaxPayer),sizeof(string),
           sizeof(int),sizeof(Employee));
    Person* p = &dora;
    TaxPayer* t = &dora;
    printf("&dora = %p, &(Person Object) = %p\n"
           "&(TaxPayer Object) = %p, &dora.sEmployeeNo = %p\n"
           "&dora.iWeekSalary = %p\n",
           &dora,p,t,&dora.sEmployeeNo,&dora.iWeekSalary);

    cout << "------------------eat----------------------------\n";
    dora.eat(320);
    cout << "------------------work---------------------------\n";
    dora.work();
    cout << "------------------payTax-------------------------\n";
    dora.payTax(1000.00);

    return 0;
}
