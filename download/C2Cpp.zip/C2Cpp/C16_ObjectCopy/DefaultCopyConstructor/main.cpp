//Project - DefaultCopyConstructor
#include <iostream>
using namespace std;

class Point {     //点类
public:
    int x = 0;
    int y = 0;
    Point(const Point& r){
        x = r.x;  y = r.y;
        printf("Point::Point(const Point&) - (%d,%d)\n",x,y);
    }

    Point(){}     //显式定义构造函数
};

class Rectangle { //矩形类
public:
    Point ptTL;   //左上角坐标点
    Point ptBR;   //右下角坐标点
};

int main(){
    Rectangle r1;
    r1.ptTL.x = r1.ptTL.y = 100;
    r1.ptBR.x = r1.ptBR.y = 900;

    Rectangle r2 = r1;
    return 0;
}
