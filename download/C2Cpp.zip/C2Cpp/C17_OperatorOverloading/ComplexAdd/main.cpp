//Project - ComplexAdd
#include <iostream>
using namespace std;

class Complex {
public:
    double dReal;
    double dImage;

    Complex(double real, double image){
        dReal = real; dImage = image;
    }

    Complex operator+(const Complex& r) const{
        cout << "Complex::operator+()" << endl;
        return Complex(dReal+r.dReal,dImage+r.dImage);
    }
};

int main() {
    Complex a(1,3);
    Complex b(2,4);

    Complex c = a + b;
    printf("a + b = %.2f + %.2fi\n", c.dReal, c.dImage);
    return 0;
}
