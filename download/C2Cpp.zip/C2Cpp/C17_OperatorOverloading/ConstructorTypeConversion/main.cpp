//Project - ConstructorTypeConversion
#include <iostream>
using namespace std;

class Complex {
public:
    double dReal;
    double dImage;

    Complex(double real, double image){
        dReal = real; dImage = image;
    }

    Complex(const double r){
        cout << "Complex::Complex(const double)" << endl;
        dReal = r;  dImage = 0;
    }

    const Complex& operator=(const Complex& r){
        cout << "Complex::operator=(const Complex&)" << endl;
        dReal = r.dReal;  dImage = r.dImage;
        return *this;
    }
};

int main() {
    Complex c(1,5);
    c = 3.14;
}
