//Project - SmartPointer
#include <iostream>
using namespace std;

class Fish {
public:
    string sName;
    Fish(const string& name){
        sName = name;
        cout << "Fish Constructor called: " << sName << endl;
    }

    void sayHello(){
        cout << "Aloha: " << sName << endl;
    }

    ~Fish(){
        cout << "Fish Destructor called:  "  << sName << endl;
    }
};

template <typename T>
class SmartPointer {
private:
    T* ptr;             //原始指针
    int* refCount;      //指向引用计数的指针
    void releaseReference(){   //释放对对象的引用
        if (!ptr)
            return;
        (*refCount)--;
        if (*refCount==0){
            delete ptr; ptr = nullptr;
            delete refCount; refCount = nullptr;
        }
    }

public:
    SmartPointer(T* p=nullptr){
        ptr = p;
        refCount = new int;
        *refCount = ptr?1:0;
    }

    ~SmartPointer(){
        releaseReference();
    }

    //拷贝构造函数
    SmartPointer(const SmartPointer& r) {
        cout << "Copy constructor of SmartPointer." << endl;
        ptr = r.ptr;
        refCount = r.refCount;
        (*refCount)++;
    }

    //重载=操作符
    SmartPointer& operator=(const SmartPointer& r){
        cout << "operator=(const SmartPointer&)." << endl;
        if (&r == this)
            return *this;
        releaseReference();
        ptr = r.ptr;
        refCount = r.refCount;
        (*refCount)++;
        return *this;
    }

    //重载*操作符
    T& operator*(){
        cout << "operator*() of SmartPointer." << endl;
        if (ptr)
            return *ptr;
        throw exception();
    }

    //重载->操作符
    T* operator->(){
        cout << "operator->() of SmartPointer." << endl;
        if (ptr)
            return ptr;
        throw exception();
    }

    //查询引用计数
    int referenceCount(){
        return *refCount;
    }
};

int main() {
    SmartPointer<Fish> f1(new Fish("Dora"));
    SmartPointer<Fish> f2(new Fish("Tom"));
    auto f3 = f1;      //调用f3的拷贝构造函数，以f1为实参
    f2 = f1;           //调用f2的operator=()函数，以f1为实参，间接导致Tom鱼被释放
    (*f2).sayHello();  //调用f2的operator*()函数
    f2->sayHello();    //调用f2的operator->()函数
    cout << "Refernce count of Dora fish: " << f2.referenceCount() << endl;
    return 0;
}
