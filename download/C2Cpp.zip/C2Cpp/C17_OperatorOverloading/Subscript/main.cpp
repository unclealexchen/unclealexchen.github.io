//Project - Subscript
#include <iostream>
#include <string.h>
using namespace std;

class UserString {
private:
    char* buffer = nullptr;       //缓冲区指针
    unsigned long long size = 0;  //缓冲区大小

public:
    const UserString& operator=(const char* s){
        unsigned long long sizeNeeded = strlen(s) + 1;
        if (size >= sizeNeeded)   //缓冲区够用，直接复制
            strcpy(buffer,s);
        else {
            if (buffer!=nullptr)  //缓冲区不够用，重新申请后再复制
                free(buffer);
            size = sizeNeeded;
            buffer = (char*)calloc(size,1);
            strcpy(buffer,s);
        }
        return *this;
    }

    ~UserString(){
        if (buffer!=nullptr)
            free(buffer);
    }

    char& operator[](size_t idx){
        return buffer[idx];
    }

    size_t getSize(){
        return buffer?strlen(buffer):0;
    }

    friend ostream& operator<<(ostream&, const UserString&);
};

ostream& operator<<(ostream& o, const UserString& r){
    o << r.buffer;
    return o;
}

int main() {
    UserString s;
    s = "Aloha";
    cout << "before: " << s << endl;
    for (size_t i=0;i<s.getSize();i++){
        char& c = s[i];           //s[i] 等价于 s.operator[](i)
        if (c <= 'z' && c >= 'a')
            c += 'A' - 'a';
    }
    cout << "after: " << s <<endl;
    return 0;
}
