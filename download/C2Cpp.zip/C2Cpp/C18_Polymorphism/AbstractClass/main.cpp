//Project - AbstractClass
#include <iostream>
#include <memory>
using namespace std;

class Pet {
protected:
    string sName;
public:
    void virtual speak() = 0;   //=0表示该函数为纯虚函数
    void virtual eat(int weight) = 0;
    Pet(const string& name):sName(name){}
    virtual ~Pet(){}
};

class Rabbit:public Pet {
public:
    void speak(){
        cout << "Hello from rabbit " << sName << endl;
    }

    void eat(int weight){
        cout << "Rabbit " << sName << " ate " << weight << " gram's food.\n";
    }

    Rabbit(const string& name):Pet(name){}
};

class Cat:public Pet{
public:
    void eat(int weight){
        cout << "Cat " << sName << " ate " << weight << " gram's food.\n";
    }

    Cat(const string& name):Pet(name){}
};

class DragonLi:public Cat{
public:
    void speak(){
        cout << "Hello from dragonli cat " << sName << endl;
    }

    DragonLi(const string& name):Cat(name){}
};

class Persian:public Cat{
public:
    void speak(){
        cout << "Hello from persian cat " << sName << endl;
    }

    Persian(const string& name):Cat(name){}
};

int main() {
    //Pet p("Emily");
    //Pet* p = new Pet("Emily");    //错误：抽象类不可以实例化
    Pet* r = new Rabbit("Eddie");
    r->eat(100);
    r->speak();
    delete r;

    //Cat c("Lucy");
    //Pet* c = new Cat("Lucy");     //错误：抽象类Cat不可以实例化
    shared_ptr<Pet> c1(new DragonLi("Happy"));
    unique_ptr<Cat> c2(new Persian("Socks"));
    c1->eat(100);
    c1->speak();
    c2->eat(100);
    c2->speak();

    return 0;
}
