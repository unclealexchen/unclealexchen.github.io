//Project - ConstCast
#include <iostream>
using namespace std;

class Cat{};

int main() {
    const Cat cat;
    Cat& c = const_cast<Cat&>(cat); //const Cast --> Cat&

    const int v = 777;
    int v1 = v;                     //const int --> int,无转换必要
    int& r = const_cast<int&>(v);   //const int --> int&
    int* p = const_cast<int*>(&v);  //const int* --> int*

    return 0;
}
