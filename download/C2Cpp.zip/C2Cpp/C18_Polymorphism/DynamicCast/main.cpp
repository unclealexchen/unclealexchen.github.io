//Project - DynamicCast
#include <iostream>
using namespace std;

class Pet{public: virtual ~Pet(){}};   //Pet父类有虚函数
class Cat:public Pet{
public:
    void sayHello(){
        cout << "meow" << endl;
    }
};
class Dog:public Pet{};

int main() {
    Pet* p = new Cat();
    Cat* c = dynamic_cast<Cat*>(p);	   //转换失败会返回一个nullptr
    if (c){
        c->sayHello();
    }

    Cat& c1 = dynamic_cast<Cat&>(*p);  //转换失败会抛出一个std::bad_cast异常
    c1.sayHello();

    delete p;
    return 0;
}
