//Project - LateBinding
#include <iostream>
using namespace std;

class Pet {
public:
    string sName;
    virtual void sayHello() {
        cout << "Pet " << sName << " : hello" << endl;
    }

    virtual void eat(int weight){
        cout << "Pet: I ate " << weight << " gram's food.\n";
    }

    Pet(const string& name):sName(name){}
    virtual ~Pet(){
        cout << "Pet destructor: " << sName << endl;
    }
};

class Rabbit:public Pet {
public:
    void sayHello(){
        cout << "Rabbit " << sName << " : woof" << endl;
    }

    void eat(int weight){
        cout << "Rabbit: " << weight << " gram's food is not enough!\n";
    }

    Rabbit(const string& name):Pet(name){}
    ~Rabbit(){
        cout << "Rabbit destructor: " << sName << endl;
    }
};

class Cat:public Pet {
public:
    void sayHello(){
        cout << "Cat " << sName << " : meow " << endl;
    }

    Cat(const string& name):Pet(name){}
    ~Cat(){
        cout << "Cat destructor: " << sName << endl;
    }
};

int main(){
   Pet* pets[3] = {nullptr};
   pets[0] = new Pet("Emily");
   pets[1] = new Cat("Lucy");
   pets[2] = new Rabbit("Charlie");

   for (auto x:pets){
       x->sayHello();
       x->eat(100);
       delete x;
   }
   return 0;
}

