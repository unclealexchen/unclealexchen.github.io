//Project - RabbitOrCat
#include <iostream>
#include <string>
using namespace std;

class Pet {
public:
    string sName;
    void sayHello() {
        cout << "Pet " << sName << " : hello" << endl;
    }

    Pet(const string& name):sName(name){}
    ~Pet(){
        cout << "Pet destructor: " << sName << endl;
    }
};

class Rabbit:public Pet {
public:
    void sayHello(){
        cout << "Dog " << sName << " : woof" << endl;
    }

    Rabbit(const string& name):Pet(name){}
    ~Rabbit(){
        cout << "Rabbit destructor: " << sName << endl;
    }
};

class Cat:public Pet {
public:
    void sayHello(){
        cout << "Cat " << sName << " : meow " << endl;
    }

    Cat(const string& name):Pet(name){}
    ~Cat(){
        cout << "Cat destructor: " << sName << endl;
    }
};


int main() {
    cout << "What are you need ?  rabbit or cat ?";
    string s;
    cin >> s;

    Pet* p = nullptr;
    if (s=="rabbit")
        p = new Rabbit("Charlie");
    else
        p = new Cat("Lucy");

    p->sayHello();
    delete p;
    return 0;
}
