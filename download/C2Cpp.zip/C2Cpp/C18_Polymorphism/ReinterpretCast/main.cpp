//Project - ReinterpretCast
#include <iostream>
using namespace std;

int main(){
    unsigned int v = 0x11223344;
    unsigned char* rawBytes = reinterpret_cast<unsigned char*>(&v);
    printf("bytes of v: %x - %x - %x - %x",
           rawBytes[0],rawBytes[1],rawBytes[2],rawBytes[3]);
    return 0;
}
