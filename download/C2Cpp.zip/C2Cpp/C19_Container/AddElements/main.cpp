//Project - AddElements
#include <iostream>
#include <list>
#include <vector>
using namespace std;

template <typename T>
void output(T begin, T end, const string& sTitle){
    cout << "----------" << sTitle << "------------\n";
    while (begin!=end)
        cout << *begin++ << ",";
    cout << endl;
}

int main() {
    vector<int> a {0,1,2,3,4,5};
    a.insert(a.cbegin()+4,10);
    a.insert(a.cbegin()+2,3,100);
    a.insert(a.cbegin()+3,{97,98,99});
    a.emplace(a.cbegin()+5, 999);
    output(a.cbegin(),a.cend(),"vector<int> a");

    list<int> b {0,0,0,0,0};
    auto it = b.cbegin();
    it++;
    b.insert(it, a.cbegin()+2, a.cbegin()+7);
    output(b.cbegin(),b.cend(),"list<int> b");
    return 0;
}
