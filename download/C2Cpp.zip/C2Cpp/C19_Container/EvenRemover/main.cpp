//Project - EvenRemover
#include <iostream>
#include <list>
#include <deque>
using namespace std;

template <typename T>
void output(T begin, T end, const string& sTitle){
    cout << "----------" << sTitle << "------------\n";
    while (begin!=end)
        cout << *begin++ << ",";
    cout << endl;
}

template <typename T>
void evenRemover(T& c){
    auto it = c.begin();
    while (it!=c.end()){       //检查it是否等于尾后迭代器
        if (*it % 2 == 0)
            it = c.erase(it);  //发现偶数，删除并移至下一个元素
        else
            ++it;              //不是偶然，移至下一个元素
    }
}

int main() {
    list<int> a {0,1,2,3,4,5,6,7,8,9};
    evenRemover(a);
    output(a.cbegin(),a.cend(),"list<int> a");

    deque<int> b {0,1,2,3,4,5,6,7,8,9};
    evenRemover(b);
    output(b.cbegin(),b.cend(),"deque<int> b");
    return 0;
}
