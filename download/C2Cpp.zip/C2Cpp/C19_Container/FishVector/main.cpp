//Project - FishVector
#include <iostream>
#include <vector>
using namespace std;

class Fish{
    string sNumber;
public:
    Fish(){
        static int i = 0;
        sNumber = std::to_string(i++);
        cout << "Fish constructor: " << sNumber << endl;
    }

    Fish(const Fish& r){
        sNumber = r.sNumber + "[Copy]";
        cout << "Fish copy constructor: " << sNumber << endl;
    }

    ~Fish(){ cout << "Fish destructor: " << sNumber << endl; }
};

int main(){
    vector<Fish> f(2);    //0,1号鱼
    printf("f.capacity = %d, f.size = %d\n",f.capacity(),f.size());
    Fish f2;              //2号鱼
    cout << "-------------f.push_back(f2)----------" << endl;
    f.push_back(f2);
    printf("f.capacity = %d, f.size = %d\n",f.capacity(),f.size());
    cout << "vector f is " << (f.empty()?"empty.\n":"not empty.\n");
    cout << "-------------f.pop_back()-------------" << endl;
    f.pop_back();
    cout << "-------------f.resize(1)--------------" << endl;
    f.resize(1);
    cout << "-------------f.clear()----------------" << endl;
    f.clear();
    return 0;
}







