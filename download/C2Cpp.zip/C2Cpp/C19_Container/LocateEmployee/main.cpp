#include <iostream>
#include <vector>
using namespace std;

class Employee{ public: string sNo,sName; int iAge; };

int main() {
    vector<Employee> employees {
        {"10000","Jack Ma",47},
        {"10001","Mary Lee",25},
        {"10002","Tom Henry",28},
        {"10003","Dora Chen",32}
    };

    for (const auto& e:employees){
        if (e.sNo == "10003"){
            cout << "The designated employee have been found.\n";
            cout << e.sName << endl;
            cout << e.iAge << endl;
            break;
        }
    }
    return 0;
}
