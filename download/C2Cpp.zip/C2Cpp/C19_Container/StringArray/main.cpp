//Project - StringArray
#include <iostream>
#include <array>
#include <vector>
using namespace std;

int main(){
    array<string,3> a1 {"Tom","Dora","Eddie"};
    auto a2 = a1;
    a1[1] = "Charlie";   //a1.at(1) = "Charlie";

    cout << "a1: ";
    for (auto x:a1)
        cout << x << ", ";

    cout << "\na2: ";
    for (auto x:a2)
        cout << x << ", ";

    cout << "\na1 == a2: " << (a1==a2?"True":"False") << endl;
    cout <<   "a1 != a2: " << (a1!=a2?"True":"False") << endl;
    cout <<   "a1 >  a2: " << (a1> a2?"True":"False") << endl;
    cout <<   "a1 <  a2: " << (a1< a2?"True":"False") << endl;
    return 0;
}
