//Project - StringIterator
#include <iostream>
using namespace std;

int main() {
    string s = "Run, Forrest";

    auto it = s.begin();  //string::iterator
    while (it!=s.end()){   //end() 尾后迭代器
        *it = toupper(*it);
        it++;
    }

    cout << s << endl;
    return 0;
}
