//Project - StringList
#include <iostream>
#include <list>
using namespace std;

int main() {
    list<string> girls {"Dora", "Emily", "Cinderella"};
    girls.pop_back();
    girls.push_back("Angela");
    girls.emplace_front("Iris");
    girls.sort();

    for (auto& x:girls)
        cout << x << endl;
    return 0;
}
