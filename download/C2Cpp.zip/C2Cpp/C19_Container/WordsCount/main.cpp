//Project - WordsCount
#include <iostream>
#include <vector>
#include <fstream>
#include <assert.h>
using namespace std;

int main() {
    ifstream in("C:/C2Cpp/C19_Container/WordsCount/title.txt");
    vector<string> words;   //words[i]存放发现的第i个单词
    vector<int> counts;     //counts[i]存放words[i]在诗中的出现次数

    string sWord;
    while (in >> sWord){    //operator>>(in,sWord)
        for (size_t i=0;i<words.size();i++){
            if (words[i]==sWord){
                counts[i]++;
                sWord = "";
                break;
            }
        }
        if (sWord!=""){
            words.push_back(sWord);
            counts.push_back(1);
        }
    }

    assert(words.size()==counts.size());//断言向量words及counts长度相等
    for (size_t i=0;i<words.size();i++){
        cout << words[i] << ":" << counts[i] << ", ";
    }

    return 0;
}
