//Project - WordsStat
#include <iostream>
#include <unordered_map>
#include <unordered_set>
#include <algorithm>
using namespace std;

int main() {
    unordered_set<string> excludes {"the","but","and","or", "an", "a"};
    unordered_map<string,int> wordsStat;

    string sWord;
    while (cin>>sWord){
        transform(sWord.begin(),sWord.end(),sWord.begin(),::tolower);
        if (excludes.count(sWord)==0)
            wordsStat[sWord]++;
    } //输入Ctrl + Z以及Enter结束循环

    for (auto& x:wordsStat)
        cout << x.first << " - " << x.second << endl;

    return 0;
}
