//Project - BoolType
#include <iostream>
using namespace std;

int main(){
    bool a = 3 > 2;
    bool b = false;

    cout << "value of a: " << a << ",value of b: " << b << endl;
    cout << "int(true): " << int(true) << ",int(false): " << int(false) << endl;

    if (-0.00000012)
        cout << "-0.00000012 is true." << endl;

    if (2*2-4)
        cout << "2*2-4 is true." << endl;
    else
        cout << "2*2-4 is false." << endl;

    return 0;
}
