//Project - CharLiteral
#include <iostream>
using namespace std;

int main(){
    cout << "I told you, \"C/C++ is hard to learn\"." << '\n';
    cout << "When you need a \\ in string, put \\\\ in your code." << "\n";
    cout << "Popular languages:\n\tJavaScript\n\tPython\n\tJava\n\tC\n\tC++\n\tRuby";
    return 0;
}
