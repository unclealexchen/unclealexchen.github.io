//Project - CharType
#include <iostream>
#include <climits>
using namespace std;

int main(){
    cout << "Number of bits: " << CHAR_BIT << endl;
    cout << "Range of signed char: " << CHAR_MIN << " ~ " << CHAR_MAX << endl;
    cout << "Range of unsigned char: " << 0 << " ~ " << UCHAR_MAX << endl;

    char c = 'c';
    cout << "ASCII code of 'c': " << (int)c << endl;
    c += 1;
    cout << "'c' + 1 = " << c << endl;

    c = 250;
    cout << "signed char with value 250: " << int(c) << endl;

    unsigned char uc = 250;
    cout << "unsigned char with value 250: " << int(uc) << endl;

    return 0;
}
