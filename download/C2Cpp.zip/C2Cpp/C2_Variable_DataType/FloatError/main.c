//Project - FloatError
#include <stdio.h>

int main(){
    float f = 0.00001;
    printf("The stored value of 0.00001 with float:   %.30f\n",f);

    double d = 0.00001;
    printf("The stored value of 0.00001 with double:   %.30f\n",d);

    if (f==0.00001)
        printf("f == 0.00001");
    else
        printf("f <> 0.00001");

    return 0;
}
