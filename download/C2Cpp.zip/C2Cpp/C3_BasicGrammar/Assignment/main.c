//Project - Assignment
#include <stdio.h>

int main(){
    int a, b;
    a = b = 3;
    printf("a = %d, b = %d.\n",a,b);

    if (a=4)
        printf("a is equal to 4.");
    else
        printf("a is not equal to 4.");

    return 0;
}
