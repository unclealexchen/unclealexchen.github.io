//Project - ChangePrecedence
#include <stdio.h>

int main(){
    int r = 3 + 2 && 0;
    printf("3 + 2 && 0 = %d\n",r);

    r = (3 + 2) && 0;
    printf("(3 + 2) && 0 = %d\n",r);

    r = 3 + (2 && 0);
    printf("3 + (2 && 0) = %d\n",r);
    return 0;
}
