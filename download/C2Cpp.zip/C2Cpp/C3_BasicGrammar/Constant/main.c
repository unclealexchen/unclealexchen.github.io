//Program - Constant
#include <stdio.h>

#define PI 3.1415926

int main(){
    float r = 2;
    const float CPI = 3.1415926f;
    //CPI = 4;      //常量不能修改

    printf("Area of circle = %.2f\n", PI*r*r);
    printf("Area of circle = %.2f", CPI*r*r);
    return 0;
}
