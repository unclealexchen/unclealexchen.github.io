//Project - DefFunc
#include <stdio.h>

//电费计算: (期末读数 - 期初读数) * 单价
float costCompute(int iStart, int iEnd)
{
    int iConsume = iEnd - iStart;
    return iConsume * 0.85f;
}

int main(){
    float fElecFee1 = costCompute(1201,1786);
    printf("Electronic Power Cost of Mr Zhang: %.2f\n", fElecFee1);

    float fElecFee2 = costCompute(1322,1423);
    printf("Electronic Power Cost of Mr Lee: %.2f", fElecFee2);

    return 0;
}
