//Project - DivisionOperator
#include <iostream>
using namespace std;

int main(){
    int i = 3;                     //有符号整数

    auto a = 10 / i;               //整数 / 整数 = 整数
    cout << "10/3 = " << a << ", type = " << typeid(a).name() << endl;

    auto b = double(10.0) / i;     //浮点数 / 整数 = 浮点数
    cout << "10.0/3 = " << b << ", type = " << typeid(b).name() << endl;

    auto c = i / double(10.0);     //整数 / 浮点数 = 浮点数
    cout << "3/10.0 = " << c << ", type = " << typeid(c).name() << endl;

    auto d = double(10.0) / 3.0f;  //双精度浮点数 / 单精度浮点数 = 双精度浮点数
    cout << "10.0/3.0f = " << d << ", type = " << typeid(d).name() << endl;

    auto e = (unsigned int)10 / i; //无符号整数 / 有符号整数 = 无符号整数
    cout << "unsigned 10/3 = " << e << ", type = " << typeid(e).name() << endl;

    auto f = 10 / (unsigned int)3; //有符号整数 / 无符号整数 = 无符号整数
    cout << "10/unsigned 3 = " << f << ", type = " << typeid(f).name() << endl;

    return 0;
}
