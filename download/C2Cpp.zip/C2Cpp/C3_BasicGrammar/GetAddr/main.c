//Project - GetAddr
#include <stdio.h>

int main(){
    int i = 1, j = 2;
    char c = 'c';
    long double ld = 0.0;

    printf("&i=%p, &j=%p, &c=%p, &ld=%p",&i,&j,&c,&ld);
    return 0;
}
