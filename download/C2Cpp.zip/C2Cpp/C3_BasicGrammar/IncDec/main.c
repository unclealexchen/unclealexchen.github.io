//Project - IncDec
#include <stdio.h>

int main(){
    int a = 10, b, c;
    b = a++;    //先取值，后递增，a改为11，b得递增之前的值10
    c = ++a;    //先递增，后取值，a改为12，c得递增之后的值12
    printf("a = %d, b = %d, c = %d.\n",a,b,c);

    float f = 10.1f, g, h;
    g = f--;    //先取值，后递减
    h = --f;    //先递减，后取值
    printf("f = %f, g = %f, h = %f.",f,g,h);

    return 0;
}
