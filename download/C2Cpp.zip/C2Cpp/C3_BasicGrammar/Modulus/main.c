//Project - Modulus
#include <stdio.h>

int main(){
    int a = 10;
    int b = a % 7;
    printf("%d is an %s number.", b, b%2==0?"even":"odd");
    return 0;
}
