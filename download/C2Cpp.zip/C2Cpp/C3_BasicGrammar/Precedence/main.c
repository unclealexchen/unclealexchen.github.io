//Project - Precedence
#include <stdio.h>

int main(){
    int n = 3 + 2 * 6 / 3;
    printf("%d\n",n);

    n = (3 + 2) * 6 / 3;
    printf("%d\n",n);
    return 0;
}
