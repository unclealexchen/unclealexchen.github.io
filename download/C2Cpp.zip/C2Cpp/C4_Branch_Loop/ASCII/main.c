//Project - ASCII
#include <stdio.h>
#include <conio.h>

int main() {
    char c = 0;

    for (; c = getch(), c!=13 && c!=10;) { //初始化语句为空，更新表达式空缺
        putch(c);
        printf(" %d ",c);
    }

    printf("\nProgram exited!\n");
    return 0;
}
