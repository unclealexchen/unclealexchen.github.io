//Project - BreakExample
#include <stdio.h>
#include <stdbool.h>

bool isPrime(int n) {     //函数的定义
    if (n<=1)
        return false;
    for (int i=2;i<n;i++)
        if (n % i == 0)
            return false;

    return true;
}

int main(){
    printf("Try to find first prime number(>=10000):\n");

    int iPrime = -1;
    for (int i=10000;;i++){
        if (isPrime(i)){
            iPrime = i;
            break;
        }
        printf("%d checked, not prime number.\n",i);
    }

    printf("First prime number(>=10000) is: %d.",iPrime);
    return 0;
}
