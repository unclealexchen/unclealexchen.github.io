//Project - DebugExample
#include <stdio.h>
#include <stdbool.h>

bool isPrime(int n) {     //函数的定义
    if (n<=1)
        return false;
    for (int i=2;i<n;i++)
        if (n % i == 0)
            return false;

    return true;
}

int main(){
    printf("Try to find all prime number(<=10):\n");

    int iFound = 0;       //发现的质数个数
    for (int i=2;
         i<=10;
         i++)
    {
        if (!isPrime(i))
            continue;
        iFound++;
        printf("%d, ",i);
    }

    printf("\n%d prime numbers been found.",iFound);
    return 0;
}
