//Project - Everest
#include <stdio.h>

int main() {
    int iCounter = 0;              //对折次数
    float fThickness = 0.0001F;    //纸厚，单位米

    while (1){
        if (fThickness > 8844.43F) //超过珠峰高度就停止循环
            break;
        else{
            fThickness *= 2;       //对折一次厚度翻倍
            iCounter++;            //对折次数加1
        }
    }

    printf("Thickness = %.2f after %d folds, exceeding Everest.",
           fThickness,iCounter);
    return 0;
}
