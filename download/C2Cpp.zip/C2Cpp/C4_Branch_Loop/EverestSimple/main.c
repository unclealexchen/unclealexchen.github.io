//Project - EverestSimple
#include <stdio.h>
#include <math.h>    //引入log2()函数

int main(){
    double t = log2(8844.43/0.0001);
    printf("%f",t);

    printf("\n%f",0.0001 * pow(2,27));
    return 0;
}
