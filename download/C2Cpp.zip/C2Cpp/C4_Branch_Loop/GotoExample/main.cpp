//Project - GotoExample
#include <iostream>
using namespace std;

int main(){
    int i {1};
    int sum {0};

    loop:
        sum += i;
        i++;
    if (i<=100)
        goto loop;

    cout << "sum = " << sum << endl;
    return 0;
}
