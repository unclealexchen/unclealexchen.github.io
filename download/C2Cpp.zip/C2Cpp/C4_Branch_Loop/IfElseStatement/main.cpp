//Project - IfElseStatement
#include <iostream>
using namespace std;

int main() {
    int iYear {};

    cout << "Please enter the year:" << endl;
    cin >> iYear;

    if ((iYear%4==0 && iYear%100!=0) || (iYear%400==0)){
        cout << iYear << " is leap year." << endl;
        cout << "There are 29 days in February of " << iYear << ".\n";
    }
    else
        cout << iYear << " is not leap year." << endl;

    return 0;
}

