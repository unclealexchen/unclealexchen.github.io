//Project - IfStatement
#include <stdio.h>

int main(){
    int iAge = 0;
    printf("Hey, how old are you ? boy.\n");
    scanf("%d",&iAge);

    if (iAge>=18)   //括号()必须
        printf("You are legally an adult.\n");

    if (iAge>=22){
        printf("Congratulations, son!\n");
        printf("You are of legal age for marriage.\n");
    }

    return 0;
}
