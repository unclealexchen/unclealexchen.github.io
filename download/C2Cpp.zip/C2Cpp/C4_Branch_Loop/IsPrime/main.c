//Project - IsPrime
#include <stdio.h>
#include <stdbool.h>

bool isPrime(int);         //函数的声明

int main(){
    printf("sizeof(bool) = %lld.\n",sizeof(bool));

    printf("isPrime(-2):\t%s.\n", isPrime(-2)?"Yes":"No");
    printf("isPrime(3):\t%s.\n", isPrime(3)?"Yes":"No");
    printf("isPrime(4):\t%s.\n", isPrime(4)?"Yes":"No");
    printf("isPrime(117):\t%s.\n", isPrime(117)?"Yes":"No");
    return 0;
}

bool isPrime(int n) {     //函数的定义
    if (n<=1)
        return false;
    for (int i=2;i<n;i++)
        if (n % i == 0)
            return false;

    return true;
}


