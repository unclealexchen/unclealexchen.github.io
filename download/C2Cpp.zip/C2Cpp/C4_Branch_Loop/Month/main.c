//Month
#include <stdio.h>

int main() {
    int iMonth = 1;
    printf("Please input month number(1~12):");
    scanf("%d",&iMonth);

    switch (iMonth){
    case 1:
    case 3:
    case 5:
    case 7:
    case 8:
    case 10:
    case 12:
        printf("There are 31 days in %dth month.\n",iMonth);
        break;
    case 2:
        printf("There are 28 or 29 days in %dth month.\n",iMonth);
        //break;  //break缺失
    case 4:
    case 6:
    case 9:
    case 11:
        printf("There are 30 days in %dth month.\n",iMonth);
        break;
    default:
        printf("Wrong month number.\n");
    }

    return 0;
}
