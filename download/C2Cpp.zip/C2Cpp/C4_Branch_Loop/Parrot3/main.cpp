//Project - Parrot3
#include <iostream>
#include <string>

int main(){
    using namespace std;

    cout << "I am a parrot, say something to me." << endl;
    string s = "";

    do {
        getline(cin,s);
        cout << s << endl;
    }
    while (s!="q");

    cout << "Bye, see you later." << endl;

    return 0;
}
