//Project - RangeFor
#include <iostream>
using namespace std;

int main() {
    float fPrices[] {1030.23f, 2828.12f, 76.0f, 992.0f}; //2月18日的商品价格

    int idx = 0;
    cout << "idx\t2/18\t2/19\n";
    cout << "----------------------------\n";
    for (auto x:fPrices)
        cout << ++idx << "\t" << x << "\t" << x*1.1f << endl;

    for (int x:{1,3,5,7,9})
        cout << x << " ";

    return 0;
}
