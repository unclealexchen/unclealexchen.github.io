//Project - SimplestFor
#include <stdio.h>

int main() {
    int iSum = 0;

    for (int i=0;i<3;i++){
        printf("loop i = %d\n",i);
        iSum += i;
    }

    printf("sum = %d",iSum);
    return 0;
}
