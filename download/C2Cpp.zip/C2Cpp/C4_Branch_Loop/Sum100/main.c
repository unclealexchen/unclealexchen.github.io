//Project - Sum100
#include <stdio.h>

int main(){
    int iSum = 0, i = 0;
    for (i=1;i<100;i++)
        iSum += i;

    printf("sum = %d, i = %d.",iSum,i);
    return 0;
}
