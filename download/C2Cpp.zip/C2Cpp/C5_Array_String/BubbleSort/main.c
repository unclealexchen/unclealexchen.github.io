//Project - BubbleSort
#include <stdio.h>

void bubbleSort(int a[], const int n){
    for (int i=n-1;i>0;i--)
        for (int j=0;j<i;j++){
            if (a[j] > a[j+1]){
                int t = a[j];
                a[j] = a[j+1];
                a[j+1] = t;
            }
        }
}

int main() {
    int data[] = {3,9,1,4,7,6,5,8,2};
    bubbleSort(data,9);

    printf("Sorted array: ");
    for (int i=0;i<9;i++)
        printf("%d,",data[i]);

    return 0;
}
