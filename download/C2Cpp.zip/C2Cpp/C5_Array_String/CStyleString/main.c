//Project - CStyleString
#include <stdio.h>

int main() {
    char s1[] = "hello";
    printf("s1 = %s, addr = %p, sizeof s1: %lld\n", s1, s1, sizeof s1);
    printf("s1 = %d %d %d %d %d %d\n",s1[0],s1[1],s1[2],s1[3],s1[4],s1[5]);

    char s2[256] = "forrest";
    int i = 0;
    while (s2[i]!=0){
        s2[i] = s2[i] + ('A' - 'a');
        i++;
    }
    printf("s2 = %s, addr = %p, sizeof s2: %lld\n", s2, s2, sizeof s2);

    printf("'A' = %d,  'a' = %d",'A','a');
    return 0;
}
