//Project - CppString1
#include <iostream>
#include <string>
using namespace std;

int main() {
    string s1 {"hello"};

    for (unsigned int i=0;i<s1.size();i++)
        s1[i] += ('A' - 'a');
    cout << "s1 = " << s1 << ", size = " << s1.size()
         << ", sizeof(s1) = " << sizeof(s1) << endl;

    string s2 = " World!";
    string s3 = s1 + s2;
    s1 += s2;
    s2 = "Hello" + s2;
    cout << "s1 = " << s1 << " s2 = " << s2 << " s3 = " << s3 << endl;

    string s4 = "Life is a box of chocolates, you...";
    cout << "s4.substr(17,10) = " << s4.substr(17,10) << endl;

    auto iPos = s4.find("chocolates");
    cout << "s4.find(\"chocolates\") = " << iPos << endl;

    s4.replace(iPos,10,"CHOCOLATES");
    cout << "s4 after replace = " << s4 << endl;

    return 0;
}
