//Project - Scores
#include <stdio.h>

int main() {
    float scores[5] = {77,92.5,68,99,100};
    scores[0] = 88;

    printf("sizeof(scores) = %lld\n", sizeof(scores));
    printf("scores = %p\n",scores);
    printf("%p - %p - %p - %p - %p\n", &scores[0], &scores[1],
            &scores[2], &scores[3], &scores[4]);

    float fSum  = 0;
    for (int i=0;i<5;i++)
        fSum += scores[i];

    float fAverage = fSum / 5;
    printf("Average score = %.2f",fAverage);

    return 0;
}
