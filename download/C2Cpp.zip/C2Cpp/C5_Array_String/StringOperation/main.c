//Project - StringOperation
#include <stdio.h>
#include <string.h>

int main() {
    char s1[256] = "Hello";
    printf("s1 = %s, len = %lld\n",s1, strlen(s1));

    char s2[512] = "World";
    printf("strcmp(s1,s2) = %d\n",strcmp(s1,s2));

    char s3[512];
    strcat(s1," ");   //给s1附加一个空格
    strcat(s1,s2);
    strcpy(s3,s1);
    printf("s1 = %s, s2 = %s, s3 = %s",s1,s2,s3);

    return 0;
}
