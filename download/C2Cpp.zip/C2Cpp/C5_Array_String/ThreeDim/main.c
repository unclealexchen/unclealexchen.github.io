//Project - ThreeDim
#include <stdio.h>

int main(){
    short a[2][2][3] = {
        {
            {0,1,2},
            {10,11,12}
        },
        {
            {100,101,102},
            {110,111,112}
        }
    };

    printf("a = %p, sizeof(a) = %lld\n",a,sizeof(a));
    printf("a[1][1][1] = %d",a[1][1][1]);
    return 0;
}
