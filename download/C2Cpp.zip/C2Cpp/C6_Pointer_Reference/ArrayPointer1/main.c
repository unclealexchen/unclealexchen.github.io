//Project - ArrayPointer1
#include <stdio.h>
#include <stdlib.h>

int main(){
    float scores[5] = {55,66,77,88,99};
    float* p1 = scores;       //把数组名赋值给指针
    printf("sizeof(scores) = %lld,  sizeof(p1) = %lld\n",sizeof(scores),sizeof(p1));

    float* p2 = (float*)malloc(sizeof(float)*5);  //申请分配20字节的内存
    if (p2==NULL)
        exit(EXIT_FAILURE);

    float fSum = 0;
    for (unsigned int i=0;i<5;i++){
        p2[i] = p1[i];       //指针当成数组用
        fSum += p2[i];
    }

    printf("Average = %f",fSum/5);

    free(p2);                //释放申请的内存
    return 0;
}
