//Project - CallByValue
#include <stdio.h>

void swap1(int a, int b){
    printf("before swap in swap1: ");
    printf("&a = %p, &b = %p, a = %d, b = %d\n", &a, &b, a, b);
    int t = a;
    a = b;
    b = t;
    printf("after swap in swap1: ");
    printf("&a = %p, &b = %p, a = %d, b = %d\n", &a, &b, a, b);
}

int main() {
    int m = 2, n = 7;
    printf("before function call: ");
    printf("&m = %p, &n = %p, m = %d, n = %d\n", &m, &n, m, n);
    swap1(m,n);
    printf("after function call: ");
    printf("&m = %p, &n = %p, m = %d, n = %d\n", &m, &n, m, n);
    return 0;
}
