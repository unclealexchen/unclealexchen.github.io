//Project - NullPointer
#include <stdio.h>

int main() {
    double d = 3.14;
    double* p = NULL;     //等价于double *p = (double*)0;
    printf("p = NULL = %p\n", p);
    //*p = 3.14 + 1;      //对一个空指针应用间接操作符会引发执行错误

    p = &d;
    printf("p = &d = %p, *p = d = %f", p, *p);
    return 0;
}
