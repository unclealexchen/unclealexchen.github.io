//Project - NullPtr
#include <iostream>
#include <stdio.h>
using namespace std;

int main() {
    char c {'c'};
    char* p {nullptr};

    printf("p = nullptr = %p\n", p);
    p = &c;
    printf("p = &c = %p, c = %c, *p = %c", p, c, *p);

    return 0;
}
