//Project - Pointer2Pointer
#include <stdio.h>

int main(){
    int a = 100;
    int *p = &a;
    int **pp = &p;

    printf("&a = %p, p = %p\n", &a, p);   //p的值为a的地址
    printf("&p = %p, pp = %p\n", &p, pp); //pp的值为p的地址
    printf("&pp = %p\n", &pp);
    printf("before: a = %d, *p = %d, **pp = %d\n", a, *p, **pp);

    a++;
    (*p)++;
    **pp = **pp + 1;

    printf("after: a = %d, *p = %d, **pp = %d\n", a, *p, **pp);
    return 0;
}
