//Project - PointerOperation1
#include <stdio.h>
#include <stdlib.h>

int main(){
    float* p = (float*)calloc(10,sizeof(float));
    if (p==NULL)
        exit(1);

    printf("p = %p,  p + 1 = %p,  p + 3 = %p\n", p, p+1, p+3);

    for (int i=0;i<10;i++)
        *(p++) = i;            //*p1++结果相同
    p-=10;
    printf("p[0] = %f,  p[3] = %f,  p[9] = %f\n", *p,  *(p+3), *(p+9));

    free(p);

    return 0;
}
