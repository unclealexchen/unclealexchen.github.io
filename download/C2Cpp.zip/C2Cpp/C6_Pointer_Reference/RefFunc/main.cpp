//Project - RefFunc
#include <iostream>
#include <stdio.h>
using namespace std;

void swap1(float& a, float& b){
    printf("&a = %p, &b = %p\n", &a, &b);

    float t = a;
    a = b;
    b = t;
}

int main() {
    float m = 1.1f, n = 9.9f;

    printf("&m = %p, &n = %p\n", &m, &n);
    swap1(m,n);

    cout << "after swap1: m = " << m << ", n = " << n;
    return 0;
}
