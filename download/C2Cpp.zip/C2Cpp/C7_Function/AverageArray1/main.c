//Project - AverageArray1
#include <stdio.h>

float average(const float *a, const unsigned int n){
    printf("a = %p\n",a);

    float fSum = 0;
    for (unsigned int i=0;i<n;i++)
        fSum += a[i];

    return fSum / n;
}

int main() {
    float scores[5] = {50,60,70,80,90};
    printf("scores = %p\n",scores);

    float fAvg = average(scores,5);

    printf("average = %f",fAvg);
    return 0;
}
