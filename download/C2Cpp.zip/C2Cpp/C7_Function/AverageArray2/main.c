//Project - AverageArray2
#include <stdio.h>

float average(const float a[][3], const unsigned int n){
    float fSum = 0;
    for (unsigned int i=0;i<n;i++)
        for (unsigned int j=0;j<3;j++)
            fSum += a[i][j];

    return fSum / (n*3);
}

float average2(const float (*a)[3], const unsigned int n){
    float fSum = 0;
    for (unsigned int i=0;i<n;i++)
        for (unsigned int j=0;j<3;j++)
            fSum += a[i][j];

    return fSum / (n*3);
}

int main() {
    float scores[2][3] = {
        {50,60,70},
        {80,90,100}
    };

    float fAvg = average2(scores,2);

    printf("Average = %f", fAvg);
    return 0;
}
