//Project - Factorial
#include <stdio.h>

long long factorial(int n){
    printf("factorial(%d) is called, &n = %p\n", n, &n);
    if (n==1)
        return 1;
    long long r = n * factorial(n-1);
    return r;
}

int main() {
    printf("6! = %lld", factorial(6));
    return 0;
}
