//Project - FuncParameter
#include <stdio.h>

float PI = 3.1415926F;

float getCircleArea(float r){
    printf("getCircleArea: &r = %p\n", &r);
    return PI * r * r;
}

int main() {
    float r = 4;
    printf("main: &r = %p\n", &r);

    float fArea = getCircleArea(r);

    printf("fArea = %f",fArea);
    return 0;
}
