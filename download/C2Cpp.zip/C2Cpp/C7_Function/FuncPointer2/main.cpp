//Project - FuncPointer2
#include <iostream>
#include <string>
using namespace std;

void bubbleSort(string a[],const int n,bool (*bigger)(const string&, const string&)){
    for (int i=n-1;i>0;i--)
        for (int j=0;j<i;j++){
            if (bigger(a[j],a[j+1])){
                auto t = a[j];
                a[j] = a[j+1];
                a[j+1] = t;
            }
        }
}

bool biggerThan1(const string& a, const string& b){
    return a > b;
}

bool biggerThan2(const string& a, const string& b){
    return a.size() > b.size();
}

int main() {
    string names[] {"China", "United States", "Russia", "Afghanistan"};

    bubbleSort(names, 4, biggerThan1);
    cout << "sorted1: " << names[0] << ", " << names[1]
         << ", " << names[2] << ", " << names[3] << endl;

    auto pf = biggerThan2;
    bubbleSort(names, 4, pf);
    cout << "sorted2: " << names[0] << ", " << names[1]
         << ", " << names[2] << ", " << names[3] << endl;

    bool (*pfarray[2])(const string&, const string&);
    pfarray[0] = biggerThan1;
    pfarray[1] = biggerThan2;
    pfarray[0]("China","India");

    typedef bool (*biggerFunc)(const string&, const string&);
    biggerFunc pfarray2[2];
    pfarray2[0] = biggerThan1;
    pfarray2[1] = biggerThan2;

    return 0;
}
