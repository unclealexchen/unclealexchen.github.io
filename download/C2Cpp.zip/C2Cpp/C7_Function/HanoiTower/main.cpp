//Project - HanoiTower
#include <iostream>
#include <vector>
#include <string>
using namespace std;

vector<string> steps;   //用于存放移盘序列的向量

void hanoi(int n, const char* a, const char* b, const char* c) {
    if (n==1)
        steps.push_back(string(a) + " --> " + c);
    else {
        hanoi(n-1, a, c, b);
        steps.push_back(string(a) + " --> " + c);
        hanoi(n-1, b, a, c);
    }
}

int main() {
    steps.clear();

    hanoi(5,"A","B","C");

    cout << "Steps count: " << steps.size() << endl;
    cout << "First 3 steps are: " << steps[0] << ", "
         << steps[1] << ", " << steps[2];
    return 0;
}

