//Project - MultiCall
#include <stdio.h>

inline static float average(float* a, int n) {
    float fSum = 0;
    for (int i=0;i<n;i++)
        fSum += a[i];
    return fSum/n;
}

int main() {
    float values[] = {0,1,2,3,4,5,6,7,8,9};

    float v4 = average(values,4);
    printf("v4 = %f\n",v4);

    float v7 = average(values,7);
    printf("v7 = %f\n",v7);

    float v10 = average(values,10);
    printf("v10 = %f\n",v10);

    return 0;
}
