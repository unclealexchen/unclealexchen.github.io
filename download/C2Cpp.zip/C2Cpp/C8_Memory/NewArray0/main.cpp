//Project - NewArray0
#include <iostream>
using namespace std;

int main() {
    float* a = new float[10]();         //全部初始化为0
    int* b = new int[10]();             //全部初始化为0
    //double* c = new double[20](3.3);  //错误，括号不能带参数

    for (int i=0;i<10;i++)
        cout << a[i] << ", " << b[i] << endl;

    return 0;
}
