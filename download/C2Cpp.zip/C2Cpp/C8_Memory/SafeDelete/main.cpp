//Project - SafeDelete
#include <iostream>
using namespace std;

template <typename T>
inline void safe_delete(T& p){
    delete p;
    p = nullptr;
}

int main(){
    float* p = new float;
    cout << "before safe_delete: " << p << endl;
    safe_delete(p);
    cout << "after safe_delete: " << p << endl;
    return 0;
}
