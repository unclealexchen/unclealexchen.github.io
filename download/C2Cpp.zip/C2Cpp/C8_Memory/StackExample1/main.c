//Project - StackExample1
#include <stdio.h>

void func(int b1, float b2, double b3){
    double b4 = b1 * b2 + b3;
    //...
}

int main() {
    int a1 = 1;
    float a2 = 2.1F;
    func(a1,a2,15.7);
    //...
    return 0;
}
