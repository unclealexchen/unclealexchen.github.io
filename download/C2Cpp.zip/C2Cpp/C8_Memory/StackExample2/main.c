//Project - StackExample2
#include <stdio.h>

void dummy(int i, int j){
    int k = i + j;
    printf("---------------dummy-------------\n");
    printf("&i = %p, &j = %p\n", &i, &j);
    printf("&k = %p, k = %d\n",&k, k);
}

void add(int d, int e, int f){
    int g = d + e;
    int h = f;
    printf("---------------add---------------\n");
    printf("&d = %p, &e = %p, &f = %p\n", &d, &e, &f);
    printf("&g = %p, &h = %p, sum = %d\n", &g, &h, g + h);
}

int main() {
    int a=1,b=1,c=1;
    printf("&a = %p, &b = %p, &c = %p\n", &a, &b, &c);
    add(a,b,c);
    dummy(a,b);
    add(a,b,c);

    return 0;
}
