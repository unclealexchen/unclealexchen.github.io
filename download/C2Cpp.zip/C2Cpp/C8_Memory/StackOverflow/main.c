//Project - StackOverflow
#include <stdio.h>

int main() {
    int a[8000][100];  //如果在你的计算机上运行正常，那试着把100改成10000
    printf("a[10][2] = %d, seems ok.",a[10][2]);
    return 0;
}
