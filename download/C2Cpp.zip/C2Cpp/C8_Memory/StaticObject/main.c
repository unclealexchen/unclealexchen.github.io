//Project - StaticObject
#include <stdio.h>

int iGlobal = 11;               //能够在整个应用程序的所有源代码文件中使用
static int iThisFileOnly = 22;  //只能在本文件中被使用

void func(){
    static int iCounter = 0;    //只能在本函数中被使用
    iCounter++;
    printf("func called: %d, &iCounter = %p\n", iCounter, &iCounter);
}

int main() {
    int iLocal = 33;
    printf("&iLocal = %p, iLocal = %d\n", &iLocal, iLocal);
    printf("&iGlobal = %p, iGlobal = %d\n", &iGlobal, iGlobal);
    printf("&iThisFileOnly = %p, iThisFileOnly = %d\n",
           &iThisFileOnly, iThisFileOnly);

    for (int i=0;i<5;i++)
        func();

    return 0;
}
