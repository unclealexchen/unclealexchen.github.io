//Project - BitOr
#include <iostream>
#include <bitset>
using namespace std;

int main() {
    unsigned short a = 0xf37a;
    unsigned short b = 0x79f6;

    unsigned short c = a | b;
    cout << "a     = " << bitset<16>(a) << endl;
    cout << "b     = " << bitset<16>(b) << endl;
    cout << "a | b = " << bitset<16>(c) << endl;

    cout << "a          = " << bitset<16>(a) << endl;
    cout << "0x0800     = " << bitset<16>(0x0800) << endl;
    a |= 0x0800;      //复合操作符，等价于a = a | 0x0800;
    cout << "a | 0x0800 = " << bitset<16>(a) << endl;

    return 0;
}
