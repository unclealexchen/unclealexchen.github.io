//Project - RightShift
#include <iostream>
#include <bitset>
using namespace std;

int main() {
    unsigned short a = 2368;
    cout << "a      = " << bitset<16>(a) << ", value = " << a <<endl;
    a = a >> 5;    //等价于 a >>= 5;
    cout << "a >> 5 = " << bitset<16>(a) << ", value = " << a << endl;
    return 0;
}
