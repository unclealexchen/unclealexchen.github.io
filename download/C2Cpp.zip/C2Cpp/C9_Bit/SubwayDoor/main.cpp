//Project - SubwayDoor
#include <iostream>
#include <bitset>
using namespace std;

void testDoorSensors(unsigned short s, bool r[]){
    for (int i=0;i<16;i++)
        r[i] = s & (0x01 << i);
}

int main() {
    unsigned short s = 0x4031;   //随意假设的测试值
    bool blocked[16];

    cout << "s = " << bitset<16>(s) << endl;
    testDoorSensors(s,blocked);
    for (int i=0;i<16;i++){
        if (blocked[i])
            cout << "Door " << i << " is blocked." << endl;
    }
    return 0;
}
