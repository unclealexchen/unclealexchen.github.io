#include <iostream>
#include <typeinfo>
#include <memory>
using namespace std;

class Pet {
protected:
    string sName;
public:
    void virtual speak() = 0;   //=0 纯虚函数 pure virtual function
    void virtual eat(int weight) = 0;
    Pet( const string& name):sName(name){}
    virtual ~Pet(){}
};

class Rabbit:public Pet{
public:
    void speak(){
        cout << "Hello from rabbit " << sName << endl;
    }

    void eat(int weight){
        cout << "Rabbit " << sName << " ate " << weight << " gram's food.\n";
    }

    Rabbit(const string& name):Pet(name){}
};


class Cat:public Pet{
public:
    void eat(int weight){
        cout << "Cat " << sName << " ate " << weight << " gram's food.\n";
    }

    Cat(const string& name):Pet(name){}
};


class DragonLi:public Cat {
public:
    void speak(){
        cout << "Hello from dargonli cat " << sName << endl;
    }

    DragonLi(const string& name):Cat(name){}
};


class Persian:public Cat{
public:
    void speak(){
        cout << "Hello from persian cat " << sName << endl;
    }

    Persian(const string& name):Cat(name){}
};


int main(){
    shared_ptr<Pet> c1(new DragonLi("Happy"));
    unique_ptr<Cat> c2(new Persian("Socks"));

    c1->eat(100);
    c1->speak();

    c2->eat(100);
    c2->speak();
}




