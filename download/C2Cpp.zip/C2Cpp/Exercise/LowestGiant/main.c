#include <stdio.h>
#include <stdbool.h>

int main()
{
    int values[10][10];
    int n = 0;
    scanf("%d",&n);
    for (int i=0;i<n;i++)
        for (int j=0;j<n;j++)
            scanf("%d",&values[i][j]);

//    for (int i=0;i<n;i++){
//        for (int j=0;j<n;j++)
//            printf("%d ", values[i][j]);
//        printf("\n");
//    }

    int iCount = 0;
    for (int i=0;i<n;i++){
        //找出该行最大值
        int rowMax = values[i][0];
        for (int j=1;j<n;j++){
            if (values[i][j] > rowMax)
                rowMax = values[i][j];
        }

        for (int j=0;j<n;j++){
            if (values[i][j]!=rowMax)
                continue;
            //[i][j]是该行最大值，现检查其是否系该列最小值
            bool bLowestGiant = true;
            for (int k=0;k<n;k++){
                if (values[k][j]<rowMax)
                    bLowestGiant = false;
            }
            if (bLowestGiant){
                printf("(%d,%d)\n",i,j);
                iCount++;
            }
        }
    }

    if (iCount==0)
        printf("NONE\n");
    return 0;
}
