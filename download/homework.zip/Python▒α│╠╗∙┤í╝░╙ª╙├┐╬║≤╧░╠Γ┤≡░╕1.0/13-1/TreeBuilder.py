"""
The idea comes from internet.
The code is written by Alex@ChongQing university:  chenbo@cqu.edu.cn   Nov,2018
"""

from PyQt5.QtWidgets import QWidget, QApplication
from PyQt5.QtGui import QPainter, QPen,QColor
from PyQt5.QtCore import Qt
import random, math
import sys
import Ui_MainWidget
from PyQt5 import QtWidgets
class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y

class TreeNode:
    maxDepth = 8
    nBranches = 3
    def __init__(self, bottom, top, depth=0):
        self.bottom = bottom
        self.top = top
        self.drawingTop = top
        self.depth = depth
        self.children = []
        self.__generateDescendents()

    def bfs(self):  #breadth first search
        nodesQueue = [self]
        while True:
            if len(nodesQueue)==0:
                break
            x = nodesQueue.pop(0)
            yield x
            nodesQueue.extend(x.children)

    def __generateDescendents(self):
        "Recursively build sub-tree of the current node."
        n = random.randint(TreeNode.nBranches//2,round(TreeNode.nBranches*1.5))
        n = n if n >=1 else 1

        r = 0.20 + random.random() * 0.2
        x = self.bottom.x + (self.top.x - self.bottom.x) * r
        y = self.bottom.y + (self.top.y - self.bottom.y) * r
        self.drawingTop = Point(x, y)

        if self.depth < self.maxDepth:
            a = math.pi * 0.5 / n
            for i in range(n):
                angleOffset =  a * (n-1) / 2 - a * i + math.pi
                angleOffset *= (0.9 + random.random() * 0.2)
                son = self.__bornSon(self.drawingTop, self.top, angleOffset)
                self.children.append(son)

    def __bornSon(self, bottom, top, angleOffset):
        "Born a son of current node, with designated offset angle."
        xWidth = top.x - bottom.x    #Width of sub-tree
        yHeight = top.y - bottom.y   #Height of sub-tree

        angleSubTree = math.atan(yHeight / xWidth) if xWidth !=0 else math.pi/2
        if (angleSubTree < 0 and bottom.y > top.y) or \
                (angleSubTree > 0 and bottom.y < top.y):
            angleSubTree += math.pi

        angleSon = angleSubTree + angleOffset

        r = 0.9 + random.random() * 0.2
        c = math.sqrt(xWidth ** 2 + yHeight ** 2) * r
        xOffset = c * math.cos(angleSon)
        yOffset = c * math.sin(angleSon)
        topNew = Point(xOffset + bottom.x, yOffset + bottom.y)
        return TreeNode(bottom, topNew, self.depth + 1)

class TreeBuilder:
    def setPara(bottom,top,nBranches=3,maxDepth=8):
        TreeBuilder.bottom = bottom
        TreeBuilder.top = top
        TreeBuilder.nBranches = nBranches
        TreeBuilder.maxDepth = maxDepth

    def buildTree(depthOffset=0):
        TreeBuilder.maxDepth += depthOffset
        TreeBuilder.maxDepth = TreeBuilder.maxDepth \
            if TreeBuilder.maxDepth <=10 else 10
        TreeBuilder.maxDepth = TreeBuilder.maxDepth \
            if TreeBuilder.maxDepth >=2 else 2

        print("Build a tree, branches:{},depth:{}.".
              format(TreeBuilder.nBranches,TreeBuilder.maxDepth))
        TreeNode.maxDepth = TreeBuilder.maxDepth
        TreeNode.nBranches = TreeBuilder.nBranches
        t = TreeNode(TreeBuilder.bottom,TreeBuilder.top)
        return t

class Paint(QtWidgets.QMainWindow,Ui_MainWidget.Ui_MainWidget,QWidget):

    def __init__(self):
        TreeBuilder.setPara(bottom=Point(1024 / 2, 768 - 20), top=Point(1024 / 2, 768 * 0.1))
        super(Paint,self).__init__()
        self.setupUi(self)
        self.tree=TreeBuilder.buildTree()

    def paintEvent(self,e):
        #print(type(e))
        self.qp = QPainter()
        self.qp.begin(self)
        self.showtree()
        self.qp.end()

    def showtree(self):
        # 新建一个QPen对象，设置颜色黑色，宽2像素，这样就能看出来各个笔样式的区别
        for x in self.tree.bfs():
            self.__renderNode(x)
    #-------------------------------------------------------------------------------------
    def __renderNode(self,node):
        "Render a TreeNode."
        #print("访问结点")
        colorFill = "#{0:0>2x}{0:0>2x}{0:0>2x}".\
            format(int(0x60 * node.depth / node.maxDepth))
        self.__drawLine(node.bottom,node.drawingTop,
            colorFill=colorFill,width=1.5 ** (node.maxDepth - node.depth))

        if not node.children: #draw leaf if it is a leaf
            red = 0xff * node.drawingTop.y / self.tree.drawingTop.y
            red = int(red * (0.8 + random.random() * 0.4))
            red = red if red <= 0xff else 0xff
            colorFill = "#{0:0>2x}9000".format(red)
            pen = QPen(QColor(colorFill), 3, Qt.SolidLine)
            self.qp.setPen(pen)
            self.qp.drawEllipse(node.drawingTop.x ,node.drawingTop.y,2,2)


    def __drawLine(self,pt0, pt1, width, colorFill, minDist=10):
        #print("画线")
        self.__generateDotsSequence(pt0,pt1,minDist)

    def __generateDotsSequence(self,pt0,pt1,minDist):
        #print("生成点序列")
        dx, dy = pt1.x - pt0.x, pt1.y - pt0.y
        c = math.sqrt(dx ** 2 + dy ** 2)
        n = int(c / minDist) + 1
        pen = QPen(Qt.black, n, Qt.SolidLine)
        self.qp.setPen(pen)
        xPrev,yPrev = pt0.x,pt0.y
        for i in range(n):
            xOffset = dx * i / n
            yOffset = dy * i / n
            if i > 0:
                xOffset += minDist * (0.5 - random.random()) * 0.25
                yOffset += minDist * (0.5 - random.random()) * 0.25
            x,y = pt0.x + xOffset,pt0.y + yOffset
            #print(xPrev,yPrev,x,y)
            self.qp.drawLine(xPrev,yPrev,x,y)
            #dots.extend([xPrev,yPrev,x,y])
            xPrev,yPrev = x,y
        self.qp.drawLine(xPrev,yPrev,pt1.x,pt1.y)

    def on_pbNew_released(self):
        self.tree = TreeBuilder.buildTree()
        self.update()

    def on_pbNew_sub_released(self):
        self.tree = TreeBuilder.buildTree(depthOffset=-1)
        self.update()
        #self.show()

    def on_pbExit_released(self):
        self.close()

    def on_pbNew_add_released(self):
        self.tree = TreeBuilder.buildTree(depthOffset=1)
        self.update()
        #self.show()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    ex = Paint()
    ex.show()
    sys.exit(app.exec_())
