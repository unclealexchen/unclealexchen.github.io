def isValid(number):
    sum_=sumOfDoubleEvenPlace(number)+sumOfOddPlace(number)
    print(sum_)
    if sum_%10==0:
        return True
    else:
        return False

def sumOfDoubleEvenPlace(number):
    sum1=0
    for i in range(2,getSize(number)+1,2):
        k=int(getPrefix(number,i))
        k=k*2
        sum1+=getDigit(k)
    return sum1

def sumOfOddPlace(number):
    sum2=0
    for m in range(1,getSize(number),2):
        n=int(getPrefix(number,m))
        sum2+=n
    return sum2

def getDigit(number):
    if number>=10:
        number=number//10+number%10
    else:
        number=number
    return number
        
def prefixMatched(number):
    first=int(number[0])
    First2=int(number[0:1])
    if int(len(number))>=13 and int(len(number))<=16:
        if first==4 or first==5 or first==6:
            return True
        elif First2==37:
            return True
    else:
        return False

def getSize(number):
    length=len(number)
    return length

def getPrefix(number,k):
#获得从右往左第K位的数字
    number=str(number[::-1])
    number_k=number[k-1]
    return number_k

def judge(number):
#判断输入的信用卡号是否合法，得到结果
    text1 = "该信用卡号是合法的"
    text2 = "该信用卡号是不合法的"
    if prefixMatched(number) and isValid(number):
        return text1
    else:
        return text2

cardNum=input("请输入你的信用卡号:")
judge(cardNum)