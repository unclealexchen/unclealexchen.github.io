import numpy as np
from matplotlib import pyplot as plt

def My_ufunc(x):
    y=2*x*x+30*x-11.5
    return y

x = np.linspace(-1000,1000,1000)
ufunc=np.frompyfunc(My_ufunc,1,1)
y =ufunc(x)
plt.plot(x,y)
plt.show()