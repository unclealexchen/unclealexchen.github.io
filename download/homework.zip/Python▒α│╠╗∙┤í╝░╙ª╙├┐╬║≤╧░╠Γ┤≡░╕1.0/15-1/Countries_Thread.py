from PyQt5 import QtCore

class Countries_Thread(QtCore.QThread):

    def __init__(self,parent):
        super().__init__(parent)
        self.flag=False

    def run(self):
        pass