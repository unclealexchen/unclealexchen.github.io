
from PyQt5 import QtWidgets,QtGui,QtCore
from PyQt5.QtWidgets import QSizePolicy
from Country import Country,CompareState
from SortRunner import SortRunner
import  Ui_mainwindow
from PyQt5.QtCore import QMutex


class MainWidget(QtWidgets.QMainWindow, Ui_mainwindow.Ui_MainWindow, QtCore.QObject):

    def __init__(self,parent=None):
        #self.UseCountries = Countries_Thread(self)
        #self.UseCountries.start()
        super(MainWidget,self).__init__(parent)
        self.setupUi(self)
        self.pbStart.clicked.connect(self.on_pbStart_released)
        self.pbStop.clicked.connect(self.on_pbStop_released)
        self.pbShuffle.clicked.connect(self.on_pbShuffle_released)
        self.sortRunner=None
        self.initCountries()
        self.panelCountries=[]
        self.setToIdleState()
        self.mutex=QMutex()
        self.displayCountries()


    def initCountries(self):
        self.countries = []
        import configparser
        data = configparser.ConfigParser()
        data.read("countries.ini")
        data = data["Countries"]
        Size = int(data.get("countries.size",0))
        for i in range(Size):
            name = data.get("countries[{}].sName".format(i),"ERROR").strip()
            gdp = float(data.get("countries[{}].fGdp".format(i),"0"))
            logofile = data.get("countries[{}].sLogoFile".format(i),"ERROR").strip()
            print(name,gdp,logofile)
            self.countries.append(Country(name,gdp,logofile))

    def createPanelCountries(self):
        for i in range(len(self.countries)):
            panel = QtWidgets.QToolButton(self.centralWidget)
            panel.setFixedHeight(50)
            panel.setSizePolicy(QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed))
            panel.setFont(QtGui.QFont("Cambria",12))
            panel.setIconSize(QtCore.QSize(30,30))
            panel.setToolButtonStyle(QtCore.Qt.ToolButtonTextBesideIcon)
            self.verticalLayoutCountries.addWidget(panel)
            self.panelCountries.append(panel)

    def displayCountries(self):
        self.mutex.lock()
        print("显示")
        print(len(self.panelCountries))
        if len(self.panelCountries) == 0:
            self.createPanelCountries()
        print(len(self.panelCountries))
        assert len(self.panelCountries) == len(self.countries)
        for x, y in zip(self.panelCountries,self.countries):
            print(type(x),type(y))
            print(y.fGdp,y.sName,y.sLogoFile)
            x.setText(" "*8+"${:0<12,.2f}{}".format(y.fGdp,y.sName))
            x.setIcon(QtGui.QIcon("{}".format(y.sLogoFile)))
            if y.compareState == CompareState.prev:
                x.setStyleSheet("background-color: rgb(255, 255, 0);")
            elif y.compareState == CompareState.next:
                x.setStyleSheet("background-color: rgb(255, 0, 0);")
            elif y.compareState == CompareState.fixed:
                x.setStyleSheet("background-color: rgb(0, 255, 0);")
            else:
                x.setStyleSheet("")
        self.mutex.unlock()

    def setToRunningState(self):
        self.pbStart.setEnabled(False)
        self.pbStop.setEnabled(True)
        self.pbShuffle.setEnabled(False)
        self.pbAbout.setEnabled(False)
        self.pbExit.setEnabled(False)

    def setToIdleState(self):
        print("设置按钮")
        self.pbStart.setEnabled(True)
        self.pbStop.setEnabled(False)
        self.pbShuffle.setEnabled(True)
        self.pbAbout.setEnabled(True)
        self.pbExit.setEnabled(True)

    def on_pbShuffle_released(self):
        import random
        random.shuffle(self.countries)
        for x in self.countries:
            x.compareState = CompareState.idle
        self.displayCountries()

    def on_pbStart_released(self):
        print("on_pbStart_released")
        if self.sortRunner != None:
            if not self.sortRunner.isFinished():
                self.sortRunner.terminate()
                assert self.sortRunner.wait(2000)
        self.setToRunningState()
        print("初始化排序类")
        self.sortRunner = SortRunner(self.countries,self,self.mutex)
        print("连接更新函数")
        self.sortRunner.updateInformer.connect(self.handlerUpdateInformer)
        self.sortRunner.finished.connect(self.setToIdleState)
        print("开始排序")
        self.sortRunner.start()

    def on_pbStop_released(self):
        assert self.sortRunner != None
        self.sortRunner.terminate()

    def handlerUpdateInformer(self):
        self.displayCountries()