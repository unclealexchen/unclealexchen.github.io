from PyQt5 import QtCore
from Country import CompareState
import time
class SortRunner(QtCore.QThread):
    updateInformer = QtCore.pyqtSignal()
    print("updateInformer")
    def __init__(self, countries, parent,mutex):
        print("super")
        super().__init__(parent)
        print("国家",countries)
        self.countries = countries
        self.mutex=mutex
        print(len(self.countries))
        print("初始化完成")

    def run(self):
        self.mutex.lock()
        print("run")
        for x in self.countries:
            x.compareState = CompareState.idle
        print("compareState")
        self.mutex.unlock()
        self.updateInformer.emit()

        time.sleep(0.2)
        print("进入冒泡排序")
        for i in range(len(self.countries)-1,0,-1):
            for j in range(0,i):
                self.mutex.lock()
                self.countries[j].compareState = CompareState.prev
                self.countries[j+1].compareState = CompareState.next
                self.mutex.unlock()
                self.updateInformer.emit()
                time.sleep(0.5)
                if self.countries[j].fGdp < self.countries[j+1].fGdp:
                    self.mutex.lock()
                    self.countries[j],self.countries[j+1] =self.countries[j+1],self.countries[j]
                    self.mutex.unlock()
                    self.updateInformer.emit()
                    time.sleep(0.8)
                self.mutex.lock()
                self.countries[j].compareState = CompareState.idle
                self.countries[j+1].compareState = CompareState.idle
                self.mutex.unlock()
            self.mutex.lock()
            self.countries[i].compareState = CompareState.fixed
            self.mutex.unlock()
        self.mutex.lock()
        self.countries[0].compareState = CompareState.fixed
        self.mutex.unlock()
        print("再一次进入显示")

        self.updateInformer.emit()



#sort=SortRunner([],None)
#sort.start()