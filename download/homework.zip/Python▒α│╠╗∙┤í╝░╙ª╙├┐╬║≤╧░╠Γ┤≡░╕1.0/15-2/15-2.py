import numpy as np

x,y=np.ogrid[1:9:9j,1:9:9j]
print(x)
print(y)
z=x*y
print(z)