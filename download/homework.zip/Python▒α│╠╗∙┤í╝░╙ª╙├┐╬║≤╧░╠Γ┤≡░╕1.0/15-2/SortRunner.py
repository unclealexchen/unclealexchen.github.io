from PyQt5 import QtCore
from Country import CompareState
import time
class SortRunner(QtCore.QThread):
    updateInformer = QtCore.pyqtSignal()
    print("updateInformer")
    def __init__(self, countries, parent,SortPercent):
        print("super")
        super().__init__(parent)
        print("国家",countries)
        self.countries = countries
        print(len(self.countries))
        print("初始化完成")
        self.SortPercent=SortPercent

    def run(self):
        print("run")
        for x in self.countries:
            x.compareState = CompareState.idle
        print("compareState")
        self.updateInformer.emit()
        time.sleep(0.2)
        print("进入冒泡排序")
        Count=1
        for i in range(len(self.countries)-1,0,-1):
            for j in range(0,i):
                self.countries[j].compareState = CompareState.prev
                self.countries[j+1].compareState = CompareState.next
                self.updateInformer.emit()
                time.sleep(0.5)
                if self.countries[j].fGdp < self.countries[j+1].fGdp:
                    self.countries[j],self.countries[j+1] =self.countries[j+1],self.countries[j]
                    self.updateInformer.emit()
                    time.sleep(1.0)
                self.countries[j].compareState = CompareState.idle
                self.countries[j+1].compareState = CompareState.idle
            self.countries[i].compareState = CompareState.fixed
            self.SortPercent.setValue(Count)
            Count+=1
            self.updateInformer.emit()
            time.sleep(0.2)
        self.countries[0].compareState = CompareState.fixed
        print("再一次进入显示")
        time.sleep(0.2)
        #self.SortPercent.setValue(Count)
        self.updateInformer.emit()

        return


#sort=SortRunner([],None)
#sort.start()