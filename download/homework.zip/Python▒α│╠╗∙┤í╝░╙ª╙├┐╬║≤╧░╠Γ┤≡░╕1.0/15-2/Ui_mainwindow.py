# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'Ui_mainwindow.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(494, 653)
        self.centralWidget = QtWidgets.QWidget(MainWindow)
        self.centralWidget.setObjectName("centralWidget")
        self.pbStart = QtWidgets.QPushButton(self.centralWidget)
        self.pbStart.setGeometry(QtCore.QRect(20, 20, 75, 23))
        self.pbStart.setObjectName("pbStart")
        self.pbStop = QtWidgets.QPushButton(self.centralWidget)
        self.pbStop.setGeometry(QtCore.QRect(110, 20, 75, 23))
        self.pbStop.setObjectName("pbStop")
        self.pbShuffle = QtWidgets.QPushButton(self.centralWidget)
        self.pbShuffle.setGeometry(QtCore.QRect(200, 20, 75, 23))
        self.pbShuffle.setObjectName("pbShuffle")
        self.pbAbout = QtWidgets.QPushButton(self.centralWidget)
        self.pbAbout.setGeometry(QtCore.QRect(290, 20, 75, 23))
        self.pbAbout.setObjectName("pbAbout")
        self.pbExit = QtWidgets.QPushButton(self.centralWidget)
        self.pbExit.setGeometry(QtCore.QRect(380, 20, 75, 23))
        self.pbExit.setObjectName("pbExit")
        self.verticalLayoutWidget = QtWidgets.QWidget(self.centralWidget)
        self.verticalLayoutWidget.setGeometry(QtCore.QRect(80, 50, 321, 511))
        self.verticalLayoutWidget.setObjectName("verticalLayoutWidget")
        self.verticalLayoutCountries = QtWidgets.QVBoxLayout(self.verticalLayoutWidget)
        self.verticalLayoutCountries.setContentsMargins(11, 11, 11, 11)
        self.verticalLayoutCountries.setSpacing(6)
        self.verticalLayoutCountries.setObjectName("verticalLayoutCountries")
        self.SortPercent = QtWidgets.QProgressBar(self.centralWidget)
        self.SortPercent.setGeometry(QtCore.QRect(90, 580, 321, 23))
        self.SortPercent.setProperty("value", 24)
        self.SortPercent.setObjectName("SortPercent")
        MainWindow.setCentralWidget(self.centralWidget)
        self.menuBar = QtWidgets.QMenuBar(MainWindow)
        self.menuBar.setGeometry(QtCore.QRect(0, 0, 494, 23))
        self.menuBar.setObjectName("menuBar")
        MainWindow.setMenuBar(self.menuBar)
        self.mainToolBar = QtWidgets.QToolBar(MainWindow)
        self.mainToolBar.setObjectName("mainToolBar")
        MainWindow.addToolBar(QtCore.Qt.TopToolBarArea, self.mainToolBar)
        self.statusBar = QtWidgets.QStatusBar(MainWindow)
        self.statusBar.setObjectName("statusBar")
        MainWindow.setStatusBar(self.statusBar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.pbStart.setText(_translate("MainWindow", "开始"))
        self.pbStop.setText(_translate("MainWindow", "停止"))
        self.pbShuffle.setText(_translate("MainWindow", "随机"))
        self.pbAbout.setText(_translate("MainWindow", "关于"))
        self.pbExit.setText(_translate("MainWindow", "退出"))

