from cv2 import imread,imwrite
img=imread("18-3.jpg",-1)
height,weight=img.shape[:2]
img=img[50:height-50:3,50:weight-50:5,:]
imwrite("18-3_1.jpg",img)
