import numpy as np
score=np.array([80,85,83,87,90,96])
weight=np.array([0.3,0.5,0.7,0.2,0.4,0.6])
print(np.average(score,weights=weight))