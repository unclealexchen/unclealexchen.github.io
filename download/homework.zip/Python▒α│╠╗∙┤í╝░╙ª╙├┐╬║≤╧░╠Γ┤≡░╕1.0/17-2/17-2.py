import numpy as np
import mpl_toolkits.mplot3d
from matplotlib import pyplot as plt
from matplotlib import cm
x,y=np.mgrid[-2*np.pi:2*np.pi:1000j,-2*np.pi:2*np.pi:1000j]
z = np.sin(x)*np.cos(y)

fig = plt.figure(figsize=(8,6))
ax = fig.gca(projection='3d')
ax.plot_surface(x,y,z,cmap=cm.ocean)
plt.show()