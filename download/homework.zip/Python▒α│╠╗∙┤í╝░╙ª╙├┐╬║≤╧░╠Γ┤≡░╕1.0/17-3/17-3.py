import matplotlib.pyplot as plt
from pylab import mpl

mpl.rcParams['font.sans-serif'] = ['FangSong'] # 指定默认字体
mpl.rcParams['axes.unicode_minus'] = False # 解决保存图像是负号'-'显示为方块的问题
PreYear = (195558.74, 131735.85, 43421.60, 35954.06, 32322.81,25865.68,26074.09,19329.38,17592.67,16823.68)
CurYear = (205130.00, 134572.67, 50706.26, 40291.40, 28088.99,27946.96,26899.92,20869.11,19093.86,17337.06)   #各组女性平均得分
add_percent=[]
for i in range(len(CurYear)):
    add_percent.append((CurYear[i]-PreYear[i]))
Countries=("美国","中国","日本","德国","英国","法国","印度","意大利","巴西","加拿大")
fig,ax = plt.subplots()
x =list(range(len(Countries)))
print(x)
total_width, n = 0.8, 2
width = total_width / n
ax.set_ylabel('GDP(亿)')
ax.set_xlabel('国家')
ax.set_title('2018年世界前十大经济体的GDP总值及其增量')
p1 = ax.bar(x, CurYear,width=width)
for i in range(len(x)):
    x[i] = x[i] + width
p2 = ax.bar(x,add_percent, width=width)
ax.legend((p1[0],p2[0]),("GDP(亿)","增量(亿)")) #显式地定义图示
plt.show()