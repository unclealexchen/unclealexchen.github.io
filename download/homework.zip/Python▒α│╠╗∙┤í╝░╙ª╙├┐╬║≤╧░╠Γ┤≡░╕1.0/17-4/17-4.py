import numpy as np
import matplotlib.pyplot as plt
from pylab import mpl

mpl.rcParams['font.sans-serif'] = ['FangSong'] # 指定默认字体
mpl.rcParams['axes.unicode_minus'] = False # 解决保存图像是负号'-'显示为方块的问题

x=np.arange(0,10)
y=np.random.randint(10,30,10)
fig,ax = plt.subplots()
ax.set_ylabel('GDP(亿)')
ax.set_xlabel('国家')
ax.set_title('过去30年中国对世界主要经济体（前10位）出口总额的数据')
Countries=[]
for i in range(10):
    Countries.append("国家"+str(i))

for i in range(30):
    plt.cla()
    ax.set_title(str(1989+i)+'年中国对世界主要经济体（前10位）出口总额的数据')
    p1 = ax.bar(Countries,y,width=0.5)
    plt.pause(0.5)
    y = np.random.randint(10, 30, 10)

plt.show()