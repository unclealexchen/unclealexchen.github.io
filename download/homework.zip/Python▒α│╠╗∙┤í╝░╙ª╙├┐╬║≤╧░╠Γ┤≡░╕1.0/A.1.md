---
title: 《Python编程实践》第A.1章练习题及解答
date: 2019-08-03 12:20:28
tags: 
  - Python
  - 习题
comments: true
categories:
  - [Python]
meta:
  top: false
  date: true
  categories: true 
  counter: true 
  updated: true
  share: true
  tags: true 
recommended_posts: false
mathjax: true
---



《Python编程实践》第A.1章练习题及解答



<!-- more -->



> 版权声明
>
> 本文**可以**在互联网上自由转载，但必须：注明出处(作者：陈波，刘慧君)并包含指向本页面的链接。
>
> 本文**不可以**以纸质出版为目的进行改编、摘抄。





#### A.1-1

设计一个生成器函数，该生成器函数生成字母'a', 'b','c','d'的全排列，其生成顺序按照字母表排序。用一个for
循环迭代这个生成器函数，打印全部元素。

答案：

```python
def Permutations(value_fun,start,end):
    if start+1==end:
        yield value_fun
    else:
        for ind in range(start,end):
            value_fun[ind],value_fun[start]=value_fun[start],value_fun[ind]
            for y in Permutations(value_fun,start+1,end):
                yield y
            value_fun[ind],value_fun[start]=value_fun[start],value_fun[ind]

value=['a','b','c','d']
ans=[]
for x in Permutations(value,0,len(value)):
    ans.append(x.copy())
print(sorted(ans))
```

思路：

```
全排列递归算法的基本思想：若序列长度为n，则下标为0的数，需要和后面所有n个数交换位置（包括自己），进行下一层的递归，递归完成后进行还原；在某次递归中，下标为1的数，需要和后面所有n-1个数交换位置（包括自己），进行下一层的递归，递归完成后进行还原...依次类推，直到所有的递归完成。本题使用yield返回序列，由于在递归中会使用yield，因此递归过程中也会产生序列，所以需要for y in Permutations(value_fun,start+1,end):这个语句来遍历所有产生的序列。为了避免名字绑定的情况发生，使用x.copy()生成新的对象，最后再排列。
```



#### A.1-2

设计一个序列化类。实例化该类并使用下标访问其全部元素。其中，第i个元素的值为斐波那契序列前i项的
和，i的最大值限定为100。

答案：

```python
class MyList():
    def __init__(self,num=0):
        self.temp=[0,1,1]
        self.MaxLen=100
        self.Cur=None
        self.index=0
        self.Calculate(num)

    def __getitem__(self, key):
        if key<1 or key>100:
            raise  KeyError
        if type(key)!=int:
            raise TypeError
        if self.Cur==None or key>self.Cur:
            self.Calculate(key)
        return self.temp[key]
    def __len__(self):
        return self.Cur

    def __setitem__(self, key, value):
        if key<1 or key>100:
            raise  KeyError
        if type(key)!=int:
            raise TypeError
        if self.Cur==None or key>self.Cur:
            self.Calculate(key)
        self.temp[key]=value

    def __iter__(self):
        return self

    def __next__(self):
        self.index+=1
        if self.Cur==None or self.index>self.Cur:
            self.index=0
            raise StopIteration
        return self.temp[self.index]

    def Calculate(self,key):
        if self.Cur==None:
            self.Cur=2
        for ind in range(self.Cur+1,key+1):
            self.temp.append(self.temp[ind-1]+self.temp[ind-2])
        self.Cur=key

mylist=MyList(5)
for x in mylist:
    print(x)
print(mylist[3])
```

思路：

```
使用下标访问元素，需要重写__getitem__和__setitem__方法，注意判断边界和下标的类型。
若要遍历所有元素，需要重写__next__和__iter__方法。
```

