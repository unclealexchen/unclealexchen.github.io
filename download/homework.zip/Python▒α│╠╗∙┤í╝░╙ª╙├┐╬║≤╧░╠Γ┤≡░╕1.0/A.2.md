---
title: 《Python编程实践》第A.2章练习题及解答
date: 2019-08-03 12:26:27
tags: 
  - Python
  - 习题
comments: true
categories:
  - [Python]
meta:
  top: false
  date: true
  categories: true 
  counter: true 
  updated: true
  share: true
  tags: true 
recommended_posts: false
mathjax: true
---



《Python编程实践》第A.2章练习题及解答



<!-- more -->



> 版权声明
>
> 本文**可以**在互联网上自由转载，但必须：注明出处(作者：陈波，刘慧君)并包含指向本页面的链接。
>
> 本文**不可以**以纸质出版为目的进行改编、摘抄。





#### A.2-1

请在你的计算机上使用pip install安装numpy, scipy，matplotlib, PyQt5, opencv-python等扩展库。安装前
后请注意Python安装路径下site-packages 子目录里的变化。

答案：

```python
安装成功后，会在site-packages子目录下添加相应的包文件夹（包括依赖包）。
```

思路：

```
pass
```



#### A.2-2

使用dir(), help()等函数了解numpy模块的功能。

答案：

```python
import numpy

print(dir(numpy))
print(help(numpy))
print(numpy.__all__)
```

思路：

```
pass
```

#### A.2-3

将A.2章随书代码中的fibiter.py修改成一个模块文件，即删去除Fibonacci类定义之外的执行代码部分。然后，
在同一目录下编写一个名为fibdemo.py的代码文件，在其中导入fibiter.py中的Fibonacci类，并使用该类迭代打印
斐波那契数列的前20项。

答案：

```python
#fibdemo.py
class Fibonacci:
    def __init__(self, max):
        self.a = 1
        self.b = 1
        self.idx = 0
        self.maxIdx = max
    def __iter__(self):
        return self
    def __next__(self):
        self.idx += 1
        if self.idx == 1:
            return 1
        elif self.idx == 2:
            return 1
        elif self.idx > self.maxIdx:
            raise StopIteration
        else:
            c = self.a + self.b
            self.a, self.b = self.b, c
            return c

```



```python
from fibdemo import Fibonacci
for x in Fibonacci(10):
    print(x, end=",")
print("")
it = Fibonacci(10)
for x in range(10):
    print(next(it), end=",")
print("")
print(list(Fibonacci(10)))
```

思路：

```
由于要迭代访问Fibonacci，因此需要重写Fibonacci中的__next__和__iter__方法，注意判断边界的情况。
```

