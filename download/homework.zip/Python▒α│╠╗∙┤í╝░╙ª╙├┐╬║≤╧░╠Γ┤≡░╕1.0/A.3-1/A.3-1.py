from MainWidget import MainWidget
from PyQt5 import QtWidgets
import sys

app = QtWidgets.QApplication(sys.argv)
mw = MainWidget()
mw.show()
exit(app.exec_())