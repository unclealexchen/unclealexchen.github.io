---
title: 《Python编程实践》第A.3章练习题及解答
date: 2019-08-05 18:50:07
tags: 
  - Python
  - 习题
comments: true
categories:
  - [Python]
meta:
  top: false
  date: true
  categories: true 
  counter: true 
  updated: true
  share: true
  tags: true 
recommended_posts: false
mathjax: true
---



《Python编程实践》第A.3章练习题及解答



<!-- more -->



> 版权声明
>
> 本文**可以**在互联网上自由转载，但必须：注明出处(作者：陈波，刘慧君)并包含指向本页面的链接。
>
> 本文**不可以**以纸质出版为目的进行改编、摘抄。





#### A.3-1

本实践中，SortRunner线程需要使用countries列表，MainWidget.py中的主线程也在使用同一个countries列表进行数据展示。事实上，两个线程在竞争性地使用该资源，有时，这样做会带来后果。我们希望有一种机制，可以确保同一时间，仅有一个线程使用该资源-countries列表，如果另一个线程需要用，则稍等等，等另一个线程使用完后再用。请查询资料，解决该问题。提示：关键词mutex, 互斥锁。

答案：

```python
#Ui_About.py
from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_About(object):
    def setupUi(self, About):
        About.setObjectName("About")
        About.resize(865, 393)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(About.sizePolicy().hasHeightForWidth())
        About.setSizePolicy(sizePolicy)
        About.setMinimumSize(QtCore.QSize(865, 393))
        About.setMaximumSize(QtCore.QSize(865, 393))
        About.setModal(False)
        self.textBrowser = QtWidgets.QTextBrowser(About)
        self.textBrowser.setGeometry(QtCore.QRect(160, 10, 681, 251))
        self.textBrowser.setObjectName("textBrowser")
        self.widget = QtWidgets.QWidget(About)
        self.widget.setGeometry(QtCore.QRect(20, 20, 111, 121))
        self.widget.setStyleSheet("background-image: url(:/Images/img/copy.png);")
        self.widget.setObjectName("widget")
        self.pbClose = QtWidgets.QPushButton(About)
        self.pbClose.setGeometry(QtCore.QRect(540, 277, 301, 101))
        font = QtGui.QFont()
        font.setFamily("Cambria")
        font.setPointSize(16)
        self.pbClose.setFont(font)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(":/Images/img/logout.png"), QtGui.QIcon.Normal, QtGui.QIcon.On)
        self.pbClose.setIcon(icon)
        self.pbClose.setIconSize(QtCore.QSize(64, 64))
        self.pbClose.setObjectName("pbClose")

        self.retranslateUi(About)
        QtCore.QMetaObject.connectSlotsByName(About)

    def retranslateUi(self, About):
        _translate = QtCore.QCoreApplication.translate
        About.setWindowTitle(_translate("About", "About ... "))
        self.textBrowser.setHtml(_translate("About", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'SimSun\'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt; font-weight:600;\">ABOUT THIS SOFTWARE</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:18pt;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt;\">The software was developped by Alex from Chongqing University.It was designed for educational purpose as an example for author\'s book. The licence is GPL.</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:12pt;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt;\">email: </span><span style=\" font-size:12pt; font-weight:600;\">chenbo@cqu.edu.cn   </span><span style=\" font-size:12pt;\">November, 2018</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p></body></html>"))
        self.pbClose.setText(_translate("About", "         CLOSE"))
```

```python
#About.py
from PyQt5 import QtWidgets
from Ui_About import Ui_About

class About(QtWidgets.QDialog,Ui_About):
    def __init__(self,parent):
        QtWidgets.QDialog.__init__(self,parent)
        self.setupUi(self)

    def on_pbClose_released(self):
        self.close()
```

```python
#SortRunner.py
from PyQt5 import QtCore
from Country import CompareState
import time

class SortRunner(QtCore.QThread):
    updateInformer = QtCore.pyqtSignal()
    def __init__(self, countries, parent,mutex):
        super().__init__(parent)
        self.countries = countries
        self.mutex=mutex

    def run(self):
        self.mutex.lock()
        for x in self.countries:
            x.compareState = CompareState.idle
        self.mutex.unlock()
        self.updateInformer.emit()
        time.sleep(0.2)
        for i in range(len(self.countries)-1,0,-1):
            for j in range(0,i):
                self.mutex.lock()
                self.countries[j].compareState = CompareState.prev
                self.countries[j+1].compareState = CompareState.next
                self.mutex.unlock()
                self.updateInformer.emit()
                time.sleep(0.5)
                if self.countries[j].fGdp < self.countries[j+1].fGdp:
                    self.mutex.lock()
                    self.countries[j],self.countries[j+1] = \
                        self.countries[j+1],self.countries[j]
                    self.mutex.unlock()
                    self.updateInformer.emit()
                    time.sleep(1.0)
                self.mutex.lock()
                self.countries[j].compareState = CompareState.idle
                self.countries[j+1].compareState = CompareState.idle
                self.mutex.unlock()
            self.mutex.lock()
            self.countries[i].compareState = CompareState.fixed
            self.mutex.unlock()
        self.mutex.lock()
        self.countries[0].compareState = CompareState.fixed
        self.mutex.unlock()
        self.updateInformer.emit()
        return
```

```python
#MainWidget.py
import os,random
from PyQt5 import QtWidgets,QtGui,QtCore
from PyQt5.QtWidgets import QSizePolicy
from Country import Country,CompareState
from SortRunner import SortRunner
import Ui_MainWidget
import About

class MainWidget(QtWidgets.QMainWindow,Ui_MainWidget.Ui_MainWidget):
    def __init__(self,parent=None):
        super(MainWidget,self).__init__(parent)
        self.setupUi(self)
        self.sortRunner = None
        self.mutex=QtCore.QMutex()
        self.panelCountries = []
        self.initCountries()
        self.setToIdleState()
        self.displayCountries()


    def setToRunningState(self):
        self.pbStart.setEnabled(False)
        self.pbStop.setEnabled(True)
        self.pbShuffle.setEnabled(False)
        self.pbAbout.setEnabled(False)
        self.pbExit.setEnabled(False)

    def setToIdleState(self):
        self.pbStart.setEnabled(True)
        self.pbStop.setEnabled(False)
        self.pbShuffle.setEnabled(True)
        self.pbAbout.setEnabled(True)
        self.pbExit.setEnabled(True)

    def handlerUpdateInformer(self):
        self.displayCountries()

    def initCountries(self):
        self.countries = []

        import configparser
        data = configparser.ConfigParser()
        data.read("countries.ini")
        data = data["Countries"]
        iSize = int(data.get("countries.size",0))
        for i in range(iSize):
            name = data.get("countries[{}].sName".format(i),"ERROR").strip()
            gdp = float(data.get("countries[{}].fGdp".format(i),"0"))
            logofile = data.get("countries[{}].sLogoFile".format(i),"ERROR").strip()
            self.countries.append(Country(name,gdp,logofile))

    def createPanelCountries(self):
        for i in range(len(self.countries)):
            panel = QtWidgets.QToolButton(self.centralwidget)
            panel.setFixedHeight(52)
            panel.setSizePolicy(QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed))
            panel.setFont(QtGui.QFont("Cambria",16))
            panel.setIconSize(QtCore.QSize(64,48))
            panel.setToolButtonStyle(QtCore.Qt.ToolButtonTextBesideIcon)
            self.verticalLayoutCountries.addWidget(panel)
            self.panelCountries.append(panel)

    def displayCountries(self):
        self.mutex.lock()
        if len(self.panelCountries) == 0:
            self.createPanelCountries()
        assert len(self.panelCountries) == len(self.countries)

        for x, y in zip(self.panelCountries,self.countries):
            x.setText(" " * 10 + "${:<30,.2f}{}".format(y.fGdp,y.sName))
            x.setIcon(QtGui.QIcon("img{}{}".format(os.sep,y.sLogoFile)))
            if y.compareState == CompareState.prev:
                x.setStyleSheet("background-color: rgb(255, 255, 0);")
            elif y.compareState == CompareState.next:
                x.setStyleSheet("background-color: rgb(255, 0, 0);")
            elif y.compareState == CompareState.fixed:
                x.setStyleSheet("background-color: rgb(0, 255, 0);")
            else:
                x.setStyleSheet("")
        self.mutex.unlock()


    def on_pbShuffle_released(self):
        random.shuffle(self.countries)
        for x in self.countries:
            x.compareState = CompareState.idle
        self.displayCountries()

    def on_pbExit_released(self):
        self.close()

    def on_pbAbout_released(self):
        dlg = About.About(self)
        dlg.exec()

    def on_pbStop_released(self):
        assert self.sortRunner != None
        self.sortRunner.terminate()

    def on_pbStart_released(self):
        if self.sortRunner != None:
            if not self.sortRunner.isFinished():
                self.sortRunner.terminate()
                assert self.sortRunner.wait(2000)

        self.setToRunningState()

        self.sortRunner = SortRunner(self.countries,self,self.mutex)
        self.sortRunner.updateInformer.connect(self.handlerUpdateInformer)
        self.sortRunner.finished.connect(self.setToIdleState)
        self.sortRunner.start()
```

```python
#Country.py
from enum import Enum

class CompareState(Enum):
    prev = 0   #the item in comparation as prev item
    next = 1   #the item in comparation as next item
    idle = 2   #the item is not in comparation
    fixed = 3  #the item's position have been settled by sort algorithm

class Country:
    def __init__(self,name,gdp,logofile):
        self.sName = name
        self.fGdp = gdp
        self.sLogoFile = logofile
        self.compareState = CompareState.idle

```

```python
#BubbleSort
import sys
from PyQt5 import QtWidgets
import MainWidget

app = QtWidgets.QApplication(sys.argv)

mw = MainWidget.MainWidget()
mw.show()

exit(app.exec_())
```

```
[Countries]
countries.size = 15
countries[0].sName = United States
countries[0].fGdp = 19555.874
countries[0].sLogoFile = img/us.gif
countries[1].sName = China
countries[1].fGdp = 13173.585
countries[1].sLogoFile =img/china.gif
countries[2].sName = Japan
countries[2].fGdp = 4342.16
countries[2].sLogoFile = img/japan.gif
countries[3].sName = Germany
countries[3].fGdp = 3595.406
countries[3].sLogoFile = img/german.gif
countries[4].sName = United Kingdom
countries[4].fGdp = 3232.281
countries[4].sLogoFile = img/gb.gif
countries[5].sName = India
countries[5].fGdp = 2607.409
countries[5].sLogoFile = img/india.gif
countries[6].sName = France
countries[6].fGdp = 2586.568
countries[6].sLogoFile = img/france.gif
countries[7].sName = Italy
countries[7].fGdp = 1932.938
countries[7].sLogoFile = img/italy.gif
countries[8].sName = Brazil
countries[8].fGdp = 1759.267
countries[8].sLogoFile = img/brazil.gif
countries[9].sName = Canada
countries[9].fGdp = 1682.368
countries[9].sLogoFile = img/canada.gif
countries[10].sName = Korea
countries[10].fGdp = 1545.81
countries[10].sLogoFile = img/korea.gif
countries[11].sName = Spain
countries[11].fGdp = 1318.826
countries[11].sLogoFile = img/spain.gif
countries[12].sName = Austrilia
countries[12].fGdp = 1317.158
countries[12].sLogoFile = img/austrilia.gif
countries[13].sName = Russia
countries[13].fGdp = 1309.268
countries[13].sLogoFile = img/russia.gif
countries[14].sName = Mexico
countries[14].fGdp =1251.253
countries[14].sLogoFile = img/mexico.gif
```

```python
#Ui_MainWidget
from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_MainWidget(object):
    def setupUi(self, MainWidget):
        MainWidget.setObjectName("MainWidget")
        MainWidget.resize(1077, 932)
        self.centralwidget = QtWidgets.QWidget(MainWidget)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.centralwidget.sizePolicy().hasHeightForWidth())
        self.centralwidget.setSizePolicy(sizePolicy)
        self.centralwidget.setObjectName("centralwidget")
        self.horizontalLayout = QtWidgets.QHBoxLayout(self.centralwidget)
        self.horizontalLayout.setContentsMargins(2, 2, 2, 2)
        self.horizontalLayout.setSpacing(2)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.verticalLayout_3 = QtWidgets.QVBoxLayout()
        self.verticalLayout_3.setSizeConstraint(QtWidgets.QLayout.SetMaximumSize)
        self.verticalLayout_3.setSpacing(0)
        self.verticalLayout_3.setObjectName("verticalLayout_3")
        self.tbTitle = QtWidgets.QToolButton(self.centralwidget)
        self.tbTitle.setEnabled(True)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.MinimumExpanding, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.tbTitle.sizePolicy().hasHeightForWidth())
        self.tbTitle.setSizePolicy(sizePolicy)
        self.tbTitle.setMinimumSize(QtCore.QSize(700, 80))
        font = QtGui.QFont()
        font.setFamily("Cambria")
        font.setPointSize(16)
        self.tbTitle.setFont(font)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(":/Images/img/globe.png"), QtGui.QIcon.Normal, QtGui.QIcon.On)
        self.tbTitle.setIcon(icon)
        self.tbTitle.setIconSize(QtCore.QSize(64, 64))
        self.tbTitle.setCheckable(True)
        self.tbTitle.setChecked(True)
        self.tbTitle.setToolButtonStyle(QtCore.Qt.ToolButtonTextBesideIcon)
        self.tbTitle.setObjectName("tbTitle")
        self.verticalLayout_3.addWidget(self.tbTitle)
        self.verticalLayoutCountries = QtWidgets.QVBoxLayout()
        self.verticalLayoutCountries.setSpacing(2)
        self.verticalLayoutCountries.setObjectName("verticalLayoutCountries")
        self.verticalLayout_3.addLayout(self.verticalLayoutCountries)
        self.horizontalLayout.addLayout(self.verticalLayout_3)
        spacerItem = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem)
        self.verticalLayout = QtWidgets.QVBoxLayout()
        self.verticalLayout.setObjectName("verticalLayout")
        self.pbStart = QtWidgets.QPushButton(self.centralwidget)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.pbStart.sizePolicy().hasHeightForWidth())
        self.pbStart.setSizePolicy(sizePolicy)
        self.pbStart.setMinimumSize(QtCore.QSize(0, 120))
        font = QtGui.QFont()
        font.setFamily("Cambria")
        font.setPointSize(16)
        self.pbStart.setFont(font)
        self.pbStart.setStyleSheet("")
        icon1 = QtGui.QIcon()
        icon1.addPixmap(QtGui.QPixmap(":/Images/img/start.png"), QtGui.QIcon.Normal, QtGui.QIcon.On)
        self.pbStart.setIcon(icon1)
        self.pbStart.setIconSize(QtCore.QSize(64, 64))
        self.pbStart.setObjectName("pbStart")
        self.verticalLayout.addWidget(self.pbStart)
        self.pbStop = QtWidgets.QPushButton(self.centralwidget)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.pbStop.sizePolicy().hasHeightForWidth())
        self.pbStop.setSizePolicy(sizePolicy)
        self.pbStop.setMinimumSize(QtCore.QSize(0, 120))
        font = QtGui.QFont()
        font.setFamily("Cambria")
        font.setPointSize(16)
        self.pbStop.setFont(font)
        icon2 = QtGui.QIcon()
        icon2.addPixmap(QtGui.QPixmap(":/Images/img/pause.png"), QtGui.QIcon.Normal, QtGui.QIcon.On)
        self.pbStop.setIcon(icon2)
        self.pbStop.setIconSize(QtCore.QSize(64, 64))
        self.pbStop.setObjectName("pbStop")
        self.verticalLayout.addWidget(self.pbStop)
        self.pbShuffle = QtWidgets.QPushButton(self.centralwidget)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.pbShuffle.sizePolicy().hasHeightForWidth())
        self.pbShuffle.setSizePolicy(sizePolicy)
        self.pbShuffle.setMinimumSize(QtCore.QSize(0, 120))
        font = QtGui.QFont()
        font.setFamily("Cambria")
        font.setPointSize(16)
        self.pbShuffle.setFont(font)
        icon3 = QtGui.QIcon()
        icon3.addPixmap(QtGui.QPixmap(":/Images/img/poker.png"), QtGui.QIcon.Normal, QtGui.QIcon.On)
        self.pbShuffle.setIcon(icon3)
        self.pbShuffle.setIconSize(QtCore.QSize(64, 64))
        self.pbShuffle.setObjectName("pbShuffle")
        self.verticalLayout.addWidget(self.pbShuffle)
        self.pbAbout = QtWidgets.QPushButton(self.centralwidget)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.pbAbout.sizePolicy().hasHeightForWidth())
        self.pbAbout.setSizePolicy(sizePolicy)
        self.pbAbout.setMinimumSize(QtCore.QSize(0, 120))
        font = QtGui.QFont()
        font.setFamily("Cambria")
        font.setPointSize(16)
        self.pbAbout.setFont(font)
        icon4 = QtGui.QIcon()
        icon4.addPixmap(QtGui.QPixmap(":/Images/img/copy.png"), QtGui.QIcon.Normal, QtGui.QIcon.On)
        self.pbAbout.setIcon(icon4)
        self.pbAbout.setIconSize(QtCore.QSize(64, 64))
        self.pbAbout.setObjectName("pbAbout")
        self.verticalLayout.addWidget(self.pbAbout)
        self.pbExit = QtWidgets.QPushButton(self.centralwidget)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.pbExit.sizePolicy().hasHeightForWidth())
        self.pbExit.setSizePolicy(sizePolicy)
        self.pbExit.setMinimumSize(QtCore.QSize(0, 120))
        font = QtGui.QFont()
        font.setFamily("Cambria")
        font.setPointSize(16)
        self.pbExit.setFont(font)
        icon5 = QtGui.QIcon()
        icon5.addPixmap(QtGui.QPixmap(":/Images/img/logout.png"), QtGui.QIcon.Normal, QtGui.QIcon.On)
        self.pbExit.setIcon(icon5)
        self.pbExit.setIconSize(QtCore.QSize(64, 64))
        self.pbExit.setObjectName("pbExit")
        self.verticalLayout.addWidget(self.pbExit)
        self.horizontalLayout.addLayout(self.verticalLayout)
        spacerItem1 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem1)
        MainWidget.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWidget)
        QtCore.QMetaObject.connectSlotsByName(MainWidget)

    def retranslateUi(self, MainWidget):
        _translate = QtCore.QCoreApplication.translate
        MainWidget.setWindowTitle(_translate("MainWidget", "Bubble Sort Demo..."))
        self.tbTitle.setText(_translate("MainWidget", "       GDP OF MAIN INDUSTRIAL COUNTRIES\n"
"                               (IN BILLIONS)"))
        self.pbStart.setText(_translate("MainWidget", "    START  "))
        self.pbStop.setText(_translate("MainWidget", "   STOP      "))
        self.pbShuffle.setText(_translate("MainWidget", "    SHUFFLE"))
        self.pbAbout.setText(_translate("MainWidget", "    ABOUT    "))
        self.pbExit.setText(_translate("MainWidget", "      EXIT       "))
```



思路：

```
注意QtCore.QMutex()的用法。
```



#### A.3-2

试着修改本实践，增加一个进度条，显示排序进展到总进程的百分之多少。

答案：

```python
#Ui_About.py
from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_About(object):
    def setupUi(self, About):
        About.setObjectName("About")
        About.resize(865, 393)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(About.sizePolicy().hasHeightForWidth())
        About.setSizePolicy(sizePolicy)
        About.setMinimumSize(QtCore.QSize(865, 393))
        About.setMaximumSize(QtCore.QSize(865, 393))
        About.setModal(False)
        self.textBrowser = QtWidgets.QTextBrowser(About)
        self.textBrowser.setGeometry(QtCore.QRect(160, 10, 681, 251))
        self.textBrowser.setObjectName("textBrowser")
        self.widget = QtWidgets.QWidget(About)
        self.widget.setGeometry(QtCore.QRect(20, 20, 111, 121))
        self.widget.setStyleSheet("background-image: url(:/Images/img/copy.png);")
        self.widget.setObjectName("widget")
        self.pbClose = QtWidgets.QPushButton(About)
        self.pbClose.setGeometry(QtCore.QRect(540, 277, 301, 101))
        font = QtGui.QFont()
        font.setFamily("Cambria")
        font.setPointSize(16)
        self.pbClose.setFont(font)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(":/Images/img/logout.png"), QtGui.QIcon.Normal, QtGui.QIcon.On)
        self.pbClose.setIcon(icon)
        self.pbClose.setIconSize(QtCore.QSize(64, 64))
        self.pbClose.setObjectName("pbClose")

        self.retranslateUi(About)
        QtCore.QMetaObject.connectSlotsByName(About)

    def retranslateUi(self, About):
        _translate = QtCore.QCoreApplication.translate
        About.setWindowTitle(_translate("About", "About ... "))
        self.textBrowser.setHtml(_translate("About", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'SimSun\'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt; font-weight:600;\">ABOUT THIS SOFTWARE</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:18pt;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt;\">The software was developped by Alex from Chongqing University.It was designed for educational purpose as an example for author\'s book. The licence is GPL.</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:12pt;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt;\">email: </span><span style=\" font-size:12pt; font-weight:600;\">chenbo@cqu.edu.cn   </span><span style=\" font-size:12pt;\">November, 2018</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p></body></html>"))
        self.pbClose.setText(_translate("About", "         CLOSE"))
```



```python
#About.py
from PyQt5 import QtWidgets
from Ui_About import Ui_About

class About(QtWidgets.QDialog,Ui_About):
    def __init__(self,parent):
        QtWidgets.QDialog.__init__(self,parent)
        self.setupUi(self)

    def on_pbClose_released(self):
        self.close()
```

```python
#SortRunner.py
from PyQt5 import QtCore
from Country import CompareState
import time

class SortRunner(QtCore.QThread):
    updateInformer = QtCore.pyqtSignal()
    def __init__(self, countries, parent,SortPercent):
        super().__init__(parent)
        self.countries = countries
        self.SortPercent=SortPercent
        self.SortPercent.setRange(0,len(self.countries))

    def run(self):
        for x in self.countries:
            x.compareState = CompareState.idle
        self.updateInformer.emit()
        time.sleep(0.2)
        per=0
        for i in range(len(self.countries)-1,0,-1):
            for j in range(0,i):
                self.countries[j].compareState = CompareState.prev
                self.countries[j+1].compareState = CompareState.next
                self.updateInformer.emit()
                time.sleep(0.5)
                if self.countries[j].fGdp < self.countries[j+1].fGdp:
                    self.countries[j],self.countries[j+1] = \
                        self.countries[j+1],self.countries[j]
                    self.updateInformer.emit()
                    time.sleep(0.5)
                self.countries[j].compareState = CompareState.idle
                self.countries[j+1].compareState = CompareState.idle
            self.countries[i].compareState = CompareState.fixed
            per+=1
            self.SortPercent.setValue(per)
        self.countries[0].compareState = CompareState.fixed
        per+=1
        self.SortPercent.setValue(per)
        self.updateInformer.emit()
        return
```

```python
#MainWidget.py
import os,random
from PyQt5 import QtWidgets,QtGui,QtCore
from PyQt5.QtWidgets import QSizePolicy
from Country import Country,CompareState
from SortRunner import SortRunner
import Ui_MainWidget
import About


class MainWidget(QtWidgets.QMainWindow,Ui_MainWidget.Ui_MainWidget):
    def __init__(self,parent=None):
        super(MainWidget,self).__init__(parent)
        self.setupUi(self)
        self.sortRunner = None
        self.panelCountries = []
        self.initCountries()
        self.setToIdleState()
        self.displayCountries()
        self.SortPercent.reset()

    def setToRunningState(self):
        self.pbStart.setEnabled(False)
        self.pbStop.setEnabled(True)
        self.pbShuffle.setEnabled(False)
        self.pbAbout.setEnabled(False)
        self.pbExit.setEnabled(False)

    def setToIdleState(self):
        self.pbStart.setEnabled(True)
        self.pbStop.setEnabled(False)
        self.pbShuffle.setEnabled(True)
        self.pbAbout.setEnabled(True)
        self.pbExit.setEnabled(True)

    def handlerUpdateInformer(self):
        self.displayCountries()

    def initCountries(self):
        self.countries = []

        import configparser
        data = configparser.ConfigParser()
        data.read("countries.ini")
        data = data["Countries"]
        iSize = int(data.get("countries.size",0))
        for i in range(iSize):
            name = data.get("countries[{}].sName".format(i),"ERROR").strip()
            gdp = float(data.get("countries[{}].fGdp".format(i),"0"))
            logofile = data.get("countries[{}].sLogoFile".format(i),"ERROR").strip()
            self.countries.append(Country(name,gdp,logofile))

    def createPanelCountries(self):
        for i in range(len(self.countries)):
            panel = QtWidgets.QToolButton(self.centralwidget)
            panel.setFixedHeight(52)
            panel.setSizePolicy(QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed))
            panel.setFont(QtGui.QFont("Cambria",16))
            panel.setIconSize(QtCore.QSize(64,48))
            panel.setToolButtonStyle(QtCore.Qt.ToolButtonTextBesideIcon)
            self.verticalLayoutCountries.addWidget(panel)
            self.panelCountries.append(panel)

    def displayCountries(self):
        if len(self.panelCountries) == 0:
            self.createPanelCountries()
        assert len(self.panelCountries) == len(self.countries)

        for x, y in zip(self.panelCountries,self.countries):
            x.setText(" " * 10 + "${:<30,.2f}{}".format(y.fGdp,y.sName))
            x.setIcon(QtGui.QIcon("img{}{}".format(os.sep,y.sLogoFile)))
            if y.compareState == CompareState.prev:
                x.setStyleSheet("background-color: rgb(255, 255, 0);")
            elif y.compareState == CompareState.next:
                x.setStyleSheet("background-color: rgb(255, 0, 0);")
            elif y.compareState == CompareState.fixed:
                x.setStyleSheet("background-color: rgb(0, 255, 0);")
            else:
                x.setStyleSheet("")


    def on_pbShuffle_released(self):
        self.SortPercent.reset()
        random.shuffle(self.countries)
        for x in self.countries:
            x.compareState = CompareState.idle
        self.displayCountries()

    def on_pbExit_released(self):
        self.close()

    def on_pbAbout_released(self):
        dlg = About.About(self)
        dlg.exec()

    def on_pbStop_released(self):
        assert self.sortRunner != None
        self.sortRunner.terminate()

    def on_pbStart_released(self):
        self.SortPercent.reset()
        if self.sortRunner != None:
            if not self.sortRunner.isFinished():
                self.sortRunner.terminate()
                assert self.sortRunner.wait(2000)

        self.setToRunningState()

        self.sortRunner = SortRunner(self.countries,self,self.SortPercent)
        self.sortRunner.updateInformer.connect(self.handlerUpdateInformer)
        self.sortRunner.finished.connect(self.setToIdleState)
        self.sortRunner.start()
```

```python
#Country.py
from enum import Enum

class CompareState(Enum):
    prev = 0   #the item in comparation as prev item
    next = 1   #the item in comparation as next item
    idle = 2   #the item is not in comparation
    fixed = 3  #the item's position have been settled by sort algorithm

class Country:
    def __init__(self,name,gdp,logofile):
        self.sName = name
        self.fGdp = gdp
        self.sLogoFile = logofile
        self.compareState = CompareState.idle

```

```python
#BubbleSort
import sys
from PyQt5 import QtWidgets
import MainWidget

app = QtWidgets.QApplication(sys.argv)

mw = MainWidget.MainWidget()
mw.show()

exit(app.exec_())
```

```
[Countries]
countries.size = 15
countries[0].sName = United States
countries[0].fGdp = 19555.874
countries[0].sLogoFile = img/us.gif
countries[1].sName = China
countries[1].fGdp = 13173.585
countries[1].sLogoFile =img/china.gif
countries[2].sName = Japan
countries[2].fGdp = 4342.16
countries[2].sLogoFile = img/japan.gif
countries[3].sName = Germany
countries[3].fGdp = 3595.406
countries[3].sLogoFile = img/german.gif
countries[4].sName = United Kingdom
countries[4].fGdp = 3232.281
countries[4].sLogoFile = img/gb.gif
countries[5].sName = India
countries[5].fGdp = 2607.409
countries[5].sLogoFile = img/india.gif
countries[6].sName = France
countries[6].fGdp = 2586.568
countries[6].sLogoFile = img/france.gif
countries[7].sName = Italy
countries[7].fGdp = 1932.938
countries[7].sLogoFile = img/italy.gif
countries[8].sName = Brazil
countries[8].fGdp = 1759.267
countries[8].sLogoFile = img/brazil.gif
countries[9].sName = Canada
countries[9].fGdp = 1682.368
countries[9].sLogoFile = img/canada.gif
countries[10].sName = Korea
countries[10].fGdp = 1545.81
countries[10].sLogoFile = img/korea.gif
countries[11].sName = Spain
countries[11].fGdp = 1318.826
countries[11].sLogoFile = img/spain.gif
countries[12].sName = Austrilia
countries[12].fGdp = 1317.158
countries[12].sLogoFile = img/austrilia.gif
countries[13].sName = Russia
countries[13].fGdp = 1309.268
countries[13].sLogoFile = img/russia.gif
countries[14].sName = Mexico
countries[14].fGdp =1251.253
countries[14].sLogoFile = img/mexico.gif

```

```python
#Ui_MainWidget.py

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_MainWidget(object):
    def setupUi(self, MainWidget):
        MainWidget.setObjectName("MainWidget")
        MainWidget.resize(978, 851)
        self.centralwidget = QtWidgets.QWidget(MainWidget)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.centralwidget.sizePolicy().hasHeightForWidth())
        self.centralwidget.setSizePolicy(sizePolicy)
        self.centralwidget.setObjectName("centralwidget")
        self.horizontalLayout = QtWidgets.QHBoxLayout(self.centralwidget)
        self.horizontalLayout.setContentsMargins(2, 2, 2, 2)
        self.horizontalLayout.setSpacing(2)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.verticalLayout_3 = QtWidgets.QVBoxLayout()
        self.verticalLayout_3.setSizeConstraint(QtWidgets.QLayout.SetMaximumSize)
        self.verticalLayout_3.setSpacing(0)
        self.verticalLayout_3.setObjectName("verticalLayout_3")
        self.tbTitle = QtWidgets.QToolButton(self.centralwidget)
        self.tbTitle.setEnabled(True)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.MinimumExpanding, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.tbTitle.sizePolicy().hasHeightForWidth())
        self.tbTitle.setSizePolicy(sizePolicy)
        self.tbTitle.setMinimumSize(QtCore.QSize(700, 80))
        font = QtGui.QFont()
        font.setFamily("Cambria")
        font.setPointSize(16)
        self.tbTitle.setFont(font)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(":/Images/img/globe.png"), QtGui.QIcon.Normal, QtGui.QIcon.On)
        self.tbTitle.setIcon(icon)
        self.tbTitle.setIconSize(QtCore.QSize(64, 64))
        self.tbTitle.setCheckable(True)
        self.tbTitle.setChecked(True)
        self.tbTitle.setToolButtonStyle(QtCore.Qt.ToolButtonTextBesideIcon)
        self.tbTitle.setObjectName("tbTitle")
        self.verticalLayout_3.addWidget(self.tbTitle)
        self.SortPercent = QtWidgets.QProgressBar(self.centralwidget)
        self.SortPercent.setProperty("value", 24)
        self.SortPercent.setObjectName("SortPercent")
        self.verticalLayout_3.addWidget(self.SortPercent)
        self.verticalLayoutCountries = QtWidgets.QVBoxLayout()
        self.verticalLayoutCountries.setSpacing(2)
        self.verticalLayoutCountries.setObjectName("verticalLayoutCountries")
        self.verticalLayout_3.addLayout(self.verticalLayoutCountries)
        self.horizontalLayout.addLayout(self.verticalLayout_3)
        spacerItem = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem)
        self.verticalLayout = QtWidgets.QVBoxLayout()
        self.verticalLayout.setObjectName("verticalLayout")
        self.pbStart = QtWidgets.QPushButton(self.centralwidget)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.pbStart.sizePolicy().hasHeightForWidth())
        self.pbStart.setSizePolicy(sizePolicy)
        self.pbStart.setMinimumSize(QtCore.QSize(0, 120))
        font = QtGui.QFont()
        font.setFamily("Cambria")
        font.setPointSize(16)
        self.pbStart.setFont(font)
        self.pbStart.setStyleSheet("")
        icon1 = QtGui.QIcon()
        icon1.addPixmap(QtGui.QPixmap(":/Images/img/start.png"), QtGui.QIcon.Normal, QtGui.QIcon.On)
        self.pbStart.setIcon(icon1)
        self.pbStart.setIconSize(QtCore.QSize(64, 64))
        self.pbStart.setObjectName("pbStart")
        self.verticalLayout.addWidget(self.pbStart)
        self.pbStop = QtWidgets.QPushButton(self.centralwidget)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.pbStop.sizePolicy().hasHeightForWidth())
        self.pbStop.setSizePolicy(sizePolicy)
        self.pbStop.setMinimumSize(QtCore.QSize(0, 120))
        font = QtGui.QFont()
        font.setFamily("Cambria")
        font.setPointSize(16)
        self.pbStop.setFont(font)
        icon2 = QtGui.QIcon()
        icon2.addPixmap(QtGui.QPixmap(":/Images/img/pause.png"), QtGui.QIcon.Normal, QtGui.QIcon.On)
        self.pbStop.setIcon(icon2)
        self.pbStop.setIconSize(QtCore.QSize(64, 64))
        self.pbStop.setObjectName("pbStop")
        self.verticalLayout.addWidget(self.pbStop)
        self.pbShuffle = QtWidgets.QPushButton(self.centralwidget)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.pbShuffle.sizePolicy().hasHeightForWidth())
        self.pbShuffle.setSizePolicy(sizePolicy)
        self.pbShuffle.setMinimumSize(QtCore.QSize(0, 120))
        font = QtGui.QFont()
        font.setFamily("Cambria")
        font.setPointSize(16)
        self.pbShuffle.setFont(font)
        icon3 = QtGui.QIcon()
        icon3.addPixmap(QtGui.QPixmap(":/Images/img/poker.png"), QtGui.QIcon.Normal, QtGui.QIcon.On)
        self.pbShuffle.setIcon(icon3)
        self.pbShuffle.setIconSize(QtCore.QSize(64, 64))
        self.pbShuffle.setObjectName("pbShuffle")
        self.verticalLayout.addWidget(self.pbShuffle)
        self.pbAbout = QtWidgets.QPushButton(self.centralwidget)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.pbAbout.sizePolicy().hasHeightForWidth())
        self.pbAbout.setSizePolicy(sizePolicy)
        self.pbAbout.setMinimumSize(QtCore.QSize(0, 120))
        font = QtGui.QFont()
        font.setFamily("Cambria")
        font.setPointSize(16)
        self.pbAbout.setFont(font)
        icon4 = QtGui.QIcon()
        icon4.addPixmap(QtGui.QPixmap(":/Images/img/copy.png"), QtGui.QIcon.Normal, QtGui.QIcon.On)
        self.pbAbout.setIcon(icon4)
        self.pbAbout.setIconSize(QtCore.QSize(64, 64))
        self.pbAbout.setObjectName("pbAbout")
        self.verticalLayout.addWidget(self.pbAbout)
        self.pbExit = QtWidgets.QPushButton(self.centralwidget)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.pbExit.sizePolicy().hasHeightForWidth())
        self.pbExit.setSizePolicy(sizePolicy)
        self.pbExit.setMinimumSize(QtCore.QSize(0, 120))
        font = QtGui.QFont()
        font.setFamily("Cambria")
        font.setPointSize(16)
        self.pbExit.setFont(font)
        icon5 = QtGui.QIcon()
        icon5.addPixmap(QtGui.QPixmap(":/Images/img/logout.png"), QtGui.QIcon.Normal, QtGui.QIcon.On)
        self.pbExit.setIcon(icon5)
        self.pbExit.setIconSize(QtCore.QSize(64, 64))
        self.pbExit.setObjectName("pbExit")
        self.verticalLayout.addWidget(self.pbExit)
        self.horizontalLayout.addLayout(self.verticalLayout)
        spacerItem1 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem1)
        MainWidget.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWidget)
        QtCore.QMetaObject.connectSlotsByName(MainWidget)

    def retranslateUi(self, MainWidget):
        _translate = QtCore.QCoreApplication.translate
        MainWidget.setWindowTitle(_translate("MainWidget", "Bubble Sort Demo..."))
        self.tbTitle.setText(_translate("MainWidget", "       GDP OF MAIN INDUSTRIAL COUNTRIES\n"
"                               (IN BILLIONS)"))
        self.pbStart.setText(_translate("MainWidget", "    START  "))
        self.pbStop.setText(_translate("MainWidget", "   STOP      "))
        self.pbShuffle.setText(_translate("MainWidget", "    SHUFFLE"))
        self.pbAbout.setText(_translate("MainWidget", "    ABOUT    "))
        self.pbExit.setText(_translate("MainWidget", "      EXIT       "))
```

思路：

```
了解QtWidgets.QProgressBar()的用法。
```

#### A.3-3

本实践中，为了实现排序进程的演示并保证界面的及时响应，我们启用了排序线程。就本实践而言，使用定
时器可以达到类似目的。请修改程序，改用定时器实现相同功能。提示：资料查询关键词QTimer, PyQt5。

答案：

```python
#About.py
from PyQt5 import QtWidgets
from Ui_About import Ui_About

class About(QtWidgets.QDialog,Ui_About):
    def __init__(self,parent):
        QtWidgets.QDialog.__init__(self,parent)
        self.setupUi(self)

    def on_pbClose_released(self):
        self.close()

```

```python
#BubbleSort.py
import sys
from PyQt5 import QtWidgets
import MainWidget

app = QtWidgets.QApplication(sys.argv)

mw = MainWidget.MainWidget()
mw.show()

exit(app.exec_())
```

```
#countries.ini
[Countries]
countries.size = 15
countries[0].sName = United States
countries[0].fGdp = 19555.874
countries[0].sLogoFile = us.gif
countries[1].sName = China
countries[1].fGdp = 13173.585
countries[1].sLogoFile = china.gif
countries[2].sName = Japan
countries[2].fGdp = 4342.16
countries[2].sLogoFile = japan.gif
countries[3].sName = Germany
countries[3].fGdp = 3595.406
countries[3].sLogoFile = german.gif
countries[4].sName = United Kingdom
countries[4].fGdp = 3232.281
countries[4].sLogoFile = gb.gif
countries[5].sName = India
countries[5].fGdp = 2607.409
countries[5].sLogoFile = india.gif
countries[6].sName = France
countries[6].fGdp = 2586.568
countries[6].sLogoFile = france.gif
countries[7].sName = Italy
countries[7].fGdp = 1932.938
countries[7].sLogoFile = italy.gif
countries[8].sName = Brazil
countries[8].fGdp = 1759.267
countries[8].sLogoFile = brazil.gif
countries[9].sName = Canada
countries[9].fGdp = 1682.368
countries[9].sLogoFile = canada.gif
countries[10].sName = Korea
countries[10].fGdp = 1545.81
countries[10].sLogoFile = korea.gif
countries[11].sName = Spain
countries[11].fGdp = 1318.826
countries[11].sLogoFile = spain.gif
countries[12].sName = Austrilia
countries[12].fGdp = 1317.158
countries[12].sLogoFile = austrilia.gif
countries[13].sName = Russia
countries[13].fGdp = 1309.268
countries[13].sLogoFile = russia.gif
countries[14].sName = Mexico
countries[14].fGdp =1251.253
countries[14].sLogoFile = mexico.gif

```

```python
#Country.py
from enum import Enum

class CompareState(Enum):
    prev = 0   #the item in comparation as prev item
    next = 1   #the item in comparation as next item
    idle = 2   #the item is not in comparation
    fixed = 3  #the item's position have been settled by sort algorithm

class Country:
    def __init__(self,name,gdp,logofile,compareState=2):
        self.sName = name
        self.fGdp = gdp
        self.sLogoFile = logofile
        self.compareState = compareState

```

```python
#MainWidget.py
import os,random
from PyQt5 import QtWidgets,QtGui,QtCore
from PyQt5.QtWidgets import QSizePolicy
from Country import Country,CompareState
from SortRunner import SortRunner
import Ui_MainWidget
import About
from PyQt5.QtCore import QTimer
import time

class MainWidget(QtWidgets.QMainWindow,Ui_MainWidget.Ui_MainWidget):
    def __init__(self,parent=None):
        super(MainWidget,self).__init__(parent)
        self.setupUi(self)
        self.sortRunner = None
        self.panelCountries = []
        self.genrate=None
        self.initCountries()
        self.setToIdleState()
        self.displayCountries(self.countries)

    def setToRunningState(self):
        self.pbStart.setEnabled(False)
        self.pbStop.setEnabled(True)
        self.pbShuffle.setEnabled(False)
        self.pbAbout.setEnabled(False)
        self.pbExit.setEnabled(False)

    def setToIdleState(self):
        self.pbStart.setEnabled(True)
        self.pbStop.setEnabled(False)
        self.pbShuffle.setEnabled(True)
        self.pbAbout.setEnabled(True)
        self.pbExit.setEnabled(True)


    def initCountries(self):
        self.countries = []

        import configparser
        data = configparser.ConfigParser()
        data.read("countries.ini")
        data = data["Countries"]
        iSize = int(data.get("countries.size",0))
        for i in range(iSize):
            name = data.get("countries[{}].sName".format(i),"ERROR").strip()
            gdp = float(data.get("countries[{}].fGdp".format(i),"0"))
            logofile = data.get("countries[{}].sLogoFile".format(i),"ERROR").strip()
            self.countries.append(Country(name,gdp,logofile))

    def createPanelCountries(self):
        for i in range(len(self.countries)):
            panel = QtWidgets.QToolButton(self.centralwidget)
            panel.setFixedHeight(52)
            panel.setSizePolicy(QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed))
            panel.setFont(QtGui.QFont("Cambria",16))
            panel.setIconSize(QtCore.QSize(64,48))
            panel.setToolButtonStyle(QtCore.Qt.ToolButtonTextBesideIcon)
            self.verticalLayoutCountries.addWidget(panel)
            self.panelCountries.append(panel)


    def on_pbShuffle_released(self):
        random.shuffle(self.countries)
        for x in self.countries:
            x.compareState = CompareState.idle
        self.displayCountries(self.countries)

    def on_pbExit_released(self):
        self.close()

    def on_pbAbout_released(self):
        dlg = About.About(self)
        dlg.exec()

    def on_pbStop_released(self):
        self.Timer.stop()
        self.setToIdleState()
        #assert self.sortRunner != None
        #self.sortRunner.terminate()

    def displayCountries(self,Countries):

        if len(self.panelCountries) == 0:
            self.createPanelCountries()
        assert len(self.panelCountries) == len(Countries)
        #print("展示")
        for x, y in zip(self.panelCountries,Countries):
            x.setText(" " * 10 + "${:<30,.2f}{}".format(y.fGdp,y.sName))
            x.setIcon(QtGui.QIcon("img{}{}".format(os.sep,y.sLogoFile)))
            #print(x.setText,y.sName)
            if y.compareState == CompareState.prev:
                x.setStyleSheet("background-color: rgb(255, 255, 0);")
            elif y.compareState == CompareState.next:
                x.setStyleSheet("background-color: rgb(255, 0, 0);")
            elif y.compareState == CompareState.fixed:
                x.setStyleSheet("background-color: rgb(0, 255, 0);")
            else:
                x.setStyleSheet("")
           # print("过程")
        #print("结束")
        #self.setToIdleState()


    def Iteratot_Show(self):
        print(len(self.temp))
        try:
            print(self.idx)
            countries=self.temp [self.idx]
            self.idx+=1
        except (StopIteration, Exception) as e:
            self.Timer.stop()
            self.setToIdleState()
        else:
            #print(len(self.countries))
            self.displayCountries(countries)

    def on_pbStart_released(self):
        '''
        if self.sortRunner != None:
            if not self.sortRunner.isFinished():
                self.sortRunner.terminate()
                assert self.sortRunner.wait(2000)
        '''
        self.setToRunningState()
        self.sortRunner = SortRunner(self.countries.copy())
        self.temp = self.sortRunner.Sort()
        self.Timer=QTimer()
        self.idx = 0
        self.Timer.start(500)
        self.Timer.timeout.connect(self.Iteratot_Show)
```

```python
#SortRunner.py
from PyQt5 import QtCore
from Country import CompareState
from copy import deepcopy

class SortRunner():
    updateInformer = QtCore.pyqtSignal()
    def __init__(self, countries):
        self.countries = countries

    def Sort(self):
        self.lst=[]
        for x in self.countries:
            x.compareState = CompareState.idle
        self.lst.append(deepcopy(self.countries.copy()))
        for i in range(len(self.countries)-1,0,-1):
            for j in range(0,i):
                self.countries[j].compareState = CompareState.prev
                self.countries[j+1].compareState = CompareState.next
                self.lst.append(deepcopy(self.countries.copy()))
                if self.countries[j].fGdp < self.countries[j+1].fGdp:
                    self.countries[j],self.countries[j+1] = \
                        self.countries[j+1],self.countries[j]
                    self.lst.append(deepcopy(self.countries.copy()))
                self.countries[j].compareState = CompareState.idle
                self.countries[j+1].compareState = CompareState.idle
            self.countries[i].compareState = CompareState.fixed

        self.countries[0].compareState = CompareState.fixed
        self.lst.append(deepcopy(self.countries.copy()))
        return self.lst
```

```python
#Ui_About.py
from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_About(object):
    def setupUi(self, About):
        About.setObjectName("About")
        About.resize(865, 393)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(About.sizePolicy().hasHeightForWidth())
        About.setSizePolicy(sizePolicy)
        About.setMinimumSize(QtCore.QSize(865, 393))
        About.setMaximumSize(QtCore.QSize(865, 393))
        About.setModal(False)
        self.textBrowser = QtWidgets.QTextBrowser(About)
        self.textBrowser.setGeometry(QtCore.QRect(160, 10, 681, 251))
        self.textBrowser.setObjectName("textBrowser")
        self.widget = QtWidgets.QWidget(About)
        self.widget.setGeometry(QtCore.QRect(20, 20, 111, 121))
        self.widget.setStyleSheet("background-image: url(:/Images/img/copy.png);")
        self.widget.setObjectName("widget")
        self.pbClose = QtWidgets.QPushButton(About)
        self.pbClose.setGeometry(QtCore.QRect(540, 277, 301, 101))
        font = QtGui.QFont()
        font.setFamily("Cambria")
        font.setPointSize(16)
        self.pbClose.setFont(font)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(":/Images/img/logout.png"), QtGui.QIcon.Normal, QtGui.QIcon.On)
        self.pbClose.setIcon(icon)
        self.pbClose.setIconSize(QtCore.QSize(64, 64))
        self.pbClose.setObjectName("pbClose")

        self.retranslateUi(About)
        QtCore.QMetaObject.connectSlotsByName(About)

    def retranslateUi(self, About):
        _translate = QtCore.QCoreApplication.translate
        About.setWindowTitle(_translate("About", "About ... "))
        self.textBrowser.setHtml(_translate("About", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'SimSun\'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt; font-weight:600;\">ABOUT THIS SOFTWARE</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:18pt;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt;\">The software was developped by Alex from Chongqing University.It was designed for educational purpose as an example for author\'s book. The licence is GPL.</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:12pt;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt;\">email: </span><span style=\" font-size:12pt; font-weight:600;\">chenbo@cqu.edu.cn   </span><span style=\" font-size:12pt;\">November, 2018</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p></body></html>"))
        self.pbClose.setText(_translate("About", "         CLOSE"))
```

```python
#Ui_MainWidget.py
from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_MainWidget(object):
    def setupUi(self, MainWidget):
        MainWidget.setObjectName("MainWidget")
        MainWidget.resize(1077, 932)
        self.centralwidget = QtWidgets.QWidget(MainWidget)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.centralwidget.sizePolicy().hasHeightForWidth())
        self.centralwidget.setSizePolicy(sizePolicy)
        self.centralwidget.setObjectName("centralwidget")
        self.horizontalLayout = QtWidgets.QHBoxLayout(self.centralwidget)
        self.horizontalLayout.setContentsMargins(2, 2, 2, 2)
        self.horizontalLayout.setSpacing(2)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.verticalLayout_3 = QtWidgets.QVBoxLayout()
        self.verticalLayout_3.setSizeConstraint(QtWidgets.QLayout.SetMaximumSize)
        self.verticalLayout_3.setSpacing(0)
        self.verticalLayout_3.setObjectName("verticalLayout_3")
        self.tbTitle = QtWidgets.QToolButton(self.centralwidget)
        self.tbTitle.setEnabled(True)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.MinimumExpanding, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.tbTitle.sizePolicy().hasHeightForWidth())
        self.tbTitle.setSizePolicy(sizePolicy)
        self.tbTitle.setMinimumSize(QtCore.QSize(700, 80))
        font = QtGui.QFont()
        font.setFamily("Cambria")
        font.setPointSize(16)
        self.tbTitle.setFont(font)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(":/Images/img/globe.png"), QtGui.QIcon.Normal, QtGui.QIcon.On)
        self.tbTitle.setIcon(icon)
        self.tbTitle.setIconSize(QtCore.QSize(64, 64))
        self.tbTitle.setCheckable(True)
        self.tbTitle.setChecked(True)
        self.tbTitle.setToolButtonStyle(QtCore.Qt.ToolButtonTextBesideIcon)
        self.tbTitle.setObjectName("tbTitle")
        self.verticalLayout_3.addWidget(self.tbTitle)
        self.verticalLayoutCountries = QtWidgets.QVBoxLayout()
        self.verticalLayoutCountries.setSpacing(2)
        self.verticalLayoutCountries.setObjectName("verticalLayoutCountries")
        self.verticalLayout_3.addLayout(self.verticalLayoutCountries)
        self.horizontalLayout.addLayout(self.verticalLayout_3)
        spacerItem = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem)
        self.verticalLayout = QtWidgets.QVBoxLayout()
        self.verticalLayout.setObjectName("verticalLayout")
        self.pbStart = QtWidgets.QPushButton(self.centralwidget)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.pbStart.sizePolicy().hasHeightForWidth())
        self.pbStart.setSizePolicy(sizePolicy)
        self.pbStart.setMinimumSize(QtCore.QSize(0, 120))
        font = QtGui.QFont()
        font.setFamily("Cambria")
        font.setPointSize(16)
        self.pbStart.setFont(font)
        self.pbStart.setStyleSheet("")
        icon1 = QtGui.QIcon()
        icon1.addPixmap(QtGui.QPixmap(":/Images/img/start.png"), QtGui.QIcon.Normal, QtGui.QIcon.On)
        self.pbStart.setIcon(icon1)
        self.pbStart.setIconSize(QtCore.QSize(64, 64))
        self.pbStart.setObjectName("pbStart")
        self.verticalLayout.addWidget(self.pbStart)
        self.pbStop = QtWidgets.QPushButton(self.centralwidget)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.pbStop.sizePolicy().hasHeightForWidth())
        self.pbStop.setSizePolicy(sizePolicy)
        self.pbStop.setMinimumSize(QtCore.QSize(0, 120))
        font = QtGui.QFont()
        font.setFamily("Cambria")
        font.setPointSize(16)
        self.pbStop.setFont(font)
        icon2 = QtGui.QIcon()
        icon2.addPixmap(QtGui.QPixmap(":/Images/img/pause.png"), QtGui.QIcon.Normal, QtGui.QIcon.On)
        self.pbStop.setIcon(icon2)
        self.pbStop.setIconSize(QtCore.QSize(64, 64))
        self.pbStop.setObjectName("pbStop")
        self.verticalLayout.addWidget(self.pbStop)
        self.pbShuffle = QtWidgets.QPushButton(self.centralwidget)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.pbShuffle.sizePolicy().hasHeightForWidth())
        self.pbShuffle.setSizePolicy(sizePolicy)
        self.pbShuffle.setMinimumSize(QtCore.QSize(0, 120))
        font = QtGui.QFont()
        font.setFamily("Cambria")
        font.setPointSize(16)
        self.pbShuffle.setFont(font)
        icon3 = QtGui.QIcon()
        icon3.addPixmap(QtGui.QPixmap(":/Images/img/poker.png"), QtGui.QIcon.Normal, QtGui.QIcon.On)
        self.pbShuffle.setIcon(icon3)
        self.pbShuffle.setIconSize(QtCore.QSize(64, 64))
        self.pbShuffle.setObjectName("pbShuffle")
        self.verticalLayout.addWidget(self.pbShuffle)
        self.pbAbout = QtWidgets.QPushButton(self.centralwidget)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.pbAbout.sizePolicy().hasHeightForWidth())
        self.pbAbout.setSizePolicy(sizePolicy)
        self.pbAbout.setMinimumSize(QtCore.QSize(0, 120))
        font = QtGui.QFont()
        font.setFamily("Cambria")
        font.setPointSize(16)
        self.pbAbout.setFont(font)
        icon4 = QtGui.QIcon()
        icon4.addPixmap(QtGui.QPixmap(":/Images/img/copy.png"), QtGui.QIcon.Normal, QtGui.QIcon.On)
        self.pbAbout.setIcon(icon4)
        self.pbAbout.setIconSize(QtCore.QSize(64, 64))
        self.pbAbout.setObjectName("pbAbout")
        self.verticalLayout.addWidget(self.pbAbout)
        self.pbExit = QtWidgets.QPushButton(self.centralwidget)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.pbExit.sizePolicy().hasHeightForWidth())
        self.pbExit.setSizePolicy(sizePolicy)
        self.pbExit.setMinimumSize(QtCore.QSize(0, 120))
        font = QtGui.QFont()
        font.setFamily("Cambria")
        font.setPointSize(16)
        self.pbExit.setFont(font)
        icon5 = QtGui.QIcon()
        icon5.addPixmap(QtGui.QPixmap(":/Images/img/logout.png"), QtGui.QIcon.Normal, QtGui.QIcon.On)
        self.pbExit.setIcon(icon5)
        self.pbExit.setIconSize(QtCore.QSize(64, 64))
        self.pbExit.setObjectName("pbExit")
        self.verticalLayout.addWidget(self.pbExit)
        self.horizontalLayout.addLayout(self.verticalLayout)
        spacerItem1 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem1)
        MainWidget.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWidget)
        QtCore.QMetaObject.connectSlotsByName(MainWidget)

    def retranslateUi(self, MainWidget):
        _translate = QtCore.QCoreApplication.translate
        MainWidget.setWindowTitle(_translate("MainWidget", "Bubble Sort Demo..."))
        self.tbTitle.setText(_translate("MainWidget", "       GDP OF MAIN INDUSTRIAL COUNTRIES\n"
"                               (IN BILLIONS)"))
        self.pbStart.setText(_translate("MainWidget", "    START  "))
        self.pbStop.setText(_translate("MainWidget", "   STOP      "))
        self.pbShuffle.setText(_translate("MainWidget", "    SHUFFLE"))
        self.pbAbout.setText(_translate("MainWidget", "    ABOUT    "))
        self.pbExit.setText(_translate("MainWidget", "      EXIT       "))

```

思路：

```
使用一个列表记录排序过程Countries的变化情况，然后通过定时器间隔的展示出来，注意类对象的浅拷贝和深拷贝。
```

#### A.3-4

在实践中，人们极少自行编写排序代码进行排序，而是尽可能地借助于列表的sort函数实现排序。就本实践
MainWidget.py中的self.countries列表，请借助于列表的sort()函数，将该列表按GDP升序排序。提示：key参数可以指向某个自定义函数或者lambda函数，该函数接受一个Country对象参数，返回该对象的GDP值。答案：

```python
#Ui_About.py
from PyQt5 import QtWidgets
from Ui_About import Ui_About

class About(QtWidgets.QDialog,Ui_About):
    def __init__(self,parent):
        QtWidgets.QDialog.__init__(self,parent)
        self.setupUi(self)

    def on_pbClose_released(self):
        self.close()

```

```python
#BubbleSort
import sys
from PyQt5 import QtWidgets
import MainWidget

app = QtWidgets.QApplication(sys.argv)

mw = MainWidget.MainWidget()
mw.show()

exit(app.exec_())


```

```
#countries.ini
[Countries]
countries.size = 15
countries[0].sName = United States
countries[0].fGdp = 19555.874
countries[0].sLogoFile = us.gif
countries[1].sName = China
countries[1].fGdp = 13173.585
countries[1].sLogoFile = china.gif
countries[2].sName = Japan
countries[2].fGdp = 4342.16
countries[2].sLogoFile = japan.gif
countries[3].sName = Germany
countries[3].fGdp = 3595.406
countries[3].sLogoFile = german.gif
countries[4].sName = United Kingdom
countries[4].fGdp = 3232.281
countries[4].sLogoFile = gb.gif
countries[5].sName = India
countries[5].fGdp = 2607.409
countries[5].sLogoFile = india.gif
countries[6].sName = France
countries[6].fGdp = 2586.568
countries[6].sLogoFile = france.gif
countries[7].sName = Italy
countries[7].fGdp = 1932.938
countries[7].sLogoFile = italy.gif
countries[8].sName = Brazil
countries[8].fGdp = 1759.267
countries[8].sLogoFile = brazil.gif
countries[9].sName = Canada
countries[9].fGdp = 1682.368
countries[9].sLogoFile = canada.gif
countries[10].sName = Korea
countries[10].fGdp = 1545.81
countries[10].sLogoFile = korea.gif
countries[11].sName = Spain
countries[11].fGdp = 1318.826
countries[11].sLogoFile = spain.gif
countries[12].sName = Austrilia
countries[12].fGdp = 1317.158
countries[12].sLogoFile = austrilia.gif
countries[13].sName = Russia
countries[13].fGdp = 1309.268
countries[13].sLogoFile = russia.gif
countries[14].sName = Mexico
countries[14].fGdp =1251.253
countries[14].sLogoFile = mexico.gif
```

```python
#Country.py
from enum import Enum

class CompareState(Enum):
    prev = 0   #the item in comparation as prev item
    next = 1   #the item in comparation as next item
    idle = 2   #the item is not in comparation
    fixed = 3  #the item's position have been settled by sort algorithm

class Country:
    def __init__(self,name,gdp,logofile):
        self.sName = name
        self.fGdp = gdp
        self.sLogoFile = logofile
        self.compareState = CompareState.idle

```

```python
#MainWidget.py
import os,random
from PyQt5 import QtWidgets,QtGui,QtCore
from PyQt5.QtWidgets import QSizePolicy
from Country import Country,CompareState
from SortRunner import SortRunner
import Ui_MainWidget
import About



class MainWidget(QtWidgets.QMainWindow,Ui_MainWidget.Ui_MainWidget):
    def __init__(self,parent=None):
        super(MainWidget,self).__init__(parent)
        self.setupUi(self)
        self.sortRunner = None
        self.mutex=QtCore.QMutex()
        self.panelCountries = []
        self.initCountries()
        self.setToIdleState()
        self.displayCountries()


    def setToRunningState(self):
        self.pbStart.setEnabled(False)
        self.pbStop.setEnabled(True)
        self.pbShuffle.setEnabled(False)
        self.pbAbout.setEnabled(False)
        self.pbExit.setEnabled(False)

    def setToIdleState(self):
        self.pbStart.setEnabled(True)
        self.pbStop.setEnabled(False)
        self.pbShuffle.setEnabled(True)
        self.pbAbout.setEnabled(True)
        self.pbExit.setEnabled(True)

    def handlerUpdateInformer(self):
        self.displayCountries()

    def initCountries(self):
        self.countries = []

        import configparser
        data = configparser.ConfigParser()
        data.read("countries.ini")
        data = data["Countries"]
        iSize = int(data.get("countries.size",0))
        for i in range(iSize):
            name = data.get("countries[{}].sName".format(i),"ERROR").strip()
            gdp = float(data.get("countries[{}].fGdp".format(i),"0"))
            logofile = data.get("countries[{}].sLogoFile".format(i),"ERROR").strip()
            self.countries.append(Country(name,gdp,logofile))

    def createPanelCountries(self):
        for i in range(len(self.countries)):
            panel = QtWidgets.QToolButton(self.centralwidget)
            panel.setFixedHeight(52)
            panel.setSizePolicy(QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed))
            panel.setFont(QtGui.QFont("Cambria",16))
            panel.setIconSize(QtCore.QSize(64,48))
            panel.setToolButtonStyle(QtCore.Qt.ToolButtonTextBesideIcon)
            self.verticalLayoutCountries.addWidget(panel)
            self.panelCountries.append(panel)

    def displayCountries(self):
        self.mutex.lock()
        if len(self.panelCountries) == 0:
            self.createPanelCountries()
        assert len(self.panelCountries) == len(self.countries)

        for x, y in zip(self.panelCountries,self.countries):
            x.setText(" " * 10 + "${:<30,.2f}{}".format(y.fGdp,y.sName))
            x.setIcon(QtGui.QIcon("img{}{}".format(os.sep,y.sLogoFile)))
            if y.compareState == CompareState.prev:
                x.setStyleSheet("background-color: rgb(255, 255, 0);")
            elif y.compareState == CompareState.next:
                x.setStyleSheet("background-color: rgb(255, 0, 0);")
            elif y.compareState == CompareState.fixed:
                x.setStyleSheet("background-color: rgb(0, 255, 0);")
            else:
                x.setStyleSheet("")
        self.mutex.unlock()


    def on_pbShuffle_released(self):
        random.shuffle(self.countries)
        for x in self.countries:
            x.compareState = CompareState.idle
        self.displayCountries()

    def on_pbExit_released(self):
        self.close()

    def on_pbAbout_released(self):
        dlg = About.About(self)
        dlg.exec()

    def on_pbStop_released(self):
        assert self.sortRunner != None
        self.sortRunner.terminate()

    def on_pbStart_released(self):
        if self.sortRunner != None:
            if not self.sortRunner.isFinished():
                self.sortRunner.terminate()
                assert self.sortRunner.wait(2000)

        self.setToRunningState()

        self.sortRunner = SortRunner(self.countries,self,self.mutex)
        self.sortRunner.updateInformer.connect(self.handlerUpdateInformer)
        self.sortRunner.finished.connect(self.setToIdleState)
        self.sortRunner.start()
```

```python
#SortRunner.py
from PyQt5 import QtCore
from Country import CompareState
import time

class SortRunner(QtCore.QThread):
    updateInformer = QtCore.pyqtSignal()
    def __init__(self, countries, parent,mutex):
        super().__init__(parent)
        self.countries = countries
        self.mutex=mutex

    def run(self):
        self.mutex.lock()
        for x in self.countries:
            x.compareState = CompareState.idle
        self.mutex.unlock()
        self.updateInformer.emit()
        time.sleep(0.2)
        self.mutex.lock()
        self.countries.sort(key=lambda x:x.fGdp,reverse=True)
        for i in range(len(self.countries)):
            self.countries[i].compareState = CompareState.fixed
        self.mutex.unlock()
        self.updateInformer.emit()
        return


```

```python
#Ui_About.py

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_About(object):
    def setupUi(self, About):
        About.setObjectName("About")
        About.resize(865, 393)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(About.sizePolicy().hasHeightForWidth())
        About.setSizePolicy(sizePolicy)
        About.setMinimumSize(QtCore.QSize(865, 393))
        About.setMaximumSize(QtCore.QSize(865, 393))
        About.setModal(False)
        self.textBrowser = QtWidgets.QTextBrowser(About)
        self.textBrowser.setGeometry(QtCore.QRect(160, 10, 681, 251))
        self.textBrowser.setObjectName("textBrowser")
        self.widget = QtWidgets.QWidget(About)
        self.widget.setGeometry(QtCore.QRect(20, 20, 111, 121))
        self.widget.setStyleSheet("background-image: url(:/Images/img/copy.png);")
        self.widget.setObjectName("widget")
        self.pbClose = QtWidgets.QPushButton(About)
        self.pbClose.setGeometry(QtCore.QRect(540, 277, 301, 101))
        font = QtGui.QFont()
        font.setFamily("Cambria")
        font.setPointSize(16)
        self.pbClose.setFont(font)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(":/Images/img/logout.png"), QtGui.QIcon.Normal, QtGui.QIcon.On)
        self.pbClose.setIcon(icon)
        self.pbClose.setIconSize(QtCore.QSize(64, 64))
        self.pbClose.setObjectName("pbClose")

        self.retranslateUi(About)
        QtCore.QMetaObject.connectSlotsByName(About)

    def retranslateUi(self, About):
        _translate = QtCore.QCoreApplication.translate
        About.setWindowTitle(_translate("About", "About ... "))
        self.textBrowser.setHtml(_translate("About", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'SimSun\'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt; font-weight:600;\">ABOUT THIS SOFTWARE</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:18pt;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt;\">The software was developped by Alex from Chongqing University.It was designed for educational purpose as an example for author\'s book. The licence is GPL.</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:12pt;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt;\">email: </span><span style=\" font-size:12pt; font-weight:600;\">chenbo@cqu.edu.cn   </span><span style=\" font-size:12pt;\">November, 2018</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p></body></html>"))
        self.pbClose.setText(_translate("About", "         CLOSE"))


```

```python
#Ui_MainWidget.py

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_MainWidget(object):
    def setupUi(self, MainWidget):
        MainWidget.setObjectName("MainWidget")
        MainWidget.resize(1077, 932)
        self.centralwidget = QtWidgets.QWidget(MainWidget)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.centralwidget.sizePolicy().hasHeightForWidth())
        self.centralwidget.setSizePolicy(sizePolicy)
        self.centralwidget.setObjectName("centralwidget")
        self.horizontalLayout = QtWidgets.QHBoxLayout(self.centralwidget)
        self.horizontalLayout.setContentsMargins(2, 2, 2, 2)
        self.horizontalLayout.setSpacing(2)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.verticalLayout_3 = QtWidgets.QVBoxLayout()
        self.verticalLayout_3.setSizeConstraint(QtWidgets.QLayout.SetMaximumSize)
        self.verticalLayout_3.setSpacing(0)
        self.verticalLayout_3.setObjectName("verticalLayout_3")
        self.tbTitle = QtWidgets.QToolButton(self.centralwidget)
        self.tbTitle.setEnabled(True)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.MinimumExpanding, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.tbTitle.sizePolicy().hasHeightForWidth())
        self.tbTitle.setSizePolicy(sizePolicy)
        self.tbTitle.setMinimumSize(QtCore.QSize(700, 80))
        font = QtGui.QFont()
        font.setFamily("Cambria")
        font.setPointSize(16)
        self.tbTitle.setFont(font)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(":/Images/img/globe.png"), QtGui.QIcon.Normal, QtGui.QIcon.On)
        self.tbTitle.setIcon(icon)
        self.tbTitle.setIconSize(QtCore.QSize(64, 64))
        self.tbTitle.setCheckable(True)
        self.tbTitle.setChecked(True)
        self.tbTitle.setToolButtonStyle(QtCore.Qt.ToolButtonTextBesideIcon)
        self.tbTitle.setObjectName("tbTitle")
        self.verticalLayout_3.addWidget(self.tbTitle)
        self.verticalLayoutCountries = QtWidgets.QVBoxLayout()
        self.verticalLayoutCountries.setSpacing(2)
        self.verticalLayoutCountries.setObjectName("verticalLayoutCountries")
        self.verticalLayout_3.addLayout(self.verticalLayoutCountries)
        self.horizontalLayout.addLayout(self.verticalLayout_3)
        spacerItem = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem)
        self.verticalLayout = QtWidgets.QVBoxLayout()
        self.verticalLayout.setObjectName("verticalLayout")
        self.pbStart = QtWidgets.QPushButton(self.centralwidget)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.pbStart.sizePolicy().hasHeightForWidth())
        self.pbStart.setSizePolicy(sizePolicy)
        self.pbStart.setMinimumSize(QtCore.QSize(0, 120))
        font = QtGui.QFont()
        font.setFamily("Cambria")
        font.setPointSize(16)
        self.pbStart.setFont(font)
        self.pbStart.setStyleSheet("")
        icon1 = QtGui.QIcon()
        icon1.addPixmap(QtGui.QPixmap(":/Images/img/start.png"), QtGui.QIcon.Normal, QtGui.QIcon.On)
        self.pbStart.setIcon(icon1)
        self.pbStart.setIconSize(QtCore.QSize(64, 64))
        self.pbStart.setObjectName("pbStart")
        self.verticalLayout.addWidget(self.pbStart)
        self.pbStop = QtWidgets.QPushButton(self.centralwidget)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.pbStop.sizePolicy().hasHeightForWidth())
        self.pbStop.setSizePolicy(sizePolicy)
        self.pbStop.setMinimumSize(QtCore.QSize(0, 120))
        font = QtGui.QFont()
        font.setFamily("Cambria")
        font.setPointSize(16)
        self.pbStop.setFont(font)
        icon2 = QtGui.QIcon()
        icon2.addPixmap(QtGui.QPixmap(":/Images/img/pause.png"), QtGui.QIcon.Normal, QtGui.QIcon.On)
        self.pbStop.setIcon(icon2)
        self.pbStop.setIconSize(QtCore.QSize(64, 64))
        self.pbStop.setObjectName("pbStop")
        self.verticalLayout.addWidget(self.pbStop)
        self.pbShuffle = QtWidgets.QPushButton(self.centralwidget)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.pbShuffle.sizePolicy().hasHeightForWidth())
        self.pbShuffle.setSizePolicy(sizePolicy)
        self.pbShuffle.setMinimumSize(QtCore.QSize(0, 120))
        font = QtGui.QFont()
        font.setFamily("Cambria")
        font.setPointSize(16)
        self.pbShuffle.setFont(font)
        icon3 = QtGui.QIcon()
        icon3.addPixmap(QtGui.QPixmap(":/Images/img/poker.png"), QtGui.QIcon.Normal, QtGui.QIcon.On)
        self.pbShuffle.setIcon(icon3)
        self.pbShuffle.setIconSize(QtCore.QSize(64, 64))
        self.pbShuffle.setObjectName("pbShuffle")
        self.verticalLayout.addWidget(self.pbShuffle)
        self.pbAbout = QtWidgets.QPushButton(self.centralwidget)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.pbAbout.sizePolicy().hasHeightForWidth())
        self.pbAbout.setSizePolicy(sizePolicy)
        self.pbAbout.setMinimumSize(QtCore.QSize(0, 120))
        font = QtGui.QFont()
        font.setFamily("Cambria")
        font.setPointSize(16)
        self.pbAbout.setFont(font)
        icon4 = QtGui.QIcon()
        icon4.addPixmap(QtGui.QPixmap(":/Images/img/copy.png"), QtGui.QIcon.Normal, QtGui.QIcon.On)
        self.pbAbout.setIcon(icon4)
        self.pbAbout.setIconSize(QtCore.QSize(64, 64))
        self.pbAbout.setObjectName("pbAbout")
        self.verticalLayout.addWidget(self.pbAbout)
        self.pbExit = QtWidgets.QPushButton(self.centralwidget)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.pbExit.sizePolicy().hasHeightForWidth())
        self.pbExit.setSizePolicy(sizePolicy)
        self.pbExit.setMinimumSize(QtCore.QSize(0, 120))
        font = QtGui.QFont()
        font.setFamily("Cambria")
        font.setPointSize(16)
        self.pbExit.setFont(font)
        icon5 = QtGui.QIcon()
        icon5.addPixmap(QtGui.QPixmap(":/Images/img/logout.png"), QtGui.QIcon.Normal, QtGui.QIcon.On)
        self.pbExit.setIcon(icon5)
        self.pbExit.setIconSize(QtCore.QSize(64, 64))
        self.pbExit.setObjectName("pbExit")
        self.verticalLayout.addWidget(self.pbExit)
        self.horizontalLayout.addLayout(self.verticalLayout)
        spacerItem1 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem1)
        MainWidget.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWidget)
        QtCore.QMetaObject.connectSlotsByName(MainWidget)

    def retranslateUi(self, MainWidget):
        _translate = QtCore.QCoreApplication.translate
        MainWidget.setWindowTitle(_translate("MainWidget", "Bubble Sort Demo..."))
        self.tbTitle.setText(_translate("MainWidget", "       GDP OF MAIN INDUSTRIAL COUNTRIES\n"
"                               (IN BILLIONS)"))
        self.pbStart.setText(_translate("MainWidget", "    START  "))
        self.pbStop.setText(_translate("MainWidget", "   STOP      "))
        self.pbShuffle.setText(_translate("MainWidget", "    SHUFFLE"))
        self.pbAbout.setText(_translate("MainWidget", "    ABOUT    "))
        self.pbExit.setText(_translate("MainWidget", "      EXIT       "))
```



思路：

```
了解sort函数中关键字参数key的使用。
```

