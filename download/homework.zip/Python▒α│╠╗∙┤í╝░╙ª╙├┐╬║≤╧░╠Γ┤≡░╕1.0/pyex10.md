---
title: 《Python编程实践》第10章练习题及解答
date: 2019-08-03 11:27:37
tags: 
  - Python
  - 习题
comments: true
categories:
  - [Python]
meta:
  top: false
  date: true
  categories: true 
  counter: true 
  updated: true
  share: true
  tags: true 
recommended_posts: false
mathjax: true
---



《Python编程实践》第10章练习题及解答



<!-- more -->



> 版权声明
>
> 本文**可以**在互联网上自由转载，但必须：注明出处(作者：陈波，刘慧君)并包含指向本页面的链接。
>
> 本文**不可以**以纸质出版为目的进行改编、摘抄。





#### 10-1

借助于range()生成0到100，间隔为5的等差数列，再使用join()函数将上述数列的数字串成如下格式：

```python
0,5,10,15,...,95,100,
```

答案：

```python
lst=[str(x) for x in range(0,101,5)]
print(",".join(lst))
```

思路：

```
pass
```



#### 10-2

下述程序试图输出一个“漂亮”的表格，但不太成功。请借助于本章所学的替代字段，格式说明符等知识，修改
代码，让输出表格变得整齐，漂亮。

```python
titles = ['学号','姓名','出生年月','绩点']
value1 = ['20190324','Andy Lee','2002-12',3.4675]
value2 = ['2019L1','李杜','2001-11',2.78]
value3 = ['2019X11','Leonardo di ser Piero Da Vinci','2012-4',3.11111]
for x in titles:
	print(x,end=" ")
print()
for x in value1:
	print(x,end=" ")
print()
for x in value2:
    print(x,end=" ")
print()
for x in value3:
	print(x,end=" ")
```

答案：

```python
titles = ['学号','姓名','出生年月','绩点']
value1 = ['20190324','Andy Lee','2002-12',3.4675]
value2 = ['2019L1','李杜','2001-11',2.78]
value3 = ['2019X11','Leonardo di ser Piero Da Vinci','2012-4',3.11111]

def check_chinese(check_str):
    for ch in check_str:
        if u'\u4e00' <= ch and u'\u9fff' >=ch:
            return True
    else:
        return False

def Type(x):
    temp="{:<"
    if check_chinese(str(x)):
        temp=temp+str(31-len(x))+"}"
    else:
        temp=temp+"31}"
    return temp

for x in titles:
    temp=Type(x)
    print(temp.format(x), end=" ")
print()
for x in value1:
    temp=Type(x)
    print(temp.format(x), end=" ")
print()
for x in value2:
    temp=Type(x)
    print(temp.format(x), end=" ")
print()
for x in value3:
    temp=Type(x)
    print(temp.format(x), end=" ")
```

思路：

```
注意一个汉字占用两个字符的位置，若要按统一格式输出汉字和字母，需要特别判断哪些字符串是汉字。 
```

