---
title: 《Python编程实践》第12章练习题及解答
date: 2019-08-03 11:49:37
tags: 
  - Python
  - 习题
comments: true
categories:
  - [Python]
meta:
  top: false
  date: true
  categories: true 
  counter: true 
  updated: true
  share: true
  tags: true 
recommended_posts: false
mathjax: true
---



《Python编程实践》第12章练习题及解答



<!-- more -->



> 版权声明
>
> 本文**可以**在互联网上自由转载，但必须：注明出处(作者：陈波，刘慧君)并包含指向本页面的链接。
>
> 本文**不可以**以纸质出版为目的进行改编、摘抄。





#### 12-1

写出下述程序的执行结果。

```python
a=4
b=2
for i in range(5):
    try:
        a = a - 1
        c = b / a
        print(c)
    except Exception:
        print("error!")
```

答案：

```
0.6666666666666666
1.0
2.0
error!
-2.0
```

思路：

```
主要的执行过程为：c=2/3；c=2/2；c=2/1；c=2/0；c=2/-1。
```



#### 12-2

写出下述程序的执行结果。

```python
x=4
y=2
for i in range(4):
    try:
        x = x - 1  
        z = y / x  
        print(z)
    except Exception:
        print("error!")
    else:
        print("正常运行")
```

答案：

```
0.6666666666666666
正常运行
1.0
正常运行
2.0
正常运行
error!
```

思路：

```
主要的执行过程为：z=2/3；z=2/2；z=2/1；z=2/0。
```

#### 12-3

写出下述程序的执行结果。

```python
x=5
y=2
for i in range(3):
    try:
        x = x - 2   
        z = y / x  
        print(z)
    except Exception:
        print("error!")
    else:
        print("正常运行")
    finally:
        print("finally")
```

答案：

```
0.6666666666666666
正常运行
finally
2.0
正常运行
finally
-2.0
正常运行
finally
```

思路：

```
主要的执行过程为：z=2/3；z=2/1；z=2/-1。
```

#### 12-4

编程序实现功能：输入三角形的三条边边长，求三角形面积，如果三条边不能形成一个三角形时，抛
ValueError异常。

答案：

```python
from math import *
value_str=input("请输入三角形的三条边（用空格隔开）：")
value_float=[]
#两边之和大于第三边
#两边之差小于第三边
for x in value_str.split(" "):
    value_float.append(float(x))
try:
    if value_float[0]<0 or value_float[1]<0 or value_float[2]<0:
        raise ValueError
    elif value_float[0]+value_float[1]<=value_float[2] or \
       value_float[0]+value_float[2]<=value_float[1] or \
       value_float[1]+value_float[2]<=value_float[0]:
        raise ValueError

except(ValueError) as v:
    print("三条边不能形成一个三角形!")
else:
    print("三条边能形成一个三角形!")
    print("周长：",sum(value_float))
    temp=sum(value_float)/2
    print("面积：",sqrt(temp*(temp-value_float[0])*(temp-value_float[1])*(temp-value_float[2])))
finally:
    print("finally")
```

思路：

```
首先判断三条边是否为正数，然后判断三条边是否能构成三角形。
```

#### 12-5

编写一个程序计算文件中所有数字的平均数和总和，数字之间用逗号隔开。要求在程序中使用异常处理机制
来处理文件不存在、文件为空或者字符串不是数值的情况。

答案：

```python
import os
class FileIsNone(Exception):
    def __init__(self):
        pass

filename=input("请输入文件名：")
try:
    f=open(filename,"r")
    value=[]
    if os.path.getsize(filename) == 0:
        raise FileIsNone
    for line in f.readlines():
        for num in line.split(","):
            value.append(float(num))
    print("平均值：",sum(value)/len(value))
except(FileNotFoundError):
    print("文件不存在")
except(ValueError):
    print("数据错误")
except(FileIsNone):
    print("文件为空")
finally:
    print("finally")
```

思路：

```
当open语句找不到文件时，会抛出文件不存在的异常；
当无法进行float类型转换时，会抛出字符串不是数值的异常；
由于系统没有文件为空的异常，需要自定义一个FileIsNone异常，使用os.path.getsize判断文件是否为空。
```

#### 12-6

 已知有学生类Student定义如下，请为其编写一个简单的单元测试用例类。

```python
class Student(object):
    def __init__(self,name,score):
        self.name = name
        self.score = score
    def getGrade(self):
        if self.score >= 80 and self.score <= 100:
        	return 'A'
        elif self.score >= 60 and self.score <= 79:
            return 'B'
        elif self.score >= 0 and self.score <= 59:
        	return 'C'
        else:
        	raise ValueError('value is not between 0 and 100')
```

答案：

```python
import unittest
class Student(object):
    def __init__(self,name,score):
        self.name = name
        self.score = score
    def getGrade(self):
        if self.score >= 80 and self.score <= 100:
            return 'A'
        elif self.score >= 60 and self.score <= 79:
            return 'B'
        elif self.score >= 0 and self.score <= 59:
            return 'C'
        else:
            raise ValueError('value is not between 0 and 100')

class TestStudent(unittest.TestCase):

    def test_80_to_100(self):
        s1 = Student('Liting', 80)
        s2 = Student('Wangsa', 100)
        self.assertEqual(s1.getGrade(), 'A')
        self.assertEqual(s2.getGrade(), 'A')

    def test_60_to_80(self):
        s1 = Student('Liting', 60)
        s2 = Student('Wangsa', 79)
        self.assertEqual(s1.getGrade(), 'B')
        self.assertEqual(s2.getGrade(), 'B')

    def test_0_to_60(self):
        s1 = Student('Liting', 0)
        s2 = Student('Wangsa', 59)
        self.assertEqual(s1.getGrade(), 'C')
        self.assertEqual(s2.getGrade(), 'C')

    def test_invalid(self):
        s1 = Student('Liting', -1)
        s2 = Student('Wangsa', 101)
        with self.assertRaises(ValueError):
            s1.getGrade()
        with self.assertRaises(ValueError):
            s2.getGrade()

if __name__=="__main__":
    unittest.main()
```

思路：

```
pass
```

#### 12-7

为习题9-5的代码设计并进行单元测试。

答案：

```python
from math import *
import unittest

class Root:
    def __init__(self, a, b, c):
        print("init")
        self.a = a
        self.b = b
        self.c = c

    def getDiscriminant(self):
        return self.b ** 2 - 4 * self.a * self.c

    def getRoot1(self):
        if self.a==0:
            return 'error'
        if self.getDiscriminant()>=0:
            return (-self.b + sqrt(self.getDiscriminant())) / (2 * self.a)
        else:
            return "none"         

    def getRoot2(self):
        if self.a==0:
             return none
        if self.getDiscriminant()>=0:
              return (-self.b + sqrt(self.getDiscriminant())) / (2 * self.a)
        else:
             return "none"

class RootTestCase(unittest.TestCase):
    def testRoot(self):
        self.assertEqual(Root(3,4,5).getRoot1(),'none','No root!')
        self.assertEqual(Root(0,2,5).getRoot1(),'error','2次项系数不能为0!')
        self.assertEqual(Root(1,2,1).getRoot1(),-1,'Root1=1')
        self.assertEqual(Root(1,2,1).getRoot2(),-1,'Root2=1')
        self.assertEqual(Root(1,-2,1).getRoot1(),1,'Root1=1')
        self.assertEqual(Root(1,-2,1).getRoot2(),1,'Root2=1')
        self.assertEqual(Root(3,3,3).getRoot1(),'none','No root!')
        self.assertEqual(Root(-3,4,-5).getRoot1(),'none','No root!')        

if __name__=="__main__":
    unittest.main()
```

思路：

```
pass
```

