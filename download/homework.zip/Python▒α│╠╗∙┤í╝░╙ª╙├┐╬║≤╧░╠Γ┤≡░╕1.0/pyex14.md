---
title: 《Python编程实践》第17章练习题及解答
date: 2019-08-05 19:50:49
tags: 
  - Python
  - 习题
comments: true
categories:
  - [Python]
meta:
  top: false
  date: true
  categories: true 
  counter: true 
  updated: true
  share: true
  tags: true 
recommended_posts: false
mathjax: true
---



《Python编程实践》第14章练习题及解答



<!-- more -->



> 版权声明
>
> 本文**可以**在互联网上自由转载，但必须：注明出处(作者：陈波，刘慧君)并包含指向本页面的链接。
>
> 本文**不可以**以纸质出版为目的进行改编、摘抄。





#### 14-1

本游戏只有5个盘，试着改成9个盘的汉诺塔游戏。那些盘的图片可以简单地在PowerPoint中用梯形画，再另
存为PNG格式文件。

答案：

```python
#Button.py
from enum import Enum
import pygame

class ButtonState(Enum):
    normal = 0      #正常
    focused = 1     #高亮
    pushed = 2      #按下
    disabled = 3    #禁用

class Button:
    def __init__(self,screen,xCenter,yBottom,
                 fileNormal,fileFocused,filePushed,fileDisabled):
        self.screen = screen
        self.imgNormal = pygame.image.load(fileNormal)
        self.imgFocused = pygame.image.load(fileFocused)
        self.imgPushed = pygame.image.load(filePushed)
        self.imgDisabled = pygame.image.load(fileDisabled)
        self.state = ButtonState.normal

        self.rect = self.imgNormal.get_rect()
        self.rect.centerx = xCenter
        self.rect.bottom = yBottom

    def setEnabled(self,bEnabled):
        self.state = ButtonState.normal if bEnabled \
            else ButtonState.disabled

    def mouseEvent(self,e):
        x,y = pygame.mouse.get_pos()
        if e.type == pygame.MOUSEMOTION:
            return self.__mouseMotionEvent(x,y)

        if not self.rect.collidepoint(x,y):
            return

        if e.type == pygame.MOUSEBUTTONDOWN:
            return self.__mouseDownEvent()

        if e.type == pygame.MOUSEBUTTONUP:
            return self.__mouseUpEvent()

    def __mouseUpEvent(self):
        if self.state not in (ButtonState.disabled,):
            self.state = ButtonState.focused
            return self
        return None

    def __mouseDownEvent(self):
        if self.state in (ButtonState.normal,ButtonState.focused):
            self.state = ButtonState.pushed
        return

    def __mouseMotionEvent(self,x,y):
        if self.rect.collidepoint(x,y):
            if self.state == ButtonState.normal:
                self.state = ButtonState.focused
        else:
            if self.state == ButtonState.focused:
                self.state = ButtonState.normal

    def blit(self):
        img = None
        if self.state == ButtonState.normal:
            img = self.imgNormal
        elif self.state == ButtonState.focused:
            img = self.imgFocused
        elif self.state == ButtonState.disabled:
            img = self.imgDisabled
        elif self.state == ButtonState.pushed:
            img = self.imgPushed
        self.screen.blit(img,self.rect)
```

```python
#Disc.py
import pygame
class Disc:
    "The said golden disc."
    iDiscHeight = 35#上下间距
    def __init__(self,screen,number,imgFile):
        self.screen = screen
        self.iNo = number
        self.img = pygame.image.load(imgFile)
        self.rect = self.img.get_rect()
        #print(self.rect)

    def blit(self):
        self.screen.blit(self.img,self.rect)

class FlyingDisc():
    "The disc in moving..."
    verticalUpStage = 0
    horizontalMoveStage = 1
    verticalDownStage = 2

    def __init__(self,disc,poleFrom,poleTo):
        self.disc = disc
        self.poleFrom = poleFrom
        self.poleTo = poleTo

        self.xCurrent = poleFrom.xPos
        self.xTo = poleTo.xPos
        self.yCurrent = poleFrom.getDiscsTopPosition()
        self.yCeiling = Disc.iDiscHeight + 20
        self.yTo = poleTo.getDiscsTopPosition()
        self.xStep = (self.xTo - self.xCurrent)/50
        self.yUpStep = (self.yCeiling - self.yCurrent) / 50
        self.yDownStep = (self.yTo - self.yCeiling) / 50

        self.stageMove = self.verticalUpStage

    def blit(self):
        self.disc.rect.centerx = self.xCurrent
        self.disc.rect.bottom = self.yCurrent
        self.disc.blit()

    def flyMove(self):
        assert self.stageMove in (self.verticalDownStage,self.horizontalMoveStage,self.verticalUpStage)
        if self.stageMove == self.verticalUpStage:
            if abs(self.yCurrent-self.yCeiling) <= abs(self.yUpStep):
                self.yCurrent = self.yCeiling
                self.stageMove = self.horizontalMoveStage
            else:
                self.yCurrent += self.yUpStep
            return False

        if self.stageMove == self.horizontalMoveStage:
            if abs(self.xCurrent-self.xTo) <= abs(self.xStep):
                self.xCurrent = self.xTo
                self.stageMove = self.verticalDownStage
            else:
                self.xCurrent += self.xStep
            return False

        if self.stageMove == self.verticalDownStage:
            if abs(self.yCurrent-self.yTo) <= abs(self.yDownStep):
                self.yCurrent = self.yTo
                self.poleTo.putDisc(self.disc)
                return True
            else:
                self.yCurrent += self.yDownStep
            return False
```

```python
#HanoiGenerator.py
def hanoi(n, a, b, c):
    if n == 1:
        yield (a,c)
    else:
        for x in hanoi(n - 1, a, c, b):
            yield x
        yield (a,c)
        for x in hanoi(n - 1, b, a, c):
            yield x


if __name__ == '__main__':
    genHanoi = hanoi(5, 0, 1, 2)
    while True:
        try:
            a = next(genHanoi)
        except (StopIteration,Exception) as e:
            break
        else:
            print(a)

```

```python
#HanoiTower.py
import os,sys
import pygame.locals
from Button import *
from Disc import *
from Pole import *
import HanoiGenerator
from enum import Enum

class AppState(Enum):
    idle = 0
    running = 1
    finished = 2

class HanoiTower:
    instance = None
    userEventDiscMoveInterval = pygame.USEREVENT + 1
    userEventFlyDiscMove = pygame.USEREVENT + 2
    def __init__(self,disk_num):
        assert HanoiTower.instance == None, "Only one HanoiTower object allowed."
        HanoiTower.instance = self
        self.disk_num=disk_num
        self.png=["9.png","8.png","7.png","6.png","5.png","4.png","3.png","2.png","1.png"]
        self.hanoiGenerator = None
        self.initGame()


    def createButtons(self):
        self.btnReset = Button(self.screen,120,535,
                               self.sResourcePath+"resetNormal.png",
                               self.sResourcePath+"resetFocused.png",
                               self.sResourcePath+"resetPushed.png",
                               self.sResourcePath+"resetDisabled.png")
        self.btnRun = Button(self.screen,360,535,
                               self.sResourcePath+"runNormal.png",
                               self.sResourcePath+"runFocused.png",
                               self.sResourcePath+"runPushed.png",
                               self.sResourcePath+"runDisabled.png")
        self.btnStep = Button(self.screen,600,535,
                               self.sResourcePath+"stepNormal.png",
                               self.sResourcePath+"stepFocused.png",
                               self.sResourcePath+"stepPushed.png",
                               self.sResourcePath+"stepDisabled.png")
        self.btnPause = Button(self.screen,840,535,
                               self.sResourcePath+"pauseNormal.png",
                               self.sResourcePath+"pauseFocused.png",
                               self.sResourcePath+"pausePushed.png",
                               self.sResourcePath+"pauseDisabled.png")
        self.buttons = [self.btnStep,self.btnRun,self.btnPause,self.btnReset]

    def createPolesDiscs(self):
        self.flyingDisc = None
        self.poles = []
        pole0 = Pole(150)
        #print("disk_num",self.disk_num)

        for i in range(self.disk_num-1,-1,-1):
            #print(self.png[i])
            pole0.putDisc(Disc(self.screen, i, self.sResourcePath + self.png[i]))
        '''
        pole0.putDisc(Disc(self.screen,4,self.sResourcePath + "gray.png"))
        pole0.putDisc(Disc(self.screen,3,self.sResourcePath + "orange.png"))
        pole0.putDisc(Disc(self.screen,2,self.sResourcePath + "yellow.png"))
        pole0.putDisc(Disc(self.screen,1,self.sResourcePath + "green.png"))
        pole0.putDisc(Disc(self.screen,0,self.sResourcePath + "blue.png"))
        '''

        self.poles.append(pole0)
        self.poles.append(Pole(480))
        self.poles.append(Pole(810))

    def syncState(self, state):
        if state == AppState.idle:
            self.btnReset.setEnabled(True)
            self.btnRun.setEnabled(True)
            self.btnStep.setEnabled(True)
            self.btnPause.setEnabled(False)
        elif state == AppState.running:
            self.btnReset.setEnabled(False)
            self.btnRun.setEnabled(False)
            self.btnStep.setEnabled(False)
            self.btnPause.setEnabled(True)
        elif state == AppState.finished:
            self.btnReset.setEnabled(True)
            self.btnRun.setEnabled(False)
            self.btnStep.setEnabled(False)
            self.btnPause.setEnabled(False)
        else:
            assert False, "syncState():Unrecognized state parameter."
        self.appState = state

    def initGame(self):
        pygame.init()
        self.screen = pygame.display.set_mode((960, 540), 0, 32)
        pygame.display.set_caption("Tower of Hanoi")

        self.sResourcePath = "resource" + os.sep
        self.imgBackground = pygame.image.load(self.sResourcePath + "background.png").convert()

        self.bgm = pygame.mixer.music.load(self.sResourcePath+"Serenity.mp3")
        pygame.mixer.music.play(loops = int(1e9), start = 0.0)

        self.createPolesDiscs()
        self.createButtons()
        self.syncState(AppState.idle)

    def render(self):
        self.screen.blit(self.imgBackground, (0, 0))

        for x in self.buttons + self.poles:
            x.blit()

        if self.flyingDisc:
            self.flyingDisc.blit()

        pygame.display.update()

    def moveDiscStart(self,iPoleFrom,iPoleTo):
        disc = self.poles[iPoleFrom].popDisc()
        assert self.flyingDisc == None
        self.flyingDisc = FlyingDisc(disc,self.poles[iPoleFrom],self.poles[iPoleTo])
        self.flyTimerStart()

    def moveDiscEnd(self):
        self.flyingDisc = None
        self.flyTimerStop()
        if self.appState == AppState.running:
            self.intervalTimerStart()
            pass

    def reset(self):
        if self.flyingDisc:
            print("One disc still in moving...")
            return

        self.hanoiGenerator = None
        self.createPolesDiscs()
        self.syncState(AppState.idle)

    def pause(self):
        self.intervalTimerStop()
        self.syncState(AppState.idle)

    def run(self):
        if not self.hanoiGenerator:
            self.reset()
            self.hanoiGenerator = HanoiGenerator.hanoi(self.disk_num, 0, 1, 2)
        self.syncState(AppState.running)
        if not self.flyingDisc:
            self.runNextMove()

    def step(self):
        if self.flyingDisc:
            print("One disc still in moving...")
            return

        if not self.hanoiGenerator:
            self.createPolesDiscs()
            self.hanoiGenerator = HanoiGenerator.hanoi(self.disk_num, 0, 1, 2)

        self.runNextMove()

    def mouseEvent(self,event):
        for b in self.buttons:
            r = b.mouseEvent(event)
            if r:
                break

        if r == None:
            return None

        if r == self.btnRun:
            self.run()
        elif r == self.btnStep:
            self.step()
        elif r == self.btnPause:
            self.pause()
        elif r == self.btnReset:
            self.reset()
        else:
            assert False, "Wrong return value from Button.mouseEvent()."

    def intervalTimerStart(self):#盘放入的定时器
        pygame.time.set_timer(HanoiTower.userEventDiscMoveInterval, 100)

    def intervalTimerStop(self):
        pygame.time.set_timer(HanoiTower.userEventDiscMoveInterval, 0)

    def flyTimerStart(self):#盘飞起的定时器
        pygame.time.set_timer(HanoiTower.userEventFlyDiscMove, 10)

    def flyTimerStop(self):
        pygame.time.set_timer(HanoiTower.userEventFlyDiscMove, 0)


    def flyMove(self):
        if not self.flyingDisc:
            self.flyTimerStop()
            return

        if self.flyingDisc.flyMove():
            self.moveDiscEnd()

    def runNextMove(self):
        assert self.hanoiGenerator != None
        self.intervalTimerStop()
        try:
            nextAction = next(self.hanoiGenerator)
        except (StopIteration, Exception) as e:
            self.hanoiGenerator = None
            self.intervalTimerStop()
            self.syncState(AppState.finished)
            print("Iteration over, not more actions.")
        else:
            poleFrom, poleTo = nextAction
            self.moveDiscStart(poleFrom, poleTo)

    def mainLoop(self):
        while (True):
            for event in pygame.event.get():
                if event.type == pygame.locals.QUIT:
                    sys.exit()


                elif event.type == HanoiTower.userEventFlyDiscMove:
                    self.flyMove()

                elif event.type == HanoiTower.userEventDiscMoveInterval:
                     self.runNextMove()

                elif event.type in (pygame.MOUSEBUTTONDOWN,
                                  pygame.MOUSEBUTTONUP,pygame.MOUSEMOTION):
                    self.mouseEvent(event)

            self.render()

if __name__ == '__main__':
    t = HanoiTower(7)
    t.mainLoop()
```



```python
#Pole.py
from Disc import Disc
class Pole:
    def __init__(self,xPos):
        self.xPos = xPos
        self.discs = []   #disc 0 at bottom most

    def getDiscsTopPosition(self):
        return 481 - len(self.discs)*Disc.iDiscHeight

    def blit(self):
        for idx,disc in enumerate(self.discs):
            disc.rect.centerx = self.xPos
            disc.rect.bottom = 481 - Disc.iDiscHeight*idx
            disc.blit()

    def putDisc(self,disc):
        if self.discs:
            assert disc.iNo < self.discs[-1].iNo,"Rule violated."
        self.discs.append(disc)

    def popDisc(self):
        disc = self.discs.pop()
        assert disc != None, "No disc on pole."
        return disc
```

思路：

```
在代码中修改盘片的数量或者使用变量self.disk_num表示盘片数量，更新存储盘片位置的列表。
```



#### 14-2

本游戏使用的是定时器加执行序列生成器的模式完成的，这种模式使得程序逻辑相对比较零乱。请查阅关于
Python线程及线程间同步的相关资料，尝试用线程来实现飞盘的飞行过程。本书中“冒泡及轻者上浮”一章中关于线
程的知识或许对你有帮助。

答案：

```python
#Button.py
from enum import Enum
import pygame

class ButtonState(Enum):
    normal = 0      #正常
    focused = 1     #高亮
    pushed = 2      #按下
    disabled = 3    #禁用

class Button:
    def __init__(self,screen,xCenter,yBottom,
                 fileNormal,fileFocused,filePushed,fileDisabled):
        self.screen = screen
        self.imgNormal = pygame.image.load(fileNormal)
        self.imgFocused = pygame.image.load(fileFocused)
        self.imgPushed = pygame.image.load(filePushed)
        self.imgDisabled = pygame.image.load(fileDisabled)
        self.state = ButtonState.normal

        self.rect = self.imgNormal.get_rect()
        self.rect.centerx = xCenter
        self.rect.bottom = yBottom

    def setEnabled(self,bEnabled):
        self.state = ButtonState.normal if bEnabled \
            else ButtonState.disabled

    def mouseEvent(self,e):
        x,y = pygame.mouse.get_pos()
        if e.type == pygame.MOUSEMOTION:
            return self.__mouseMotionEvent(x,y)

        if not self.rect.collidepoint(x,y):
            return

        if e.type == pygame.MOUSEBUTTONDOWN:
            return self.__mouseDownEvent()

        if e.type == pygame.MOUSEBUTTONUP:
            return self.__mouseUpEvent()

    def __mouseUpEvent(self):
        if self.state not in (ButtonState.disabled,):
            self.state = ButtonState.focused
            return self
        return None

    def __mouseDownEvent(self):
        if self.state in (ButtonState.normal,ButtonState.focused):
            self.state = ButtonState.pushed
        return

    def __mouseMotionEvent(self,x,y):
        if self.rect.collidepoint(x,y):
            if self.state == ButtonState.normal:
                self.state = ButtonState.focused
        else:
            if self.state == ButtonState.focused:
                self.state = ButtonState.normal

    def blit(self):
        img = None
        if self.state == ButtonState.normal:
            img = self.imgNormal
        elif self.state == ButtonState.focused:
            img = self.imgFocused
        elif self.state == ButtonState.disabled:
            img = self.imgDisabled
        elif self.state == ButtonState.pushed:
            img = self.imgPushed
        self.screen.blit(img,self.rect)
```

```python
#Disc.py
import pygame

class Disc:
    "The said golden disc."
    iDiscHeight = 50
    def __init__(self,screen,number,imgFile):
        self.screen = screen
        self.iNo = number
        self.img = pygame.image.load(imgFile)
        self.rect = self.img.get_rect()

    def blit(self):
        self.screen.blit(self.img,self.rect)

class FlyingDisc:
    "The disc in moving..."
    verticalUpStage = 0
    horizontalMoveStage = 1
    verticalDownStage = 2

    def __init__(self,disc,poleFrom,poleTo):
        self.disc = disc
        self.poleFrom = poleFrom
        self.poleTo = poleTo

        self.xCurrent = poleFrom.xPos
        self.xTo = poleTo.xPos
        self.yCurrent = poleFrom.getDiscsTopPosition()
        self.yCeiling = Disc.iDiscHeight + 20
        self.yTo = poleTo.getDiscsTopPosition()
        self.xStep = (self.xTo - self.xCurrent)/50
        self.yUpStep = (self.yCeiling - self.yCurrent) / 50
        self.yDownStep = (self.yTo - self.yCeiling) / 50

        self.stageMove = self.verticalUpStage

    def blit(self):
        self.disc.rect.centerx = self.xCurrent
        self.disc.rect.bottom = self.yCurrent
        self.disc.blit()

    def flyMove(self):
        assert self.stageMove in (self.verticalDownStage,self.horizontalMoveStage,self.verticalUpStage)
        if self.stageMove == self.verticalUpStage:
            if abs(self.yCurrent-self.yCeiling) <= abs(self.yUpStep):
                self.yCurrent = self.yCeiling
                self.stageMove = self.horizontalMoveStage
            else:
                self.yCurrent += self.yUpStep
            #print("1False")
            return False

        if self.stageMove == self.horizontalMoveStage:
            if abs(self.xCurrent-self.xTo) <= abs(self.xStep):
                self.xCurrent = self.xTo
                self.stageMove = self.verticalDownStage
            else:
                self.xCurrent += self.xStep
            #print("2False")
            return False

        if self.stageMove == self.verticalDownStage:
            if abs(self.yCurrent-self.yTo) <= abs(self.yDownStep):
                self.yCurrent = self.yTo
                self.poleTo.putDisc(self.disc)
                return True
            else:
                self.yCurrent += self.yDownStep
            #print("3False")
            return False
```

```python
#HanoiGenerator.py
def hanoi(n, a, b, c):
    if n == 1:
        yield (a,c)
    else:
        for x in hanoi(n - 1, a, c, b):
            yield x
        yield (a,c)
        for x in hanoi(n - 1, b, a, c):
            yield x


if __name__ == '__main__':
    genHanoi = hanoi(5, 0, 1, 2)
    while True:
        try:
            a = next(genHanoi)
        except (StopIteration,Exception) as e:
            break
        else:
            print(a)

```

```python
#HanoiTower.py
import os,sys
import pygame.locals
from Button import *
from Disc import *
from Pole import *
import HanoiGenerator
from enum import Enum
import threading

class AppState(Enum):
    idle = 0
    running = 1
    finished = 2

class HanoiTower:
    instance = None
    def __init__(self):
        assert HanoiTower.instance == None, "Only one HanoiTower object allowed."
        HanoiTower.instance = self
        self.hanoiGenerator = None
        self.initGame()

    def createButtons(self):
        self.btnReset = Button(self.screen,120,535,
                               self.sResourcePath+"resetNormal.png",
                               self.sResourcePath+"resetFocused.png",
                               self.sResourcePath+"resetPushed.png",
                               self.sResourcePath+"resetDisabled.png")
        self.btnRun = Button(self.screen,360,535,
                               self.sResourcePath+"runNormal.png",
                               self.sResourcePath+"runFocused.png",
                               self.sResourcePath+"runPushed.png",
                               self.sResourcePath+"runDisabled.png")
        self.btnStep = Button(self.screen,600,535,
                               self.sResourcePath+"stepNormal.png",
                               self.sResourcePath+"stepFocused.png",
                               self.sResourcePath+"stepPushed.png",
                               self.sResourcePath+"stepDisabled.png")
        self.btnPause = Button(self.screen,840,535,
                               self.sResourcePath+"pauseNormal.png",
                               self.sResourcePath+"pauseFocused.png",
                               self.sResourcePath+"pausePushed.png",
                               self.sResourcePath+"pauseDisabled.png")
        self.buttons = [self.btnStep,self.btnRun,self.btnPause,self.btnReset]

    def createPolesDiscs(self):
        self.flyingDisc = None
        self.poles = []
        pole0 = Pole(150)
        pole0.putDisc(Disc(self.screen,4,self.sResourcePath + "gray.png"))
        pole0.putDisc(Disc(self.screen,3,self.sResourcePath + "orange.png"))
        pole0.putDisc(Disc(self.screen,2,self.sResourcePath + "yellow.png"))
        pole0.putDisc(Disc(self.screen,1,self.sResourcePath + "green.png"))
        pole0.putDisc(Disc(self.screen,0,self.sResourcePath + "blue.png"))

        self.poles.append(pole0)
        self.poles.append(Pole(480))
        self.poles.append(Pole(810))

    def syncState(self, state):
        if state == AppState.idle:
            self.btnReset.setEnabled(True)
            self.btnRun.setEnabled(True)
            self.btnStep.setEnabled(True)
            self.btnPause.setEnabled(False)
        elif state == AppState.running:
            self.btnReset.setEnabled(False)
            self.btnRun.setEnabled(False)
            self.btnStep.setEnabled(False)
            self.btnPause.setEnabled(True)
        elif state == AppState.finished:
            self.btnReset.setEnabled(True)
            self.btnRun.setEnabled(False)
            self.btnStep.setEnabled(False)
            self.btnPause.setEnabled(False)
        else:
            assert False, "syncState():Unrecognized state parameter."
        self.appState = state

    def initGame(self):
        pygame.init()
        self.screen = pygame.display.set_mode((960, 540), 0, 32)
        pygame.display.set_caption("Tower of Hanoi")

        self.sResourcePath = "resource" + os.sep
        self.imgBackground = pygame.image.load(self.sResourcePath + "background.png").convert()

        self.bgm = pygame.mixer.music.load(self.sResourcePath+"Serenity.mp3")
        pygame.mixer.music.play(loops = int(1e9), start = 0.0)

        self.createPolesDiscs()
        self.createButtons()
        self.syncState(AppState.idle)

    def render(self):
        self.screen.blit(self.imgBackground, (0, 0))

        for x in self.buttons + self.poles:
            x.blit()

        if self.flyingDisc:
            self.flyingDisc.blit()

        pygame.display.update()

    def moveDiscStart(self,iPoleFrom,iPoleTo):
        disc = self.poles[iPoleFrom].popDisc()
        assert self.flyingDisc == None
        self.flyingDisc = FlyingDisc(disc,self.poles[iPoleFrom],self.poles[iPoleTo])
        temp_thread = threading.Thread(target=self.flyMove)
        temp_thread.start()

    def moveDiscEnd(self):
        self.flyingDisc = None
        if self.appState == AppState.running:
            temp_thread = threading.Thread(target=self.runNextMove)
            temp_thread.start()
            pass

    def run(self):
        if not self.hanoiGenerator:
            self.reset()
            self.hanoiGenerator = HanoiGenerator.hanoi(5, 0, 1, 2)
        self.syncState(AppState.running)
        if not self.flyingDisc:
            temp_thread = threading.Thread(target=self.runNextMove)
            temp_thread.start()

    def reset(self):
        if self.flyingDisc:
            print("One disc still in moving...")
            return

        self.hanoiGenerator = None
        self.createPolesDiscs()
        self.syncState(AppState.idle)

    def pause(self):
        self.syncState(AppState.idle)

    def step(self):
        if self.flyingDisc:
            print("One disc still in moving...")
            return

        if not self.hanoiGenerator:
            self.createPolesDiscs()
            self.hanoiGenerator = HanoiGenerator.hanoi(5, 0, 1, 2)

        temp_thread = threading.Thread(target=self.runNextMove)
        temp_thread.start()

    def mouseEvent(self,event):
        for b in self.buttons:
            r = b.mouseEvent(event)
            if r:
                break

        if r == None:
            return None

        if r == self.btnRun:
            self.run()
        elif r == self.btnStep:
            self.step()
        elif r == self.btnPause:
            self.pause()
        elif r == self.btnReset:
            self.reset()
        else:
            assert False, "Wrong return value from Button.mouseEvent()."

    def func(self):
        self.flag=self.flyingDisc.flyMove()

    def flyMove(self):
        if not self.flyingDisc:
            return
        self.flag=self.flyingDisc.flyMove()
        while self.flag==False:
            temp_thread = threading.Thread(target=self.func)
            temp_thread.start()
        if self.flag:
            self.moveDiscEnd()

    def runNextMove(self):
        assert self.hanoiGenerator != None
        try:
            nextAction = next(self.hanoiGenerator)
        except (StopIteration, Exception) as e:
            self.hanoiGenerator = None
            self.syncState(AppState.finished)
            print("Iteration over, not more actions.")
        else:
            poleFrom, poleTo = nextAction
            self.moveDiscStart(poleFrom, poleTo)

    def mainLoop(self):
        while (True):
            for event in pygame.event.get():
                if event.type == pygame.locals.QUIT:
                    sys.exit()

                elif event.type in (pygame.MOUSEBUTTONDOWN,
                                  pygame.MOUSEBUTTONUP,pygame.MOUSEMOTION):
                    self.mouseEvent(event)

            self.render()

if __name__ == '__main__':
    t = HanoiTower()
    t.mainLoop()


```

```python
#Pole.py
from Disc import Disc
class Pole:
    def __init__(self,xPos):
        self.xPos = xPos
        self.discs = []   #disc 0 at bottom most

    def getDiscsTopPosition(self):
        return 481 - len(self.discs)*Disc.iDiscHeight

    def blit(self):
        for idx,disc in enumerate(self.discs):
            disc.rect.centerx = self.xPos
            disc.rect.bottom = 481 - Disc.iDiscHeight*idx
            disc.blit()

    def putDisc(self,disc):
        if self.discs:
            assert disc.iNo < self.discs[-1].iNo,"Rule violated."
        self.discs.append(disc)

    def popDisc(self):
        disc = self.discs.pop()
        assert disc != None, "No disc on pole."
        return disc

```

思路：

```
分析定时器所绑定的函数，然后在调用对应的函数的位置新建线程并运行对应函数。注意threading模块的使用。
```
