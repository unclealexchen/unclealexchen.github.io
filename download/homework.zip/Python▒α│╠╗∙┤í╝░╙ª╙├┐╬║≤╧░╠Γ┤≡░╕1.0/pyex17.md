---
title: 《Python编程实践》第17章练习题及解答
date: 2019-08-05 20:03:35
tags: 
  - Python
  - 习题
comments: true
categories:
  - [Python]
meta:
  top: false
  date: true
  categories: true 
  counter: true 
  updated: true
  share: true
  tags: true 
recommended_posts: false
mathjax: true
---



《Python编程实践》第17章练习题及解答



<!-- more -->



> 版权声明
>
> 本文**可以**在互联网上自由转载，但必须：注明出处(作者：陈波，刘慧君)并包含指向本页面的链接。
>
> 本文**不可以**以纸质出版为目的进行改编、摘抄。





#### 17-1

回顾一下数学教科书，将全部三角函数的图像画在一张图里的多个子图里。

答案：

```python
import numpy as np
from matplotlib import pyplot as plt

x=np.linspace(-10,10,400)
fig=plt.figure(figsize=(11,5))
ax=plt.subplot(231)
ax.plot(x,np.sin(x),c='r')
ax.set_title("sin(x)")
ax=plt.subplot(232)
ax.plot(x,np.cos(x),c='g')
ax.set_title("cos(x)")
ax=plt.subplot(233)
ax.plot(x,np.tan(x),c='y')
ax.set_title("tan(x)")
ax=plt.subplot(234)
ax.plot(x,1/np.sin(x),c='r')
ax.set_title("csc(x)")
ax=plt.subplot(235)
ax.plot(x,1/np.cos(x),c='g')
ax.set_title("sec(x)")
ax=plt.subplot(236)
ax.plot(x,1/np.tan(x),c='y')
ax.set_title("cot(x)")
fig.subplots_adjust(0.05,0.05,0.95,0.95,wspace=0.2,hspace=0.25)
plt.show()
```

思路：

```
注意子图的使用和将界面分成相应的行、列。
```



#### 17-2

17-2 绘制下述二元函数的曲面。其中，x,y的取值范围均为[-2π - +2π]。
$$
z = sin(x)cos(y)
$$
答案：

```python
import numpy as np
import mpl_toolkits.mplot3d
from matplotlib import pyplot as plt
from matplotlib import cm
x,y=np.mgrid[-2*np.pi:2*np.pi:1000j,-2*np.pi:2*np.pi:1000j]
z = np.sin(x)*np.cos(y)

fig = plt.figure(figsize=(8,6))
ax = fig.gca(projection='3d')
ax.plot_surface(x,y,z,cmap=cm.ocean)
plt.show()
```

思路：

```
参考微实践：绘制二元函数曲面的func3d.py代码。
```

#### 17-3

查询世界前十大经济体在最近一年的GDP总值及其增量，绘制成柱状图。

答案：

```python
import matplotlib.pyplot as plt
from pylab import mpl

mpl.rcParams['font.sans-serif'] = ['FangSong'] 
mpl.rcParams['axes.unicode_minus'] = False 
PreYear = (195558.74, 131735.85, 43421.60, 35954.06, 32322.81,25865.68,26074.09,19329.38,17592.67,16823.68)
CurYear = (205130.00, 134572.67, 50706.26, 40291.40, 28088.99,27946.96,26899.92,20869.11,19093.86,17337.06)   #各组女性平均得分
add_percent=[]
for i in range(len(CurYear)):
    add_percent.append((CurYear[i]-PreYear[i]))
Countries=("美国","中国","日本","德国","英国","法国","印度","意大利","巴西","加拿大")
fig,ax = plt.subplots()
x =list(range(len(Countries)))
print(x)
total_width, n = 0.8, 2
width = total_width / n
ax.set_ylabel('GDP(亿)')
ax.set_xlabel('国家')
ax.set_title('2018年世界前十大经济体的GDP总值及其增量')
p1 = ax.bar(Countries, CurYear,width=width)
for i in range(len(x)):
    x[i] = x[i] + width
p2 = ax.bar(x,add_percent, width=width)
ax.legend((p1[0],p2[0]),("GDP(亿)","增量(亿)")) #显式地定义图示
plt.show()
```

思路：

```
pass
```

#### 17-4

查询过去30年中国对世界主要经济体（前10位）出口总额的数据，使用matplotlib制作柱状图动画，展示中
国对世界主要经济体出口量在30年间的变化。

答案：

```python
#注意，本题数据是随机生成，与题目要求不符，算法思想基本一样。
import numpy as np
import matplotlib.pyplot as plt
from pylab import mpl

mpl.rcParams['font.sans-serif'] = ['FangSong'] # 指定默认字体
mpl.rcParams['axes.unicode_minus'] = False # 解决保存图像是负号'-'显示为方块的问题

x=np.arange(0,10)
y=np.random.randint(10,30,10)
fig,ax = plt.subplots()
ax.set_ylabel('GDP(亿)')
ax.set_xlabel('国家')
ax.set_title('过去30年中国对世界主要经济体（前10位）出口总额的数据')
Countries=[]
for i in range(10):
    Countries.append("国家"+str(i))

for i in range(30):
    plt.cla()
    ax.set_title(str(1989+i)+'年中国对世界主要经济体（前10位）出口总额的数据')
    p1 = ax.bar(Countries,y,width=0.5)
    plt.pause(0.5)
    y = np.random.randint(10, 30, 10)

plt.show()
```

思路：

```
清空界面并且重新绘制，控制画图的间隔时间。
注意答案中的数据为随机生成，与题目要求不符，基本算法思想一致。
```

