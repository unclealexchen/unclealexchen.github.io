---
title: 《Python编程实践》第18章练习题及解答
date: 2019-08-03 12:33:54
tags: 
  - Python
  - 习题
comments: true
categories:
  - [Python]
meta:
  top: false
  date: true
  categories: true 
  counter: true 
  updated: true
  share: true
  tags: true 
recommended_posts: false
mathjax: true
---



《Python编程实践》第18章练习题及解答



<!-- more -->



> 版权声明
>
> 本文**可以**在互联网上自由转载，但必须：注明出处(作者：陈波，刘慧君)并包含指向本页面的链接。
>
> 本文**不可以**以纸质出版为目的进行改编、摘抄。





#### 18-1

18-1 通过linspace()及ufunc函数计算并绘制下述数学函数的函数图。x取值范围为[-1000,+1000]。
$$
y = 2x^2+30x-11.5
$$
答案：

```python
import numpy as np
from matplotlib import pyplot as plt

def My_ufunc(x):
    y=2*x*x+30*x-11.5
    return y

x = np.linspace(-1000,1000,1000)
ufunc=np.frompyfunc(My_ufunc,1,1)
y =ufunc(x)
plt.plot(x,y)
plt.show()
```

思路：

```
定义My_ufunc然后使用numpy的frompyfunc方法自定义ufunc函数。
frompyfunc(function_name,x,y)。frompyfunc的常用方式是，以函数名，参数个数和返回值个数为参数。
```



#### 18-2

请通过广播运算生成并打印九九乘法表。

答案：

```python
import numpy as np

x,y=np.ogrid[1:9:9j,1:9:9j]
z=x*y
print(z)
```

思路：

```
使用numpy的ogrid方法，产生x和y，然后通过z=x*y生成九九乘法表。
```

#### 18-3

使用opencv-python的imread()函数读入一张照片，借助于数组的切片语法对图片数组进行下述处理：1). 四
边各裁去50个像素；2). 每3行抽1行，每5列抽1列构成缩略图；3).将缩略图存为jpg文件。

答案：

```python
from cv2 import imread,imwrite
img=imread("18-3.jpg",-1)
height,weight=img.shape[:2]
img=img[50:height-50:3,50:weight-50:5,:]
imwrite("18-3_1.jpg",img)
```

思路：

```
imread(filename,flag)，传入文件名和flag值；
img.shape[:2]通过切片读取height和weight；
img=img[50:height-50:3,50:weight-50:5,:]满足题目的要求1和要求2
```

#### 18-4

如果读者正在上大学，那么GPA绩点多半是加权平均的结果。使用average()函数验算一下教务处有没有算错
你的绩点。

答案：

```python
import numpy as np
score=np.array([80,85,83,87,90,96])
weight=np.array([0.3,0.5,0.7,0.2,0.4,0.6])
print(np.average(score,weights=weight))
```

思路：

```
pass
```

