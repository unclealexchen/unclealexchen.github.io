---
title: 《Python编程实践》第19章练习题及解答
date: 2019-08-05 20:09:27
tags: 
  - Python
  - 习题
comments: true
categories:
  - [Python]
meta:
  top: false
  date: true
  categories: true 
  counter: true 
  updated: true
  share: true
  tags: true 
recommended_posts: false
mathjax: true
---



《Python编程实践》第19章练习题及解答



<!-- more -->



> 版权声明
>
> 本文**可以**在互联网上自由转载，但必须：注明出处(作者：陈波，刘慧君)并包含指向本页面的链接。
>
> 本文**不可以**以纸质出版为目的进行改编、摘抄。





#### 19-1

修改“分形蕨类树叶”一节中的方程组系数，观察各系数对最终树叶形状的影响。

答案：

```
四种概率系数统一表示成[[a,b,c],[d,e,f]]。
当系数a,b,d的绝对值增大时，树叶形状会变得宽大；反之会变得窄小；
当系数e的绝对值增大时，树叶会偏向上方，保持其他系数不变，树叶会变得纤细。
```

思路：

```
pass
```



#### 19-2

请在你的计算机上完成MandelbrotComp.pyx的编译，并成功运行InteractiveMandelbrot.py。

答案：

```python
参考19.5节。
```

思路：

```
pass
```
