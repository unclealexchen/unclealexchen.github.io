---
title: 《Python编程实践》第2章练习题及解答
date: 2019-08-01 20:01:40
tags: 
  - Python
  - 习题
comments: true
categories:
  - [Python]
meta:
  top: false
  date: true
  categories: true 
  counter: true 
  updated: true
  share: true
  tags: true 
recommended_posts: false
mathjax: true
---



《Python编程实践》第2章练习题及解答



<!-- more -->



> 版权声明
>
> 本文**可以**在互联网上自由转载，但必须：注明出处(作者：陈波，刘慧君)并包含指向本页面的链接。
>
> 本文**不可以**以纸质出版为目的进行改编、摘抄。





#### 2-1

判断下述变量命名是否正确，如错误，请填写理由。

| 命名    | 正误 | 理由               |
| ------- | ---- | ------------------ |
| M-32    | 错误 | 含有非法字符-      |
| 3K1     | 错误 | 不能以数字开头     |
| iLength | 正确 |                    |
| _Width  | 正确 |                    |
| else    | 错误 | 不能使用关键字命名 |

#### 2-2 

写出下述程序的执行结果：

```python
sName1 = "john miller"
print("1:",sName1.upper())
print("2:",sName1)
```

答案：

```
1: JOHN MILLER
2: john miller
```

思路：

```
upper方法将所有字母变成大写表示，并返回新的字符串
```



#### 2-3 

 写出下述程序的执行结果:

```python
s = "\"Programming\" itself is the best way to learn programming.\n\t---Nobody."
print(s.strip())
```

答案：

```
"Programming" itself is the best way to learn programming.
	---Nobody.
```

思路：

```
在双引号""中使用""或者在单引号''中使用''需要加上\来表示转义字符，
strip()方法去除两端的空格
```

#### 2-4

写出下述程序的执行结果：

```python
r = int(True) + int(bool(-0.0000001)) + int(3 > 2)
print(r)
```

答案：

```
3
```

思路：

```
非0为真，True对应的数值为1，False对应的数值为0,
因此有r=1+1+1=3
```

#### 2-5 

 将信息“Life is short, I want to learn python！”赋值给变量m，再将其打印输出。

```python
m="Life is short,I want to learn python!"
print(m)
```

答案：

```
Life is short,I want to learn python!
```

思路：

```
pass
```

#### 2-6 

打印输出下述内容:

```python
丘吉尔说："成功就是从失败到失败，也依然不改热情！"。
```

答案：

```python
s1="丘吉尔说:\"成功就是从失败到失败，也依然不改热情\""
s2='丘吉尔说:"成功就是从失败到失败，也依然不改热情"'
print(s1)
print(s2)
```



思路：

```
答案中使用两种方法实现。
第一种是在双引号""中使用""，
第二种是在单引号''中使用""。
```

#### 2-7 

按照以下格式打印输出：

```python
My favorite sports are as follows:
	football
	table tennis
	badminton
	swimming
	running
```

答案：

```python
m="My favorite sports are as follows:\n\tfootball\n\ttable tennis\n\tbadminton\n\tswimming\n\trunning"
print(m)
```

思路：

```
注意\n和\t的使用。
```

#### 2-8 

使用str对象的方法把习题2-7中所有的爱好以大写字母的方式打印输出。

答案：

```python
m="My favorite sports are as follows:\n"+"\tfootball\n".upper()+"\ttable tennis\n".upper()+"\tbadminton\n".upper()+"\tswimming\n".upper()+"\trunning".upper()
print(m)
```

思路：

```
注意只是将所有的爱好以大写字母的方式输出，
因此可以在原字符串中就使用upper方法将小写字母转换成大写字母。
```

