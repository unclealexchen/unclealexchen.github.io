---
title: 《Python编程实践》第3章练习题及解答
date: 2019-08-01 20:18:00
tags: 
  - Python
  - 习题
comments: true
categories:
  - [Python]
meta:
  top: false
  date: true
  categories: true 
  counter: true 
  updated: true
  share: true
  tags: true 
recommended_posts: false
mathjax: true
---



《Python编程实践》第3章练习题及解答



<!-- more -->



> 版权声明
>
> 本文**可以**在互联网上自由转载，但必须：注明出处(作者：陈波，刘慧君)并包含指向本页面的链接。
>
> 本文**不可以**以纸质出版为目的进行改编、摘抄。





#### 3-1

找出下述程序中的三处错误：

```python
iScore = 70
if Score >= 60:
  print("You passed.")
else:
	print("You failed.')
```

答案：

```
1、没有Score变量
2、第三行print缩进错误
3、第四行print的双括号或单括号不匹配
```

思路：

```
pass
```

#### 3-2

写出下述程序的执行结果：

```python
a = 70
b = 55.3
c = 9
print(a>=60 and b>=60)
print(a%9+c)
print((not a<90) or b<60)
print(not (a<90 and b<60))
```

答案：

```
False
16
True
False
```

思路：

```
a>=60 and b>=60等价于True and False,从而得到False
a%9+c等价于a%9=7,7+9=16
(not a<90) or b<60等价于(not True) or True,得到False or True,最终是True
not (a<90 and b<60)等价于not(True and True)得到not True，最终是False
```

#### 3-3

写出下述程序的执行结果：

```python
print("%s\t%.1f\t%d\t%.2f" % ("Dora",899,10,899/10))
```

答案：

```
Dora	899.0	10	89.90
```

思路：

```
%s:字符串输出
%t:一个制表符
%.1f:保留一位小数
%d:整数输出
%.2f:保留两位小数
```

#### 3-4

请写出0x0310， 0b01111010的十进制值。

答案：

```
0x0310的十进制为784
0b01111010的十进制为122
```

思路：

```
0x0310为十六进制，转换十进制的过程为0*1+1*16+3*256+0*4096=784
0b01111010为二进制，转换为十进制的过程为：0*1+1*2+0*4+1*8+1*16+1*32+1*64=122
```

#### 3-5

请写出0x8F的二进制值。

答案：

```
0x8F的二进制为0b10001111
```

思路：

```
0x8F为十六进制，转换为二进制，可以使用一位化成四位的方法，
因此有8的二进制为1000；F即15的二进制为1111，
得到0x8F的二进制为10001111。
```

#### 3-6

编写程序，从键盘输入3个整数，输出它们的和与平均值。

答案：

```python
a1=int(input("请输入第一个数："))
a2=int(input("请输入第二个数："))
a3=int(input("请输入第三个数："))
ans=(a1+a2+a3)/3
print("平均值=",ans)
```

思路：

```
通过input读取输入，在将读取的输入转换为int类型。
```

#### 3-7

编程求解鸡兔同笼问题：鸡兔同笼共有30只，脚共有90只，计算笼中鸡兔各有多少只。

答案：

```python
a=90-30*2
rabits=a//2
chickens=30-rabits
print("鸡的数量=",chickens)
print("兔子的数量=",rabits)
```

思路：

```
假设有鸡30只，那么此时总共有60只脚，还需要90-60=30只脚才满足情况。
由于兔子有4只脚，兔子比鸡多出2只脚，因此此时兔子有30/2=15只。
鸡有30-15=15只。
```

#### 3-8

编程序实现功能：输入三角形的三条边边长，求三角形面积，其中面积计算使用用户自定义函数实现。

答案：

```python
from math import sqrt

def Area(a,b,c):
    p=(a+b+c)/2
    s=sqrt(p*(p-a)*(p-b)*(p-c))
    return s

ans=0
a = float(input("请输入第一条边:"))
b = float(input("请输入第二条边:"))
c = float(input("请输入第三条边:"))
if(a+b>c and a+c>b and b+c>a):
    ans=Area(a,b,c)
else:
    print("输入的参数错误，请重新输入")
print("三角形的面积为=",ans)

```

思路：

```
先使用两边之和大于第三边来判断输入的边能否构成三角形，
然后使用海伦公式求出面积。
```

#### 3-9

编程序实现华氏温度到摄氏温度的转换，其转换公式为：c=5/9*(f-32)，其中f表示华氏温度，c表示摄氏温度。

答案：

```python
f=float(input("请输入华氏温度："))
print("摄氏温度为：",5/9*(f-32))
```

思路：

```
pass
```

#### 3-10

输入圆半径计算圆周长、圆面积、圆球表面积，结果保留3位小数。

答案：

```python
from math import acos
r=float(input("请输入圆的半径:"))
pi=3.1415926
print("圆的周长为:%.3f" % (2*pi*r))
print("圆的面积为:%.3f" % (pi*r*r))
print("圆球的表面积为:%.3f" % (4*pi*r*r))
```

思路：

```
答案中根据圆的周长，面积和圆球的表面积公式分别求出答案，%.3f保留3位小数。
```

#### 3-11

编写一个程序，读取英里数然后将它转换为公里数并显示结果。1英里约等于1.609公里。

答案：

```python
a=float(input("请输入英里数："))
print("公里数为：",a*1.609)
```

思路：

```
pass
```

#### 3-12

假设某飞机的加速度是a，起飞的速度是v，下述公式可以计算出该飞机起飞所需的最短跑道长度: L = v<sup>2</sup>/(2a)。编写一个程序，提示用户输入起飞速度v(m/s)和加速度a(m/s<sup>2</sup>)，计算飞机起飞的最短跑道长度。计算过程宜封装成一个函数，该函数接受参数v和a，返回计算所得的L。

答案：

```python
def Length(v,a):
    return v*v/(2*a)

v=float(input("请输入起飞的速度："))
a=float(input("请输入加速度："))
print("飞机起飞的最短跑道长度为：",Length(v,a))
```

思路：

```
定义Lengt函数来求出最短跑道长度，将起飞速度和加速度当做参数传到函数中，最后返回答案。
```

#### 3-13

输入平面上两个点A和B的坐标，(x1,y1)和(x2,y2)，完成如下任务：

1. 逐一要求使用者输入A,B的平面坐标共4个值;
2. 计算两点之间的距离;
3. 利用turtle模块画出两点之间的连线;
4. 在线的中央一侧显示线的长度。  

答案：

```python
from math import sqrt
import turtle

def distance(x_1,y_1,x_2,y_2):
    return sqrt((x_1-x_2)**2+(y_1-y_2)**2)

x1=float(input("请输入A点的横坐标："))
y1=float(input("请输入A点的纵坐标："))
x2=float(input("请输入B点的横坐标："))
y2=float(input("请输入B点的纵坐标："))
mid_x=(x1+x2)/2
mid_y=(y1+y2)/2
dist=distance(x1,y1,x2,y2)
print("两点间的距离为：",dist)
#画图
turtle.up()
turtle.goto(x1,y1)
turtle.down()
turtle.goto(x2,y2)
#显示线的长度
turtle.up()
turtle.goto(mid_x,mid_y)
turtle.down()
turtle.write(str(dist))
turtle.done()
```

思路：

```
本题的难点在于画出两点间的直线。up方法，将画笔抬起，goto方法，到达(x1,y1)坐标处，down方法，画笔下降，goto方式，画笔从(x1,y1)移动到(x2,y2)，画出直线。
write方法，在(mid_x,mid_y)坐标处显示文字。
done方法，暂停程序，查看所画图形。
```