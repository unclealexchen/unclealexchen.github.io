---
title: 《Python编程实践》第4章练习题及解答
date: 2019-08-02 11:28:42
tags: 
  - Python
  - 习题
comments: true
categories:
  - [Python]
meta:
  top: false
  date: true
  categories: true 
  counter: true 
  updated: true
  share: true
  tags: true 
recommended_posts: false
mathjax: true
---



《Python编程实践》第4章练习题及解答



<!-- more -->



> 版权声明
>
> 本文**可以**在互联网上自由转载，但必须：注明出处(作者：陈波，刘慧君)并包含指向本页面的链接。
>
> 本文**不可以**以纸质出版为目的进行改编、摘抄。





#### 4-1

写出下述程序的执行结果：

```python
s1 = [1,3,'5','7',True]
s1.append('False')
del s1[-2]
print("s1=",s1)
s2 = []
s2.extend(['a','b'])
s2.append(['c','d'])
print("s2=",s2)
```

答案：

```
s1= [1, 3, '5', '7', 'False']
s2= ['a', 'b', ['c', 'd']]
```

思路：

```
append('False')，在列表末尾添加元素'False'，因此得到[1,3,'5','7',True,'False']
del s1[-2]，删除s1倒数第二个元素，因此得到[1, 3, '5', '7', 'False']
extend(['a','b'])，将'a','b'分别添加进列表s2中，得到['a', 'b']
append(['c','d'])，将['c','d']作为一个整体添加到s2末尾，得到['a', 'b', ['c', 'd']]
```



#### 4-2

请在Visual Studio Code中输入下述代码并运行; 请对执行结果作出解释。

```python
lst=[23,56,8,900,24]
lst.remove(8)
lst.append(30)
lst.insert(1,22)
lst.extend([66,90])
lst.pop(2)
lst.pop()
lst.sort()
lst.reverse()
print(lst)
```

答案：

```
[900, 66, 30, 24, 23, 22]
```

思路：

```
lst.remove(8)，得到[23,56,900,24]
lst.append(30)，得到[23,56,900,24,30]
lst.insert(1,22)，得到[23,22,56,900,24,30]
lst.extend([66,90])，得到[23,22,56,900,24,30,66,90]
lst.pop(2)，得到[23,22,900,24,30,66,90]
lst.pop()，得到[23,22,900,24,30,66]
lst.sort()，得到[22,23,24,30,66,900]
lst.reverse()，得到[900,66,30,24,23,22]
```



#### 4-3

请写出下述代码的执行结果。

```python
lst=[23,56,8,900,24]
print(lst.index(8))
print(lst.count(8))
print(len(lst))
print(max(lst))
print(sum(lst))
print(min(lst))
```

答案：

```
2
1
5
900
1011
8
```

思路：

```
lst.index(8)，得到数值8的下标2
lst.count(8)，计算数值8出现的次数
len(lst)，得到lst的长度
max(lst)，得到lst列表中的最大值
sum(lst)，对lst的元素进行求和
min(lst)，得到lst列表中的最小值
```



#### 4-4

请写出下述程序的执行结果，本题请人肉计算，避免在计算机上运行。

```python
lst=[23,56,8,900,24]
print(lst[-2])
print(lst[1:4])
print(lst[::2])
print(lst[::-1])
```

答案：

```
900
[56, 8, 900]
[23, 8, 24]
[24, 900, 8, 56, 23]
```



#### 4-5

数字121从左往右读与从右往左读是一样的，这种数称为回文数。请使用for循环以及切片方法设计一个程序，
找出100,000以内的全部回文数。

答案：

```python
#循环：
lst=[]
for num in range(100):
    temp=str(num)
    Len=len(temp)
    flag=True
    for i in range(Len//2):
        if(temp[i]!=temp[Len-1-i]):
            flag=False
            break
    if flag:
        lst.append(num)
print(lst)
#切片
lst=[]
for num in range(100):
    temp=str(num)
    reverseNum=temp[::-1]
    if temp==reverseNum:
        lst.append(num)
print(lst)
```

思路：

```
循环方法：遍历0~100000之间的所有数，为了方便判断回文数，将数值转换成字符串，求出长度。由于回文串满足对称结构，因此从前一半开始遍历，flag初始值为True，遍历过程中不满足回文串条件，flag置False并跳出内层循环；内层循环正常运行结束，flag为True，添加进lst。
切片方法：遍历0~100000之间的所有数，为了方便判断回文数，将数值转换成字符串，并将字符串反转，然后判断两个字符串是否相等，如果相等就是回文数。
```



#### 4-6

使用快速列表生成方法生成一个长度为10的列表。然后，借助于for循环，将列表元素循环左移一个位置。
举例：['a','b','c','d']循环左移一个位置的结果是['b','c','d','a']。

答案：

```python
lst=[x*x for x in range(10)]
print(lst)
a=lst[0]
for i in range(9):
    lst[i]=lst[i+1]
lst[9]=a
print(lst)
```

思路：

```
先用一个变量存储lst[0]，然后循环将lst左移以为，最后将lst[0]赋值给lst[9]
```



#### 4-7

编写程序找出整数列表中最大元素的下标，如果最大元素的个数超过1，那么请打印输出所有的下标。

答案：

```python
import  random
lst=[]
for i in range(20):
    lst.append(random.randint(0,15))
print(lst)
Max=max(lst)
ans=[]
for i in range(len(lst)):
    if Max==lst[i]:
        ans.append(i)
print(ans)
```

思路：

```
先用max方法得到最大数Max，然后遍历列表，将所有的Max下标添加进ans列表中。
```



#### 4-8

 编写程序删除列表中的重复值。

答案：

```python
import random
lst=[]
for i in range(20):
    lst.append(random.randint(0,15))
print(lst)

for x in lst:
    Count=lst.count(x)
    if Count>=2:
        for i in range(Count-1):
            lst.remove(x)
print(lst)
```

思路：

```
当lst.count(x)大于等于2时，即存在重复，需要执行remove(x)语句Count-1次即可将重复的x删除。
```



#### 4-9

生成一个8行6列的矩阵，其元素值等于该元素所在位置的行号+列号，其中，行列号从1开始计。

答案：

```python
lst=[[x+y for y in range(1,7)] for x in range(1,9)]
print(lst)
```

思路：

```
采用答案的形式生成二维数组，内层循环是range()代表列，外层循环range()代表行。
```



#### 4-10

生成一个6行12列的矩阵，其元素值等于小于20的随机数。

答案：

```python
import random

lst=[[random.randint(0,20) for j in range(12)]for i in range(6)]
print(lst)
```

思路：

```
导入random模块，randint()方法生成随机数。
```



#### 4-11

计一个程序，计算4-9生成的矩阵A与4-10生成的矩阵B的乘积，并打印出结果矩阵C。

提示: p行q列的矩阵A与q行r列的矩阵B可以相乘，其结果为一个p行r列的矩阵C。下述矩阵乘法公式供参考。
$$
C_{ij}=\sum_{k=1}^{q}a_{ik}b_{kj}
$$
答案：

```python
import random
A=[[x+y for y in range(1,7)] for x in range(1,9)]
#print(A)

B=[[random.randint(0,20) for j in range(12)]for i in range(6)]
#print(B)

ans=[]
#8*6 * 6*12 =8*12
for i in range(8):
    C=[]
    for j in range(12):
        temp = 0
        for k in range(6):
            temp+=A[i][k]*B[k][j]
        C.append(temp)
    ans.append(C)
print(ans)
```

思路：

```
矩阵1是n×m的矩阵，矩阵2是j×k的矩阵，若矩阵1和矩阵2满足矩阵乘法的条件，即m=j，进行矩阵乘法后，得到n×k的矩阵。
```



#### 4-12

修改”微实践 - 抓扑克牌的手气"中的程序，将54张牌中的51张随机地分发给三位玩家，每人17张。

答案：

```python
import random
suits = ["Spades","Hearts","Diamonds","Clubs"] #四种花色
ranks = ["A","2","3","4","5","6","7","8","9","10","J","Q","K"] #13种牌面
#将花色与牌面组合并加上大小王，生成54张牌的列表
cards = [x+"_"+y for x in suits for y in ranks] + ["Red Joker", "Black Joker"]
#print(cards)

cardsHold = [] #持牌列表

for j in range(3):
    a = []
    for i in range(17): #循环17次，共取17张牌
        idx = random.randint(0,len(cards)-1) #生成一个0 到 剩余牌数-1的随机数
        c = cards.pop(idx) #将指定下标的牌取出
        a.append(c) #取出的牌添加至持牌列表
    a.sort() #持牌列表排序
    cardsHold.append(a)
print(cardsHold) #打印出来看看手气

```

思路：

```
不同于”微实践 - 抓扑克牌的手气"中的程序，本题中添加了三位玩家。因此，需要添加一个外层循环来表示三位玩家。
```



#### 4-13

下述代码第二、第三行的区别是什么，请通过打印dummy的值来证实/证伪你的判断并说明理由。

```python
dummy = ['bob']
dummy.extend(['henry','mary'])
dummy.append(['henry','mary'])
```

答案：

```
代码第二行扩充两个元素，得到['bob', 'henry', 'mary']
代码第三行添加一个列表作为一个元素，得到['bob', 'henry', 'mary', ['henry', 'mary']]
```

思路：

```
pass
```



#### 4-14

写出下述程序的执行结果：

```python
print(list(range(2,10,3)))
print(list(range(5)))
print(list(range(10,-10,-5)))
```

答案：

```
[2, 5, 8]
[0, 1, 2, 3, 4]
[10, 5, 0, -5]
```

思路：

```
list(range(2,10,3))，从2到10之间，往增大的方向，每隔3位取出一位整数，得到[2,5,8]
list(range(5))，取出0到5之间的整数，，得到[0,1,2,3,4]
list(range(10,-10,-5))，从10到-10之间，往减小的方向，每隔5位取出一位整数，得到[10,5,0,-5]
```

