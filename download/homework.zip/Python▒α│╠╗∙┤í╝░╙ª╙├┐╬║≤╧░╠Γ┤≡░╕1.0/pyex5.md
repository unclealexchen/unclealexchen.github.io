---
title: 《Python编程实践》第5章练习题及解答
date: 2019-08-02 11:51:32
tags: 
  - Python
  - 习题
comments: true
categories:
  - [Python]
meta:
  top: false
  date: true
  categories: true 
  counter: true 
  updated: true
  share: true
  tags: true 
recommended_posts: false
mathjax: true
---



《Python编程实践》第5章练习题及解答



<!-- more -->



> 版权声明
>
> 本文**可以**在互联网上自由转载，但必须：注明出处(作者：陈波，刘慧君)并包含指向本页面的链接。
>
> 本文**不可以**以纸质出版为目的进行改编、摘抄。





#### 5-1

找出下述代码中的错误。

```python
tup = ("a","b","c")
tup.append("d")
tup.remove("a")
tup[2] = "e"
```

答案：

```
第二行，元组没有append方法
第三行，元组没有remove方法
第四行，元组不能修改元素
```

思路：

```
元组是只读的，不能修改。
```



#### 5-2

写出下述程序的执行结果。

```python
t = (2,4,6,8,10)
print(t[0])
print(t[-1])
print(t[:-1])
print(t[1:-1])
print(max(t))
print(len(t))
```

答案：

```
2
10
(2, 4, 6, 8)
(4, 6, 8)
10
5
```

#### 5-3

现在一台计算机A要通过串口把下述列表中的数据发送到另一台计算机B。发送前，计算机A需要把数据打包成
bytearray，然后再通过串口发送；计算机B收到bytearray的原始数据后，需要将原始数据解包成跟发送端一样的
列表。请写一个程序，将列表内容打包成bytearray， 然后再还原成列表。

提示：请查询网络资料，借助struct模块完成相关任务。

列表数据如下：['2018993', 'Andy Hu', 26, 'male', True, 175.3, 78, [12,99,77]]

答案：

```python
#a-->b,list-->str-->bytes
a=['2018993', 'Andy Hu', 26, 'male', True, 175.3, 78, [12,99,77]]

b=str(a).encode()
print(b,type(b))
#b__.d,bytes-->str-->list
c=b.decode()
print(c,type(c))
d=eval(c)
print(d,type(d))
```



#### 5-4

CPU通过一个8位IO口读取了1个字节的内容，现在存储在一个bytes对象里，示例： value = b'\x45'；这8位分
别代表了车间里8个阀门的当前状态，1表示该阀门通，0表示该阀门断。请设计一个程序，从value对象解析出8个
阀门的当前状态，True表示通，False表示断。这8个状态应组织在一个列表中，其中，第i个元素对应value的第i
位。

输出格式示例：[True, False, False, True, True,True,False,False]

答案：

```python
value_byte = b'\x45'
value_int=int.from_bytes(value_byte,'little')
print(value_int)
value_bin=bin(value_int)
value_lst=[False]*8
for i in range(len(value_bin)-1,1,-1):
    value_lst[i-1]=bool(int(value_bin[i])|value_lst[i-1])
print(value_lst)
```

思路：

```
将value转换成十进制value_int，再将value_int转换成二进制，最后通过或运算得到八位二进制value_lst
```

#### 5-5

运行下述程序，会发现结果与预期不太一致：对m\[0]\[1]的修改同时也导致的m\[1]\[1]及m\[2]\[1]的修改。请分析原因。提示：可以打印id(m[0]),id[m[1]],id[m[2]]出来看看。

```python
m = [[0]*4]*3   #生成一个3行4列的矩阵，全部元素为0
m[0][1] = 99    #0行1列元素赋值99
for x in m:
    print(x)
```

执行结果：

```
[0, 99, 0, 0]
[0, 99, 0, 0]
[0, 99, 0, 0]

```

答案：

```
第一行代码，生成一个3行4列的矩阵，全部元素为0
第二行代码，将第0行1列的元素赋值99
每行的首地址都指向同一片内存地址
```

思路：

```
每行的首地址相同。
```

#### 5-6

如何把一个十进制数左移1位，比如56左移一位，右边补0，就成了560。这相当于把原数字乘以10倍。问：一
个数，按二进制左移1位，相当于乘几？ 左移8位呢？ 右移4位呢？

答案：

```python
二进制左移一位，相当于乘2；左移八位，相当于乘2的8次方；右移4位，相当于乘2的-4次方
```

思路：

```
pass
```

