---
title: 《Python编程实践》第6章练习题及解答
date: 2019-08-02 15:59:55
tags: 
  - Python
  - 习题
comments: true
categories:
  - [Python]
meta:
  top: false
  date: true
  categories: true 
  counter: true 
  updated: true
  share: true
  tags: true 
recommended_posts: false
mathjax: true
---



《Python编程实践》第6章练习题及解答



<!-- more -->



> 版权声明
>
> 本文**可以**在互联网上自由转载，但必须：注明出处(作者：陈波，刘慧君)并包含指向本页面的链接。
>
> 本文**不可以**以纸质出版为目的进行改编、摘抄。





#### 6-1

写出程序的输出结果。

```python
def main():
    s = [12,-4,32,-36,12,6,-6]
    s_max, s_sum = 0, 0
    for i in range(len(s)):
        s_sum += s[i]
        if s_sum >= s_max:
        	s_max = s_sum
        elif s_sum < 0:
        	s_sum = 0
    print(s_max)
main()
```

答案：

```
40
```

思路：

```
求最大连续和。
```



#### 6-2

写出程序的输出结果。

```python
i = 1
while i + 1:
    if i > 4:
        print("%d" % i)
        i += 1
        break
    print("%d" % i)
    i += 1
    i += 1
```

答案：

```
1
3
5
```

思路：

```
只有if语句才能跳出循环。当if语句不成立时，实际上每次都执行print和i+=2，因此有i=1,i=2,i=5，当i=5，进入if语句，执行print语句，i+=1，跳出循环。
```



#### 6-3

身体质量指数（英文为Body Mass Index，简称BMI），其值为体重除以身高的平方。体重单位为千克，身高
单位为米。BMI是目前国际上常用的衡量人体胖瘦程度以及是否健康的一个标准。下面是16岁以上人群的BMI图
表：

|    BMI     | 解释 |
| :--------: | :--: |
|   BMI<18   | 超轻 |
| 18<=BMI<25 | 标准 |
| 25<=BMI<27 | 超重 |
|  27<=BMI   | 肥胖 |

编写一个程序，输入用户的体重（Kg）和身高（米），显示其BMI值，并作出解释性评价。

答案：

```python
weight=float(input("请输入体重(Kg):"))
height=float(input("请输入身高(m):"))
value=weight/(height**2)
if value<18:
    print("超轻")
elif value>=18 and value<25:
    print("标准")
elif value>=25 and value<27:
    print("超重")
elif value>=27:
    print("肥胖")
```

思路：

```
使用if...elif...判断即可。
```



#### 6-4

编程序实现功能：输入一个整数，判断其是否能同时被3、5、7整除。能被整除则输出“Yes”，否则, 输出“No”。

答案：

```python
a=int(input("请输入一个整数："))
if a%3==0 and a%5==0 and a%7==0:
    print("Yes")
else:
    print("No")
```

思路：

```
pass
```



#### 6-5

企业发放的奖金根据利润提成。利润低于或等于100,000元的，奖金可提10%；利润高于100,000元，低于
200,000（100,000 < p <=200,000）时，100,000元及以内部分按10%提成，高于100,000元的部分，可提成
7.5%；200,000 < p <= 400,000时，200,000元及其以内的部分仍按上述办法提成（下同），高于200,000元的部
分按5%提成；400,000 < p <=600,000元时，高于400,000元的部分按3%提成；600,000 < p <=1,000,000时，高于600,000元的部分按1.5%提成；p >1,000,000时，超过1,000,000元的部分按1%提成。按上述需求，编写一个程
序，该程序从键盘输入当月利润p，求应发奖金数。

答案：

```python
value=float(input("请输入当月的利润:"))
value/=10000

def fun_1(temp=10):
    return temp*0.1#1

def fun_2(temp=20):
    return fun_1()+(temp-10)*0.075#10*0.075

def fun_3(temp=40):
    return fun_2()+(temp-20)*0.05#20*0.05

def fun_4(temp=60):
    return fun_3()+(temp-40)*0.03#20*0.03

def fun_5(temp=100):
    return fun_4()+(temp-60)*0.015#20*0.015

def fun_6(temp):
    return fun_5()+(temp-100)*0.01

add=0
if value<=10:
    add=fun_1(value)
elif value>10 and value<=20:
    add=fun_2(value)
elif value>20 and value<=40:
    add=fun_3(value)
elif value>40 and value<=60:
    add=fun_4(value)
elif value>60 and value<=100:
    add=fun_5(value)
elif value>100:
    add=fun_6(value)

value+=add
print("应发的奖金数为：(元)",value*10000)
```

思路：

```
本题中，分别求出不同区间的奖金再求和。为了简化问题，先将value/10000，输出的时候再执行value*10000。
```

#### 6-6

在视线不太好的黑夜一司机撞伤行人之后逃逸，有3个目击者记住了该车的部分车号特征。甲说：“车牌号的前两位相同，且末位数是奇数”；乙说：“车牌号的后两位加起来等于5”；丙说：“车牌号是一个四位数，并且能被3整除”。请你写一个程序，找出肇事车可能的车牌号。

答案：

```python
for i in range(1000,10000):
    x=str(i)
    a=int(x[0]),int(x[1]),int(x[2]),int(x[3])
    if a[0]==a[1] and a[3]%2 and a[2]+a[3]==5 and i%3==0:
        print(i)
```

思路：

```
遍历所有的四位数再对所有条件进行判断。
```



#### 6-7

 编写程序按下述公式求e的近似值(精度为10<sup>-6</sup>)。
$$
e = \sum_{n=0}^{k}{\frac{1}{n!}}
$$
答案：

```python
def fact(n):
    if n==0:
        return 1
    else:
        return n*fact(n-1)
ans1=0
ans2=1
n=0
while True:
     t=1/fact(n)
     if t<1e-6:
          break
     ans1=ans1+t
     n+=1
print(ans1)
```

思路：

```
本题的思想是，最后一项绝对值少于1e-6停止计算。
```

#### 6-8

有列表["python","computer","book","programe"]，编写程序统计列表中每个字母出现的次数。

答案：

```python
values=["python","computer","book","programe"]
Count={}
for value in values:
    for i in value:
        if i not in Count:
            Count[i] = 1
        else:
            Count[i]+=1
print(Count)
```

思路：

```
首先遍历所有的单词，然后遍历所有单词的字母，使用字典实现。
```

#### 6-9

一个整数，它加上100后是一个完全平方数，再加上168又是一个完全平方数，请问该数是多少？

答案：

```python
from math import sqrt
x=0
while True:
    a=x+100
    b=x+168
    a=sqrt(a)
    b=sqrt(b)
    if a==int(a) and b==int(b):
        print(x)
        break
    x+=1
```

思路：

```
从x=0开始，循环遍历所有情况，满足情况后跳出循环。注意float类型和int类型判断相等。
```

#### 6-10

某情报机构采用公用电话传递数据，数据是5位的整数，每位整数都在0~6之间，在传递过程中是加密的。加密规则如下：每位数字都加上8,然后用和除以7的余数代替该数字，再将第1位和第5位交换，第2位和第3位交换。请编写程序，完成明文至密文的加密过程。

答案：

```python
def encode(value_list):
    value_list=[(x+8)%7 for x in value_list]
    value_list[0],value_list[4]=value_list[4],value_list[0]
    value_list[1], value_list[2] = value_list[2], value_list[1]
    return value_list

num=input("请输入一个5位整数（10000-66666之间）：")
value_list=[0,0,0,0,0]
idx=0
for i in num:
    value_list[idx]=int(i)
    idx+=1
print(value_list)
value_encode=encode(value_list)#加密
print(value_encode)
```

思路：

```
把输入的5位整数拆分存入value_list列表中，然后对列表中的数字进行加密操作
```

#### 6-11

折半查找：1个列表里存储了20个子列表，各子列表内存储了学生的学号及姓名两个元素，两个元素都是字符串类型。现已知该20个学生子列表已按学号递增序排好序。请设计一个程序，使用折半查找算法通过最少次数的比较找到指定学号的学生，如果没有，报告未找到。
数据示例：[ ['201801', '张三'], ['201822', 'Andy Lee'], ... ,['20189X','Austin Hu'] ]
折半查找算法：先把被查找值与序列中间位置的元素比较，如果相等表示已找到。如果查找值 < 中位元素，这说明查找值在中位元素的左边，如果查找值 > 中位元素，则说明查找值在中位元素的右边。每进行一次比较，我们大概可以把查找范围缩小一半。这种同中位元素进行比较的方法可以一直持续下去，直到找到或者发现找不到为止。最坏情况下，我们要进行logN次比较，N为序列的长度。

答案：

```python
num=int(input("请输入要查找的学生学号："))
Stu=[[str(2018+i),str(i+20)] for i in range(21)]
print(Stu)
bottom=0
top=len(Stu)-1
while(bottom<=top):
    mid=(bottom+top)//2
    if(num==int(Stu[mid][0])):
        print("已找到")
        break
    elif(num>int(Stu[mid][0])):
        bottom=mid+1
    elif(num<int(Stu[mid][0])):
        top=mid-1
else:
    print("没有找到")
```

思路：

```
设置上下边界top和bottom，当num大于Stu[mid][0]时，说明在右边，设置下边界；当num小于Stu[mid][0]时，说明在左边，设置上边界。当找到时，通过break跳出，循环外面的else不执行；否则，执行。
```

