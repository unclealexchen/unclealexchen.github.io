---
title: 《Python编程实践》第7章练习题及解答
date: 2019-08-02 16:35:54
tags: 
  - Python
  - 习题
comments: true
categories:
  - [Python]
meta:
  top: false
  date: true
  categories: true 
  counter: true 
  updated: true
  share: true
  tags: true 
recommended_posts: false
mathjax: true
---



《Python编程实践》第7章练习题及解答



<!-- more -->



> 版权声明
>
> 本文**可以**在互联网上自由转载，但必须：注明出处(作者：陈波，刘慧君)并包含指向本页面的链接。
>
> 本文**不可以**以纸质出版为目的进行改编、摘抄。





#### 7-1

写出下述程序的执行结果。

```python
jack = {'id':'10000', 'name':'Jack Ma', 'gender':'male','age':47, 'title':'CEO'}
print(jack["name"])
print(jack.get("salary",10000))
```

答案：

```
Jack Ma
10000
```

思路：

```
jack.get("salary",10000)的get方法，通过关键字"salary"取出值，当关键字"salary"不存在时，添加该关键字"salary"并初值为10000。
```



#### 7-2

写出下述程序的执行结果。

```python
phoneBook = {'Alex':'6511-2002','Betty':'6512-7252','Dora':'6546-2708'}
phoneBook2 = phoneBook
phoneBook2['Betty'] = '1111-2222'
print(phoneBook['Betty'])
print(phoneBook2['Betty'])
```

答案：

```
1111-2222
1111-2222
```

思路：

```
名字绑定。
```

#### 7-3

写出下述程序的执行结果。

```python
stu = {"name":"Eric Zhang","english":80,"python":90,"math":100}
print(len(stu))
print(stu["name"])
print(list(stu.keys()))
print("math" in stu)
print(stu["math"]+10)
print(stu["math"])
print(list(stu.items())[1])
print(list(stu.values())[2])
```

答案：

```
4
Eric Zhang
['name', 'english', 'python', 'math']
True
110
100
('english', 80)
90
```

思路：

```
list(stu.keys())，取出所有的关键字
list(stu.items())[1]，取出第二个键值对
print(list(stu.values())[2])，取出字典中第三个键值对中的值
```

#### 7-4

存储学生张三成绩的字典结构如下：

```python
stu={"name":"张三","english":80,"python":90,"math":100}
```

1）请使用上述结构输入5个学生的name及english、python和math三门课的成绩并存储到列表scores中；
2）计算每个同学的平均成绩，同时在字典中添加关键字"avg"用来表示平均成绩；
3）按照每个学生的平均成绩由高到低排序输出5个学生的相关信息。

答案：

```python
score=[]
for i in range(5):#使用循环自动生成5个学生数据
    stu={}
    stu["name"]="张"+str(i)
    stu["english"]=80+i
    stu["python"] =90+i
    stu["math"] =100+i
    score.append(stu)

for i in range(len(score)):
    avg=(score[i]["english"]+score[i]["python"]+score[i]["math"])/3
    score[i]["avg"]=avg
print(score)

print(sorted(score,key=lambda x:x["avg"],reverse=True))
```

思路：

```
sorted方法中，key=lambda x:x["avg"]使用列表score每一项的关键字"avg"的值来排序。
```

#### 7-5

编写一个程序读取未指定个数的字符串，找出出现次数最多的字符串。例如输入abc bcd abc ddd bbb,那么字
符串“abc”出现的次数最多。

答案：

```python
s=input("请输入字符串:") or "None"
Count={}
Max=0
while(s !="None"):
    Count[s]=Count.get(s,0)+1
    if Count[s]>Max:
        Max=Count[s]
    s = input("请输入字符串:") or "None"
for k,v in Count.items():
    if(v==Max):
        print(k)
```

思路：

```
通过循环输入字符串，只输入回车时结束输入，通过字典记录每个字符串出现的次数，比较出最大的次数Max，遍历整个字典，输出值为Max的关键字。
```

#### 7-6

编写一个程序，计算用户输入句子中的单词数以及平均单词长度。

答案：

```python
value=input("请输入句子:")
lst=value.split()
print(lst)
length=0
for i in lst:
    length+=len(i)
print(len(lst))
print(length/len(lst))
```

思路：

```
使用split方法，按照空格把字符串拆开成多个字符串，并放入一个列表中返回。遍历列表中的每个字符串，统计单词的所有长度，使用len方法得出列表中的单词数。
```

#### 7-7

写出程序的输出结果。

```python
s1 = "ABCCCCBB"
counts={}
for x in s1:
    counts[x] = counts.get(x,0)+1
lst = list(counts.items())
lst.sort(key=lambda x:x[1],reverse=True)
for i in range(len(lst)):
    print("{}出现{}次".format(lst[i][0],lst[i][1]))
```

答案：

```
C出现4次
B出现3次
A出现1次
```

思路：

```
lst为字典counts的所有项目列表，lst.sort(key=lambda x:x[1],reverse=True)，使用列表中每一项的第二个参数从大到小排序。
```

