---
title: 《Python编程实践》第8章练习题及解答
date: 2019-08-02 21:51:06
tags: 
  - Python
  - 习题
comments: true
categories:
  - [Python]
meta:
  top: false
  date: true
  categories: true 
  counter: true 
  updated: true
  share: true
  tags: true 
recommended_posts: false
mathjax: true
---



《Python编程实践》第8章练习题及解答



<!-- more -->



> 版权声明
>
> 本文**可以**在互联网上自由转载，但必须：注明出处(作者：陈波，刘慧君)并包含指向本页面的链接。
>
> 本文**不可以**以纸质出版为目的进行改编、摘抄。





#### 8-1

写出下述程序的执行结果。

```python
def func():
    x = 77
    z = y * 2
    print("x+y=",x+z)
    
x = 1
y = 1
func()
print("x=",x)
print("y=",y)

```

答案：

```
x+y= 79
x= 1
y= 1
```

思路：

```
func中的x与全局变量x同名，在函数中优先使用func中的x；
func没有y变量，调用全局变量y，
函数外，优先使用全局变量x,y。
```



#### 8-2

写出下述程序的执行结果，并描述执行过程。

```python
def func(x):
    if x <= 1:
    	return 1
    return x + func(x-2)
print(func(9))
```

答案：

```
25
递归计算1~9的奇数和。
```

思路：

```
func(9)=9+func(7)=9+7+func(5)=9+7+5+func(3)=9+7+5+3+func(1)=9+7+5+3+1=25
```

#### 8-3

编写一个函数，计算一个整数的各位数字之和。

答案：

```python
def caculate(temp):
    ans=0
    while(temp):
        ans+=temp%10
        temp//=10
    return  ans

a=int(input("请输入一个整数："))
print(caculate(a))
```

思路：

```
多次使用取模运算%，每次取出该整数的一位数，然后通过除以10，“消去”取出的整数，直到没有数可以取出。
```

#### 8-4

编写函数计算f(i)。

f(i)=1/2+2/3+3/4+…+i/(i+1)

答案：

```python
def caculate(n):
    x=1
    ans=0;
    while(x<=n):
        ans+=x/(x+1)
        x+=1
    return ans

value=int(input("请输入正整数n："))
print(caculate(value))
```

思路：

```
pass
```

#### 8-5

编写3个函数分别实现把一个整数转换成十六进制、八进制、二进制表示的字符串。

答案：

```python
def My_Hexadecimal(temp):
    ans=""
    Map={0:"0",1:"1",2:"2",3:"3",4:"4",5:"5",6:"6",7:"7",8:"8",9:"9",
         10:"A",11:"B",12:"C",13:"D",14:"E",15:"F"}
    while(temp):
        ans+=Map[temp%16]
        temp//=16
    return ans[::-1]

def My_Octonary(temp):
    ans=""
    while (temp):
        ans+=str(temp%8)
        temp //= 8
    return ans[::-1]

def My_Binary(temp):
    ans = ""
    while (temp):
        ans+=str(temp%2)
        temp //= 2
    return ans[::-1]

value=int(input("请输入一个整数："))
print("十六进制：0x",My_Hexadecimal(value))
print("八进制：0o",My_Octonary(value))
print("二进制：0b",My_Binary(value))

```

思路：

```
一个十进制数n转换成R进制，基本方法是a=n%r,n//=r，直到n为0，最后将所有的a反序输出。
```

#### 8-6

编写函数计算一个或不特定多个数的乘积。

答案：

```python
def caculate(*temp):
    ans=1
    for x in temp:
        ans*=x
    return ans

print(caculate(1,2,3,4,5))
```

思路：

```
使用*temp读取不特定多个数
```

#### 8-7

回文素数是指一个数既是素数又是回文数，例如131既是素数又是回文数。编写程序打印输出前100个回文素
数。要求每行打印输出10个，判断素数和实现反序数都用函数实现。

答案：

```python
def Prime():
    prime=[]
    count={}
    for i in range(2,100000):
        temp=i
        if temp not in count:
            prime.append(temp)
        while(temp<=100000):
            count[temp]=1
            temp+=i
    return prime

def judge(temp):
    value_str=str(temp)
    Len=len(value_str)
    for i in range(Len//2):
        if(value_str[i]!=value_str[Len-1-i]):
            return False
    return True

prime=Prime()
ans=[]
count=0
for i in prime:
    if(judge(i)):
        ans.append(i)
        count+=1
        if count>=100:
            break
print(count)
cnt=0
for x in ans:
    print(x,end=" ")
    cnt+=1
    if cnt%10==0:
        print("")
```

思路：

```
使用素数筛选法，将2~100000的所有素数都筛选出来，然后遍历所有素数，判断其是否是反序数,将满足要求的前100个存入列表ans中，最后每行打印十个。
```

#### 8-8

折半查找：1个列表里存储了20个子列表，各子列表内存储了学生的学号及姓名两个元素，两个元素都是字符
串类型。现已知该20个学生子列表已按学号递增序排好序。请设计一个程序，使用折半查找算法通过最少次数的比较找到指定学号的学生，如果没有，报告未找到。
数据示例：[ ['201801', '张三'], ['201822', 'Andy Lee'], ... ,['20189X','Austin Hu'] ]
折半查找算法：先把被查找值与序列中间位置的元素比较，如果相等表示已找到。如果查找值 < 中位元素，这说明查找值在中位元素的左边，如果查找值 > 中位元素，则说明查找值到中位元素的右边。每进行一比较，我们大概可以把查找范围缩小一半。这种同中位元素进行比较的方法可以一直持续下去，直到找到或者发现找不到为止。最坏情况下，我们要进行logN次比较。

答案：

```python
def Binary_Find(Stu):
    bottom = 0
    top = len(Stu) - 1
    while (bottom <= top):
        mid = (bottom + top) // 2
        if (num == int(Stu[mid][0])):
            return "已找到"
            break
        elif (num > int(Stu[mid][0])):
            bottom = mid + 1
        elif (num < int(Stu[mid][0])):
            top = mid - 1
    else:
        return "没有找到"
num=int(input("请输入要查找的学生学号："))
Stu=[[str(2018+i),str(i+20)] for i in range(21)]
print(Binary_Find(Stu))


```

思路：

```
参考6-11
```

#### 8-9

本章分治法寻找假硬币的示例程序使用了递归函数。请修改该示例程序，消除函数的递归调用，变成非递归程
序，功能不变。

答案：

```python
def findFalseCoin(coins,start,n):
    bottom=start
    num=n
    while(num):
        mid=num//2
        ans_left=sum(coins[bottom:bottom+mid])
        ans_right=sum(coins[bottom+mid:bottom+mid+mid])
        if ans_left<ans_right:
            pass
        elif ans_left>ans_right:
            bottom=bottom+mid
        elif mid*2<num:
            return bottom+num-1
        else:
            return None
        num=mid
        if num==1:
            return bottom


coins = [100,100,100,100,100,100,100,100,99]
r = findFalseCoin(coins,0,len(coins))
print(('假硬币:%d' %r) if r!=None else '没有发现假硬币')
```

思路：

```
本题与二分查找类似，不同点在于本题将每次比较的硬币数进行二分。
当左边的重量小于右边的重量时，说明假币在左边，将比较的硬币数除以2；
当左边的重量大于右边的重量时，说明假币在右边，修改比较的起点bottom=bottom+mid，将比较的硬币数除以2；
当左边的重量等于右边的重量时，如果此时的硬币数是奇数，则最后一个硬币是假的；如果是偶数，则没有假硬币；
注意，当存在假硬币并且比较的硬币数为1时，直接返回bottom。
```

