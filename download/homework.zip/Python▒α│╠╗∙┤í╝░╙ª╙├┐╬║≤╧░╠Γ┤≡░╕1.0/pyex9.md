---
title: 《Python编程实践》第9章练习题及解答
date: 2019-08-02 22:22:53
tags: 
  - Python
  - 习题
comments: true
categories:
  - [Python]
meta:
  top: false
  date: true
  categories: true 
  counter: true 
  updated: true
  share: true
  tags: true 
recommended_posts: false
mathjax: true
---



《Python编程实践》第9章练习题及解答



<!-- more -->



> 版权声明
>
> 本文**可以**在互联网上自由转载，但必须：注明出处(作者：陈波，刘慧君)并包含指向本页面的链接。
>
> 本文**不可以**以纸质出版为目的进行改编、摘抄。





#### 9-1

写出下述程序的执行结果。

```python
class Fun:
    def __init__(self):
        print("Fun.__init__()")
    def test(self):
        print("Fun")
class InheritFun(Fun):
    def __init__(self):
        print("InheritedFun.__init__()")
        super().__init__()
    def test(self):
        super().test()
        print("InheritedFun")
a = InheritFun()
a.test()
```

答案：

```
InheritedFun.__init__()
Fun.__init__()
Fun
InheritedFun
```

思路：

```
注意print和super()的调用顺序。
```



#### 9-2

写出下述程序的执行结果。

```python
from math import *
class Circle:
    def __init__(self, radius = 1):
        self.radius = radius
    def getPerimeter(self):
        return 2 * self.radius * pi
    def getArea(self):
        return self.radius * self.radius * pi
    def setRadius(self, radius):
        self.radius = radius

a = Circle(10)
print("{:.1f},{:.2f}".format(a.getPerimeter(),a.getArea()))
```

答案：

```
62.8,314.16
```

思路：

```
Circle(10)实例化一个Circle()类并赋值给a，在print中调用getPerimeter()和getArea()。
```

#### 9-3

9-3 按图施工，设计下述BMI类，用于计算身体质量指数。请创建BMI类型的对象，计算并打印某人的身体质量指数及定性评价。相关计算公式及评价方法参考习题6-3。

![1562477744073](..\assets\1562477744073.png)



答案：

```python
class BMI:
    def __init__(self,name,age,height,weight):
        self.name=name
        self.age=age
        self.height = height
        self.weight=weight

    def getBMI(self):
        return self.weight / (self.height ** 2)

    def getStatus(self):
        value = self.weight / (self.height ** 2)
        if value < 18:
            return "超轻"
        elif value >= 18 and value < 25:
            return "标准"
        elif value >= 25 and value < 27:
            return "超重"
        elif value >= 27:
            return "肥胖"

bmi=BMI("Me",18,1.7,60)
print(bmi.getBMI())
print(bmi.getStatus())
```

思路：

```
pass 
```

#### 9-4

图书馆里有很多的书， 请试着定义一个名为Book的类。考虑书名、书号、单价等属性。请为Book类定义一个
构造函数__init__()以及一个析构函数__del__()，构造函数应包括书名，书号及单价三个参数并执行属性的初始化；
析构函数则向控制台打印下述形式的信息：

Book destroyed - 书名，书号, 单价。

答案：

```python
class Book:

    def __init__(self,name,no,price):
        print("Book init")
        self.name=name
        self.no=no
        self.price=price

    def __del__(self):
        print("Book destroyed - ",self.name,self.no,self.price)

book=Book("OK",101,50)
```

思路：

```
pass
```

#### 9-5

设计一个类Root来计算ax<sup>2</sup>+bx+c=0的根。该类包括：a、b、c共3个属性表示方程的3个系数，getDiscriminant()方法返回b<sup>2</sup>-4ac, getRoot1()和getRoot2()返回方程的两个根。编写一个程序提示用户输入3个系数，打印输出方程式求根的结果。

答案：

```python
from math import *
class Root:

    def __init__(self,a,b,c):
        print("init")
        self.a=a
        self.b=b
        self.c=c

    def getDiscriminant(self):
        return self.b**2-4*self.a*self.c

    def getRoot1(self):
        return (-self.b+sqrt(self.getDiscriminant()))/(2*self.a)

    def getRoot2(self):
        return (-self.b-sqrt(self.getDiscriminant()))/(2*self.a)

a=float(input("请输入二次项系数："))
b=float(input("请输入一次项系数："))
c=float(input("请输入常数项系数："))

root=Root(a,b,c)
if root.getDiscriminant()>0:
    print(root.getRoot1())
    print(root.getRoot2())
elif root.getDiscriminant()==0:
    print(root.getRoot1())
else:
    print("No Root!")
```

思路：

```
pass
```

#### 9-6

设计一个名为Stock的类来表示一个公司的股票，包括以下内容：
1）股票代码、股票名称、前一天股票价格、当前股票价格4个属性；
2）构造方法，需初始化代码、名称、前一天价格和当前价格等属性；
3）返回股票名字的get方法;
4）返回股票代码的get方法;
5）获取和设置股票前一天价格的get和set方法;
6）获取和设置股票当前价格的get和set方法;
7）名为getChangePercent()方法，返回前日收市价至当前价格的变化百分比；

编写一个程序，创建一个Stock对象，它的代码是601318，名字是中国平安，前一天的价格是63.21，当前价格是
64.39。打印显示该股票的相关信息及价格改变百分比。

答案：

```python
class Stock:
    "Stock"
    def __init__(self,code,name,pre_price,cur_price):
        print("init")
        self.code=code
        self.name=name
        self.pre_price=pre_price
        self.cur_price=cur_price

    def getName(self):
        return self.name

    def getCode(self):
        return self.code

    def getPre_price(self):
        return self.pre_price
    def setPre_price(self,pre_price):
        self.pre_price=pre_price

    def getCur_price(self):
        return self.cur_price
    def setCur_price(self,cur_price):
        self.cur_price=cur_price

    def getChangePercent(self):
        return (self.cur_price-self.pre_price)/self.pre_price

    def show(self):
        print("股票代码：",self.code,"-股票名称：",self.name,"-股票昨日价格：",self.pre_price,
              "-股票今日价格：",self.cur_price)

stock=Stock(601318,"中国平安",63.21,64.39)
stock.show()
print("价格改变百分比%.2f%%"%(stock.getChangePercent()*100))
```

思路：

```
pass
```

#### 9-7

设计一个基类 Shape。该类包含3个属性：图形名称-name、图形面积-area和图形周长-perimeter。 该类包含
3个成员函数：calArea() - 计算并返回该图形的面积；calPerimeter() - 计算并返回该图形的周长；display() - 打印
输出图形名称、面积、周长。设计三个派生类： Rectangle、 Triangle、 Circle，请为派生类定义合适的数据成员
用于表达其结构，派生类应重载实现基类中的全部成员函数。

答案：

```python
from math import *

class Shape():
    def __init__(self,name=None,area=None,perimeter=None):
        print("init")
        self.name=name
        self.area=area
        self.perimeter=perimeter

    def calArea(self):
        pass

    def calPerimeter(self):
        pass

    def display(self):
        pass

class Rectangle(Shape):

    def __init__(self,name,length,width):
        Shape.__init__(self,name=name)
        self.length=length
        self.width=width

    def calArea(self):
        self.area=self.length*self.width
        return self.area

    def calPerimeter(self):
        self.perimeter=2*(self.length+self.width)
        return self.perimeter

    def display(self):
        print("名字:",self.name,"面积:",self.calArea(),"周长:",self.calPerimeter())

class Triangle(Shape):

    def __init__(self,name,a,b,c):
        Shape.__init__(self,name=name)
        self.a=a
        self.b=b
        self.c=c

    def calArea(self):
        temp=self.calPerimeter()/2
        self.area=sqrt(temp*(temp-self.a)*(temp-self.b)*(temp-self.c))
        return self.area

    def calPerimeter(self):
        self.perimeter=self.a+self.b+self.c
        return self.perimeter

    def display(self):
        print("名字:",self.name,"面积:",self.calArea(),"周长:",self.calPerimeter())


class Circle(Shape):

    def __init__(self,name,radius):
        Shape.__init__(self,name=name)
        self.radius=radius

    def calArea(self):
        self.area=self.radius**2*pi
        return self.area

    def calPerimeter(self):
        self.perimeter=2*pi*self.radius
        return self.perimeter

    def display(self):
        print("名字:",self.name,"面积:",self.calArea(),"周长:",self.calPerimeter())

rectangle=Rectangle("长方形",3,4)
triangle=Triangle("三角形",3,4,5)
circle=Circle("圆",2)

rectangle.display()
triangle.display()
circle.display()
```

思路：

```
首先编写基类Shape，然后Rectangle，Triangle，Circle分别继承自Shape，添加各自所需要的属性以及编写实例化基类的代码，重载calArea，calPerimeter和display函数。
```

#### 9-8

编写程序, 设计一个学生类。包含姓名、学号及计数器3个属性, 其中计数器属性用来统计总共实例化了多少个
学生。

答案：

```python
class Student:

    StudentCount=0
    def __init__(self,name=None,code=None):
        self.name=name
        self.code=code
        Student.StudentCount+=1

stu1=Student()
stu2=Student()
stu3=Student()
print(Student.StudentCount)
```

思路：

```
创建一个类对象的属性StudentCount=0，每次实例化一个类对象时，都会调用Student.StudentCount+=1
```

#### 9-9

从set类型继承，并设计一个名为CountedSet的子类型。通过重载set类型的某些函数，使得CountedSet对象
可以统计并记录各个元素被放入集合的总次数。下述伪代码描述了该CountedSet类型被使用的场景。

```python
class CountedSet(set):
	pass
s = CountedSet()
s.add("a")
s.add("c")
s.add("a")
a = s.getCount("a") #a值应为2
c = s.getCount("c") #c值应为1
```

答案：

```python
class CountedSet(set):

    def __init__(self):
        self.count={}

    def getCount(self,temp):
        return self.count[temp]

    def add(self,temp):
        self.count[temp]=self.count.get(temp,0)+1
```

思路：

```
使用字典实现。
```

