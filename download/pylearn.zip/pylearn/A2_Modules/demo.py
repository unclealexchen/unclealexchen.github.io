import os   #operating system 
print(os.__file__)


