import Utils
print(Utils.something)