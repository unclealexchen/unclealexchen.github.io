#Gamma.py
import scipy.special as S
print("gamma(5)=",S.gamma(5))
print("gamma(1+1.2j)=",S.gamma(1+2.1j)) #复数参数
