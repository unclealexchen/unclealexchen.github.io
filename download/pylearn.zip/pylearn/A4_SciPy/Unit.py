#Unit.py
from scipy import constants as C
print("C.mile =",C.mile)      #一英里等于多少米
print("C.gram =",C.gram)      #一克等于多少千克
print("C.pound =",C.pound)     #一磅等于多少千克
print("C.gallon =",C.gallon)    #一加仑等于多少立方米