import glob 
images = glob.glob("images/*.jpg") 
print(images)