print("'","center".center(40),"'")
print("center".center(40,"*"))