print("one two three four little indian boys".rsplit())

