s = "Python is easy to learn, easy to use."
print(s.find("to",0,len(s)))
print(s.find("not exist"))