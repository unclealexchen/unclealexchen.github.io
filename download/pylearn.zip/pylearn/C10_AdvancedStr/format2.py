sText = "pi = {pi:e}.".format(pi=3.1415926535897932)
print("pi:e", sText)
sText = "pi = {pi:.2f}.".format(pi=3.1415926535897932)
print("pi:.2f",sText)
sText = "pi = {pi:.1%}.".format(pi=3.1415926535897932)
print("pi:.1%",sText)

sText = "objectCount = {objCount:d}.".format(objCount=77)
print("objCount:d",sText)
sText = "objectCount = {objCount:b}.".format(objCount=77)
print("objCount:b",sText)
sText = "objectCount = {objCount:o}.".format(objCount=77)
print("objCount:o",sText)

