print("pi = {pi:10.2f}".format(pi=3.1415926535497932))
print("1k Bytes = {num:10} Bytes".format(num=1024))
print("{:.5}".format("Da Vinci"))
print("pow(2,64) = {:,}".format(2**64))