# <Python编程基础及应用> 随书代码 高等教育出版社
dirs = ["","home","pi","doc","Python"]
print("/".join(dirs))
print("c:" + "\\".join(dirs))

numbers = ("1","2","3")
print(" + ".join(numbers), "=", sum((1,2,3)) )