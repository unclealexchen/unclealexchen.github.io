sText = "Python is a programming language, Python is good."
sNew = sText.replace("Python","C++")
print(sText)
print(sNew)