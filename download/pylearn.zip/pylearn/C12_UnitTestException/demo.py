x=5
y=2
for i in range(3):
    try:
        x = x - 2
        z = y / x
        print(z)
    except Exception:
        print("error!")
    else:
        print("正常运行")
    finally:
        print("finally")