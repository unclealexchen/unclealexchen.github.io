n = 2**64 - 1
print(n)

d = 3600 * 24 * 365
print(d)

print(n/d)

print((2**64-1)/31536000)
