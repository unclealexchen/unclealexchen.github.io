s1 = [1,3,'5','7',True]
s1.append('False')
del s1[-2]
print("s1=",s1)
s2 = []
s2.extend(['a','b'])
s2.append(['c','d'])
print("s2=",s2)