from os import chdir
print("------------help(chdir)---------------")
help(chdir)
print("------------chdir.__doc__-------------")
print(chdir.__doc__)
