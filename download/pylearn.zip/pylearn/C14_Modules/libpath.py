#libpath.py
import sys
import pprint
sys.path.append("d:\\UserDefinedPath")
pprint.pprint(sys.path)

