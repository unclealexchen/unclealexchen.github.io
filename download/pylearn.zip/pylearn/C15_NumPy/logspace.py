import numpy as np

print(np.logspace(0,2,5,endpoint=False))
print(np.logspace(0,4,5,base=2))