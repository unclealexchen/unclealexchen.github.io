import numpy as np

idx = np.s_[::3,2::2]
print(idx)
print(type(idx))