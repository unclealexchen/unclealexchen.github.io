import numpy as np
print(np.zeros((2,3),np.int))
print(np.empty(4,np.float))
print(np.ones((2,2),np.uint64))
print(np.full(3,np.pi))