my_foods = [1,9,0,3,7]
friend_foods = my_foods[:]
print(friend_foods[-1::-2])








