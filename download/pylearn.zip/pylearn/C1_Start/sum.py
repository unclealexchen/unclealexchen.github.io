#sum.py
sum = 0
for i in range(1,101):
    sum += i
print("1+2+3...+100 =",sum)

