#Constants.py
from scipy import constants as C
print("c =",C.c)    #光在真空中的传播速度
print("g =",C.g)    #重力常数
