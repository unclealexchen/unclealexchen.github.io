n = 3
print(n, type(n))					#n的数据类型为整数/int
f = 3.1415926				
print(f,type(f))					#f的数据类型为浮点数/float
s = "How beautiful my life is. "
print(s, type(s))					#s的数据类型为字符串/str
b = 3 < 2
print(b)							#b的数据类型为布尔型/bool
print("3<2", type(b))