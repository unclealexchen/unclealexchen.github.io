print("I know many popular programming languages as follows:"
"\n\tJavaScript\n\tPython\n\tJava\n\tC\n\tC++\n\tRuby")