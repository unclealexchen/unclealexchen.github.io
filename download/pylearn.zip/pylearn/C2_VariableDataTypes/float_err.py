n = 0.14
n = n * 100
print(n)

if n==14:
    print("0.14*100 == 14")
else:
    print("0.14*100 <> 14")