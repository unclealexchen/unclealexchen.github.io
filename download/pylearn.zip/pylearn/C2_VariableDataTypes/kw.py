#kw.py
import keyword
print(keyword.kwlist)