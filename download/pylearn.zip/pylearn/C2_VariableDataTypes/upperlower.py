sName = "aLan turing"
print(sName.title())

sName = "John von Neumann"
print(sName.upper())
print(sName.lower())