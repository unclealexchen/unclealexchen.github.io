n = 3
fPrice = 3.6
fAmount = n * fPrice
fMoney = 20
fMoney = fMoney - fAmount
sText = "我买了"
print(sText, n, "斤苹果，每斤3.6元，一共花了", fAmount, "元。", "妈妈给了我20元，还剩下", fMoney, "元。")