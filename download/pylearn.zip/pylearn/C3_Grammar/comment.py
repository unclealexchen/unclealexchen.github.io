"""
The following program was written by Alex, all rights reserved.
I hope that this book can lead you into the fantastic world of programming.

Loving Alex  chenbo@cqu.edu.cn
"""

# Output to console by print function
print("How beautiful your life will be !")