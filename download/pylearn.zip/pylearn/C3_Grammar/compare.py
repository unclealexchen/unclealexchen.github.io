a = 10
print("a > 5:", a > 5)
print("a < 20 and a >= 10:", a < 20 and a >= 10)
print("a != 3:", a != 3)
print("a > 100 or a < 20:", a > 100 or a < 20)
print("not a >= 10:", not a >= 10)