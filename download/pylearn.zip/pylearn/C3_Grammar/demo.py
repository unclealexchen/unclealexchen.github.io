print([0,1][True])
print(['a','b'][False])