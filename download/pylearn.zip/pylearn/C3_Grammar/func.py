# <Python编程基础及应用> 随书代码 高等教育出版社
n1 = pow(2,8)
n2 = abs(-10)
n3 = round(7/2)
print("2^8 =",n1)
print("absolute value of -10 =",n2)
print("7/2 ≈",n3)