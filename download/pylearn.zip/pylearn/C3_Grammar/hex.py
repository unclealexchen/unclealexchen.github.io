a = 0xff
b = 0b0111
print("0xff =", a,",", "0b0111=", b)
print(a,"=",hex(a),",",b,"=",bin(b))
print("%x"%(255))