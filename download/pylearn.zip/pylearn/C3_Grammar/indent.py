a = 103
if a > 100:
    print("a is bigger than 100.")
    print("a line means nothing.")
else:
    pass
print("a is a int.")