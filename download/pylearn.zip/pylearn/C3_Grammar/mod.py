a = 10
b = a // 3
print("b=",b,type(b))
c = a % 3   #求模  取余
print("c=",c)