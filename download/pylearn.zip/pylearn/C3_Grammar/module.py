import math
from math import sqrt

print( math.floor(67.7) )
print( math.ceil(67.1) )
print( math.sqrt(9) )
print( sqrt(16) )