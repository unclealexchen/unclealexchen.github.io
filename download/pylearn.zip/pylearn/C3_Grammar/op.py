a = 3
a = a + 2
print("a =",a)

b = 3
b += 2
print("b =",b)