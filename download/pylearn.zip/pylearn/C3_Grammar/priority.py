n = 3 + 2 * 6 / 3
print(n)

n = (3 + 2) * 6 / 3
print(n)