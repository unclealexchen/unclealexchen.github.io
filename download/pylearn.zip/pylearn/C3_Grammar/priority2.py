n = 2 + 3 * 2 ** 2
print(n)

n = 2 + 3 * (2 ** 2)
print(n)