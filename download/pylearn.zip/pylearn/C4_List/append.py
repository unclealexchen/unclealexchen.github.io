#append.py
jack = ['10000', 'Jack Ma', 47]
jack.append("CEO")
print("jack list after append:", jack)

jack.insert(2,'male')
print("jack list after insert at position 2:",jack)