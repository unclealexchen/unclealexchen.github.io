cubes = [x**3+100 for x in range(1,11)]
print(cubes)