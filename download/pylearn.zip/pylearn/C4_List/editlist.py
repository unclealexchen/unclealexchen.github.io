months = ['January','February','March','April','May','June',
          'July','August','September','October','November','December']
months[3] = 4
print(months[2],months[3])
print("The final element of months list is:", months[-1])