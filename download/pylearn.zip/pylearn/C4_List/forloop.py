dummy = ['jack', 5, False, 3.1415926, 'mary', ["A","B"]]
for x in dummy:
    print(x)
    print(type(x))
print("This line does not belong to for loop.")