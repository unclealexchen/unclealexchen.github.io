values = [x+y for x in "abc" for y in "0123"]
print(values)