values = []
for x in "abc":
    for y in "0123":
        values.append(x+y)
print(values)