fours = list(range(0,17,4))
print(fours)