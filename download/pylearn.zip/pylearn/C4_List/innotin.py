print('a' in 'string', 'tri' in 'string')
print('bob' not in ['bob','mary','tom'])