lans = ["C", "C++", "Pascal"]
print(["Python", "Ruby", "R", "Scala"] + lans)
print([1,3,5] * 2)
print('python' * 5)