matrix = [[0] * 8] * 10		#警告-这种方法暗藏危机，见第5章习题5-3
print(matrix)