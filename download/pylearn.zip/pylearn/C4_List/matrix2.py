matrix = [[r*c for c in range(8)] for r in range(10)]
print(matrix)