months = ['January','February','March','April','May','June',
          'July','August','September','October','November','December']
print(type(months))
print(len(months))
print(months[0],months[3])