person1 = ['10000', 'Jack Ma',   'male',   47, 'CEO']
person2 = person1
person2[1] = "Tom Henry"
print(person1)
print(person2)