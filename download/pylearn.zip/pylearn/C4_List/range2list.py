x = range(5)
x = list(x)
print(type(x),x)