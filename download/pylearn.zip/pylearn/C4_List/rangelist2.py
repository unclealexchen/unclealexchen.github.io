x = range(5)
print(x[2])
print(x)
print(type(x))