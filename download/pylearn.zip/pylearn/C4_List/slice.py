numbers = [x for x in range(10)]
print("numbers:",numbers)
print("numbers[3:9]:",numbers[3:9])
print("numbers[3:]:",numbers[3:])
print("numbers[:9]:",numbers[:9])
print("numbers[-6:-1]:",numbers[-6:-1])
print("numbers[1:9:2]:",numbers[1:9:2])
print("numbers[-1:1:-2]:",numbers[-1:1:-2])