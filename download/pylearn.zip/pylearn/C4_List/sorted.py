names = ['jack','mary','tom','dorothy','peter']
namesSorted = sorted(names)
print("names: ", names)
print("namesSorted: ", namesSorted)