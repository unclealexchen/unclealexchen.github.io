numbers = '0123456789'
print(numbers[2:5])
print(numbers[1:9:2])
print(numbers[:3:-2])