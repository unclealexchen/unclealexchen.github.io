#createset.py
countries = {"China","USA","Japan","France"}
print("countries:",type(countries),countries)
d1 = {}
print("d1:",type(d1))
s1 = set("Hello")
print("s1:",s1)
s2 = set([1,3,1,2,7,6])
print("s2:",s2)
values = list(s2)
print("values:",values)