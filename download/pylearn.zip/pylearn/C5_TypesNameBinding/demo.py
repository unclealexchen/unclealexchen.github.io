m = [[0]*4]*3
m[0][1] = 99
for x in m:
    print(x)
    