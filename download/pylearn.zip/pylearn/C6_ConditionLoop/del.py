x = "Anything"
y = x
del y
print(y)