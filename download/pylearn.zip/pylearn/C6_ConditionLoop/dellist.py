#dellist.py
jack = ['10000', 'Jack Ma', 'male', 47, 'CEO']
del jack[2]
print("jack list after del:",jack)
