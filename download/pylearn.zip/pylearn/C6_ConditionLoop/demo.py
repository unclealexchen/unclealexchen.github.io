i = 1
while i + 1:
    if i > 4:
        print("%d" % i)
        i += 1
        break
    print("%d" % i)
    i += 1
    i += 1