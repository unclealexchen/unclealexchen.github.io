eval("print('This string was print in eval function.')")
r = eval("3 + 2 - 5")
print(r)