s = ""
for x in 'abcdefg':
    s = s + x + " - "
print(s)

s = ""
for x in [2,3,2,2]:
    s = s + str(x) + " - "
print(s)

s = []
for x in range(2,20,4):
    s.append(x)
print(s)