sum = 0
for x in range(1,100+1):
    sum += x
print("sum of (1,2,...,99,100):",sum)