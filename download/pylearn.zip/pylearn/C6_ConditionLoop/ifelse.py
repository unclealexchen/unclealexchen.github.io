iAge = int(input("Hey, boy, how old are you? "))
if iAge >= 22:
    print("You are legal to be married. ")
else:
    print("You are still too young.")