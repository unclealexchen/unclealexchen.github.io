sMessage = ""
while sMessage != "q":
    sMessage = input("I am a parrot, say something to me( q to quit ):")
    print("Parrot says:", sMessage)