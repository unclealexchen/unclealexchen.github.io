names = ['Tom', 'Andy', 'Alex', 'Dorothy']
for x in reversed(names):
    print(x)