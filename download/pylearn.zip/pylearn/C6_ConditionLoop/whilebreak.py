while True:
    sMessage = input("I am a parrot, say something to me( q to quit ):")
    if sMessage == "q":
        break
    print("Parrot says:", sMessage)