sum = i = 0
while i <=100:
    sum += i
    i+=1
print("sum of (1,2,...,100)=", sum)