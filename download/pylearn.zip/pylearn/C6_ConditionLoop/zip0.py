names = ['Tom', 'Andy', 'Alex', 'Dorothy']
salarys = [1200, 1050, 1600, 2010]
for i in range(len(names)):
    print(names[i]+"'s salary/week:",salarys[i])