names = ['Tom', 'Andy', 'Alex', 'Dorothy']
salarys = [1200, 1050, 1600, 2010]
zipped = zip(names,salarys)
print(zipped)
print(list(zipped))