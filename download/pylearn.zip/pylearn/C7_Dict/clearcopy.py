dora = {'id':'10003', 'name':'Dora Chen','gender':'female',\
        'age':32, 'title':'Sales'}

doraCopy = dora.copy()
dora.clear()

print("dict dora after clear:", dora)
print("dict doraCopy after dict dora's clear:",doraCopy)