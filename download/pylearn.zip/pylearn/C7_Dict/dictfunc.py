items = [('name','Dorothy'),('id','10003'),('age',26)]
dorothy = dict(items)
print(dorothy)