d = dict.fromkeys(['id','name','age'], 'NOTKNOWN')
d1 = {}.fromkeys(['id','name','age'], 'NOTKNOWN')
print(d)
print(d1)