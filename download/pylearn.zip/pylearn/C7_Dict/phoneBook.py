phoneBook = {'Alex':'6511-2002', 'Betty':"6512-7252",
             'Dora':"6546-2708", 'Peter':'6716-4203'}
phoneBook["Dorothy"] = '6557-7272'
print("Dora's call number is:", phoneBook["Dora"])
print(type(phoneBook))
print(phoneBook)