#QuadraticFun.py
def f(x):
    y=x*x+3*x+1
    return y

print(f(0))
print(f(2))
print(f(-4))
