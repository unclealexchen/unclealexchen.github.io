def add(x,y):
    "Calculate the sum of two numbers.\
\nThe Numbers could be integer or float."
    return x+y

print(add.__doc__)