x = 1
s = "Hahaha"
scope = vars()
print(scope)
scope["x"] = 2
print("x:",x)