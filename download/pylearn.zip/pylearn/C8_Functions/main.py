import fac
f6 = fac.factorial(6)
print(f6)
