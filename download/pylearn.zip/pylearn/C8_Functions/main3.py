#main3.py
from Compute import fac
f6 = fac.factorial(6)