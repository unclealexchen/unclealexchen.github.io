titles = ['学号','姓名','出生年月','绩点']
value1 = ['20190324','Andy Lee','2002-12',3.4675]
value2 = ['2019L1','李杜','2001-11',2.78]
value3 = ['2019X11','Leonardo di ser Piero Da Vinci','2012-4',3.11111]

for x in titles:
    print(x,end=" ")
print()
for x in value1:
    print(x,end=" ")
print()
for x in value2:
    print(x,end=" ")
print()
for x in value3:
    print(x,end=" ")


 
