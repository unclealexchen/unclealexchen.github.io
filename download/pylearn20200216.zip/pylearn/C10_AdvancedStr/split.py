print("1+2+3+4+5".split("+"))
print("\\usr\\bin\\java\\lib".split("\\"))
print("one two three four".split())