with open('title.txt') as f:
    for line in f:
        print(line)

"""
lines = list(open('title.tt'))
for line in lines:
    print(line)
"""