import os
print(os.__file__)