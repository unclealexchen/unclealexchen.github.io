import numpy as np
a = np.array([1,3,5],dtype=np.int)
b = np.array([2,4,6],dtype=np.float32)
c1 = np.add(a,b)
c2 = a + b
print("c1=",c1)
print("c2=",c2)
