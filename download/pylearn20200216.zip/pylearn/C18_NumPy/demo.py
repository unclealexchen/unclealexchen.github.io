import numpy as np 


print(np.logspace(0,2,10,endpoint=False))
