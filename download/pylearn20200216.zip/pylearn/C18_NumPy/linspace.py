import numpy as np

print("np.arange(0,1,0.1):\n",np.arange(0,1,0.1))
print("np.linspace(0,1,10):\n",np.linspace(0,1,10))
print("np.linspace(0,1,10,endpoint=False):\n",
      np.linspace(0,1,10,endpoint=False))


