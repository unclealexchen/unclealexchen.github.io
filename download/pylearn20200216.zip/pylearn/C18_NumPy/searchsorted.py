import numpy as np
a = np.array([0, 2, 9, 10])
v = np.array([0,1,2,3,4,5,6,7,8,9,10])
print("a=",a)
print("v=",v)
print("np.searchsorted(a,v)=",np.searchsorted(a,v))

