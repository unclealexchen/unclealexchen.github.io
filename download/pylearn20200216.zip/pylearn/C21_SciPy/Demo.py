from scipy import constants as C
print(C.pound)