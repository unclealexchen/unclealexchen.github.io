print(int(True))
print(int(False))

if 3:
    print("True")
if -0.00099:
    print("True")