# i=1
# while(i=100):
#     i=i+1
#     if i/2==0:
#         print(i)
#     else:
#         pass

for i in range(101):
    if i%2==0:
        print(i,end=",")
    

     
