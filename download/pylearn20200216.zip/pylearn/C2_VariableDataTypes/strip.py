sText = "    How beautiful my life is !      "
print("Output by rstrip:", sText.rstrip(), "END.")
print("Output by lstrip:", sText.lstrip(), "END.")
print("Output by  strip:", sText.strip(), "END.")