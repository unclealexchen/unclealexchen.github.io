print('I told you, "Python is good".')
print("I told you, 'Python is good'.")