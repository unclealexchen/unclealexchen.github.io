s1 = "120"
s2 = "3.1415926"
i = int(s1)
f = float(s2)
s3 = str(i)
s4 = str(f)
print("i =",i,"f =",f,"s3 =",s3,"s4 =",s4)