sName = input("What's your name: ")  #用户输入姓名并按下Enter后程序才会继续执行
iAge = input("How old are you ? ")	 
iAge = int(iAge)
print("Hi,", sName, "You are ",iAge, "years old.")