scores = [23, 76, 98, 82, 56, 67]
print(max(scores))
print(min(scores))
print(sum(scores))
print("average =", sum(scores)/len(scores))