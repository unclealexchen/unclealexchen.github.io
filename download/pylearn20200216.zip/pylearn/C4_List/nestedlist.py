jack = ['10000', 'Jack Ma',   'male',   47, 'CEO']
mary = ['10001', 'Mary Lee',  'female', 25, 'Secretary']
tom  = ['10002', 'Tom Henry', 'male',   28, 'Engineer']
dora = ['10003', 'Dora Chen', 'female', 32, 'Sales']
employees = [jack,mary,tom]
employees.append(dora)
print(employees[2])
print(employees[2][1])