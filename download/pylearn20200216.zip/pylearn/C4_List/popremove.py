jack = ['10000', 'Jack Ma', 'male', 47, 47, 'CEO', 47]
sGender = jack.pop(2)
print("jack list after pop(2):",jack)
print("The popped element is:",sGender)

jack.remove(47)
print("jack list after remove(47):",jack)