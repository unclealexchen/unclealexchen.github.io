#rangelist.py
print("output of range(5):")
for i in range(5):
    print(i)

print("output of range(2,5):")
for x in range(2,5):
    print(x)