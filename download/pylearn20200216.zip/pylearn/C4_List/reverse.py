names = ['jack','mary','tom','dorothy','peter']
names.reverse()
print(names)