values = [x*x for x in range(10) if x % 3 == 0]
print(values)