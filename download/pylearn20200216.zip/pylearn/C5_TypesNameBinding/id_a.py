a = 3
b = int(a ** 2 / 3)
print(a,b)
print(id(a),id(b))