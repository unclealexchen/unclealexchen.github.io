#isequal.py
a = 3					#a绑定至整数对象3
b = 3.0					#b绑定至浮点数对象3.0
print("a==b:",a==b)
print("a is b:",a is b)
print(id(a),id(b))