values = (3,2,1)
valuesCopy = values
valuesCopy = (1,2,3)
print(values, "-", valuesCopy)

string = "string"
stringCopy = string
stringCopy = "new string"
print(string, "-", stringCopy)