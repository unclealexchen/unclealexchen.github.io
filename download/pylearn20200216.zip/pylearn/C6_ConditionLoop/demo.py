class <类名>(<父类列表>):
    def __init__(self,<形参>):
        <函数体>
    
    def <成员函数名1>(self,<形参>):
        <函数体>
        return <返回值列表>
    ...
    def <成员函数名n>(self,<形参>):
        <函数体>
        return <返回值列表>
