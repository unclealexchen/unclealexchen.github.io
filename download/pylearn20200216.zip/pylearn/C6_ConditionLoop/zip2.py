names = ['Tom', 'Andy', 'Alex', 'Dorothy']
salarys = [1200, 1050, 1600, 2010]
for name, salary in zip(names,salarys):
    print(name+"'s salary/week:",salary)