#dictfunc2.py
dorothy = dict(name='Dorothy', id='10003', age=26)
print(dorothy)