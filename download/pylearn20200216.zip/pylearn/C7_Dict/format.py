sText = "Mary have {} lambs, they are {n1}, {n2} and " \
        "{}.".format(3,'cot',n1='happy',n2='nauty')
print(sText)