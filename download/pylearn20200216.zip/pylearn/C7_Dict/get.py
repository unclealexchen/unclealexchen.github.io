dora = {'id':'10003', 'name':'Dora Chen','gender':'female',\
        'age':32, 'title':'Sales'}
print("Title:",dora.get("title"))
print("Salary:",dora.get("salary","N/A"))