dora = {}
dora.setdefault('id','N/A')
dora.setdefault('name','N/A')
dora.setdefault('gender','male')
dora.setdefault('age',0)

dora['age'] = 26
dora['name'] = 'Dora Chen'

print(dora)