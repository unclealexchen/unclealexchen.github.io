dora = {'id':'10003', 'age':32, 'title':'Sales'}
dora2 = {'name':'Dora Chen','gender':'female',\
        'age':32, 'title':'CEO'}

dora.update(dora2)
print(dora)