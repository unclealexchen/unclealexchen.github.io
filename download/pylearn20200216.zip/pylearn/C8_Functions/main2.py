#main2.py
from fac import factorial
f6 = factorial(6)