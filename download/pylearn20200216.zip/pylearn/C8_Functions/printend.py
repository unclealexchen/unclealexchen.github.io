print("我还记得几位唐朝诗人：","李白",end=",")
print("杜甫",end=",")
print("白居易",end=",")
print("孟浩然",end=",")