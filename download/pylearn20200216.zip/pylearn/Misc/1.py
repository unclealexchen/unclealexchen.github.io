# print('\n'.join([' '.join(["%2s x%2s = %2s"%(j,i,i*j) for j in range(1,i+1)]) for i in range(1,10)]))
# import random
# print(''.join(random.choice('\u2571\u2572') for i in range(50*24)))

